-- Customer Master Data schema

CREATE SCHEMA IF NOT EXISTS customer;
SET search_path TO customer, public;

-- Enum types
CREATE TYPE entity_type AS ENUM ('person', 'company');
CREATE TYPE kyc_status AS ENUM ('not_started', 'in_progress', 'verified', 'expired', 'rejected');
CREATE TYPE onboarding_status AS ENUM ('pending', 'active', 'suspended', 'closed');
CREATE TYPE association_role AS ENUM ('signatory', 'board_member', 'employee', 'guardian', 'power_of_attorney', 'spouse', 'parent');

-- Persons (physical human beings)
CREATE TABLE persons (
    id UUID PRIMARY KEY,
    given_name TEXT NOT NULL,
    family_name TEXT NOT NULL,
    date_of_birth DATE,
    national_id TEXT UNIQUE,
    email TEXT,
    phone TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Companies (legal persons)
CREATE TABLE companies (
    id UUID PRIMARY KEY,
    name TEXT NOT NULL,
    org_number TEXT NOT NULL UNIQUE,
    company_type TEXT,
    registered_address TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Customer role (applied to either a person or a company)
CREATE TABLE customers (
    id UUID PRIMARY KEY,
    legal_entity_id UUID NOT NULL,
    entity_type entity_type NOT NULL,
    kyc_status kyc_status NOT NULL DEFAULT 'not_started',
    risk_classification TEXT,
    onboarding_status onboarding_status NOT NULL DEFAULT 'pending',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (legal_entity_id)
);

-- Associations (links a person to an entity with a role)
CREATE TABLE associations (
    id UUID PRIMARY KEY,
    person_id UUID NOT NULL REFERENCES persons(id),
    associated_entity_id UUID NOT NULL,
    role association_role NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (person_id, associated_entity_id, role)
);

-- Digital identities (maps auth credentials to a person)
CREATE TABLE digital_identities (
    id UUID PRIMARY KEY,
    person_id UUID NOT NULL REFERENCES persons(id),
    provider TEXT NOT NULL,
    subject TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (provider, subject)
);

-- KYC evidence / screening records (append-only history)
-- New evidence supersedes old evidence for the same (entity_id, entity_type, attribute_key).
-- The partial unique index enforces at most one "current" row per key.
CREATE TABLE kyc_evidence (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    entity_id       UUID NOT NULL,
    entity_type     entity_type NOT NULL,
    attribute_key   VARCHAR(100) NOT NULL,
    attribute_value JSONB NOT NULL,
    verified_at     TIMESTAMPTZ,
    verified_by     VARCHAR(255),
    expires_at      TIMESTAMPTZ,
    superseded_by   UUID REFERENCES kyc_evidence(id),
    created_at      TIMESTAMPTZ DEFAULT now()
);

-- Only one "current" (non-superseded) row per entity+key
CREATE UNIQUE INDEX idx_kyc_evidence_current_unique
    ON kyc_evidence(entity_id, entity_type, attribute_key)
    WHERE superseded_by IS NULL;

-- Fast lookup of all current evidence for an entity
CREATE INDEX idx_kyc_evidence_entity
    ON kyc_evidence(entity_id, entity_type)
    WHERE superseded_by IS NULL;

-- Materialized current-state view (for reads and policy checks)
CREATE VIEW kyc_current AS
    SELECT id, entity_id, entity_type, attribute_key, attribute_value, verified_at, verified_by, expires_at, created_at
    FROM kyc_evidence
    WHERE superseded_by IS NULL;

-- Indexes
CREATE INDEX idx_customers_entity ON customers(legal_entity_id);
CREATE INDEX idx_associations_person ON associations(person_id);
CREATE INDEX idx_associations_entity ON associations(associated_entity_id);
CREATE INDEX idx_digital_identities_person ON digital_identities(person_id);
CREATE INDEX idx_digital_identities_resolve ON digital_identities(provider, subject);
