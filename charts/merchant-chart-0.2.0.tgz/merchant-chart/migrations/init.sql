-- Merchant Service Schema (idempotent)
-- Manages product catalog and procurement/checkout process

CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ══════════════════════════════════════════════════════════
-- CATALOG SCHEMA — Products, categories, pricing
-- ══════════════════════════════════════════════════════════

CREATE SCHEMA IF NOT EXISTS catalog;

CREATE TABLE IF NOT EXISTS catalog.categories (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL UNIQUE,
    description TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS catalog.products (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    description TEXT,
    category_id UUID REFERENCES catalog.categories(id),
    price NUMERIC(15,2) NOT NULL CHECK (price >= 0),
    currency TEXT NOT NULL DEFAULT 'BRG',
    active BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_products_category ON catalog.products(category_id);
CREATE INDEX IF NOT EXISTS idx_products_active ON catalog.products(active);

-- ══════════════════════════════════════════════════════════
-- PROCUREMENT SCHEMA — Orders, payments, receipts
-- ══════════════════════════════════════════════════════════

CREATE SCHEMA IF NOT EXISTS procurement;

CREATE TABLE IF NOT EXISTS procurement.orders (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    status TEXT NOT NULL DEFAULT 'draft'
        CHECK (status IN ('draft','awaiting_payment','paid','payment_failed','cancelled','receipted')),
    customer_iban TEXT,
    total_amount NUMERIC(15,2) NOT NULL DEFAULT 0 CHECK (total_amount >= 0),
    currency TEXT NOT NULL DEFAULT 'BRG',
    store_id TEXT,
    terminal_id TEXT,
    operator_id TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_orders_status ON procurement.orders(status);

CREATE TABLE IF NOT EXISTS procurement.order_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id UUID NOT NULL REFERENCES procurement.orders(id) ON DELETE CASCADE,
    product_id UUID NOT NULL,
    product_name TEXT NOT NULL,
    quantity INTEGER NOT NULL CHECK (quantity > 0),
    unit_price NUMERIC(15,2) NOT NULL CHECK (unit_price >= 0),
    currency TEXT NOT NULL DEFAULT 'BRG',
    line_total NUMERIC(15,2) NOT NULL CHECK (line_total >= 0),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_order_items_order ON procurement.order_items(order_id);

CREATE TABLE IF NOT EXISTS procurement.payments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id UUID NOT NULL REFERENCES procurement.orders(id),
    rtp_id TEXT UNIQUE,
    rtp_status TEXT,
    bank_response JSONB,
    amount NUMERIC(15,2) NOT NULL CHECK (amount > 0),
    currency TEXT NOT NULL DEFAULT 'BRG',
    active BOOLEAN NOT NULL DEFAULT true,
    next_poll_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Enforce: at most one active payment per order
CREATE UNIQUE INDEX IF NOT EXISTS idx_one_active_payment_per_order
    ON procurement.payments(order_id) WHERE active = true;

CREATE INDEX IF NOT EXISTS idx_payments_poll ON procurement.payments(next_poll_at) WHERE active = true;

CREATE TABLE IF NOT EXISTS procurement.receipts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id UUID NOT NULL UNIQUE REFERENCES procurement.orders(id),
    payment_id UUID NOT NULL REFERENCES procurement.payments(id),
    receipt_number TEXT NOT NULL UNIQUE,
    items JSONB NOT NULL,
    total_amount NUMERIC(15,2) NOT NULL,
    currency TEXT NOT NULL,
    merchant_iban TEXT NOT NULL,
    customer_iban TEXT NOT NULL,
    issued_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
