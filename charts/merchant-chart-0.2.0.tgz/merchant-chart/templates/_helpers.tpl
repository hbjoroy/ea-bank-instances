{{/*
Common labels
*/}}
{{- define "merchant.labels" -}}
app.kubernetes.io/managed-by: {{ .Release.Service }}
helm.sh/chart: {{ .Chart.Name }}-{{ .Chart.Version }}
{{- end }}

{{/*
Database URL template
*/}}
{{- define "merchant.databaseUrl" -}}
postgres://{{ .Values.database.user }}:$(DB_PASSWORD)@{{ .Values.database.host }}:{{ .Values.database.port }}/{{ .Values.database.name }}
{{- end }}

{{/*
DB credentials secret name
*/}}
{{- define "merchant.dbCredentialsSecret" -}}
{{ .Release.Name }}-db-credentials
{{- end }}
