-- FIFTH Network — BIC Registry schema
-- Idempotent: safe to re-run on upgrades.

CREATE TABLE IF NOT EXISTS bic_entries (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    bic VARCHAR(11) UNIQUE NOT NULL,
    institution_code VARCHAR(4) NOT NULL,
    country_code VARCHAR(2) NOT NULL,
    name VARCHAR(255) NOT NULL,
    api_endpoint TEXT NOT NULL,
    currencies TEXT[] NOT NULL DEFAULT '{}',
    status VARCHAR(20) NOT NULL DEFAULT 'active'
        CHECK (status IN ('active', 'suspended', 'deactivated')),
    capabilities TEXT[] NOT NULL DEFAULT '{}',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_bic_institution_code ON bic_entries(institution_code);
CREATE INDEX IF NOT EXISTS idx_bic_status ON bic_entries(status);

-- Normalized sort code mappings. Each sort code maps to exactly one active BIC entry.
CREATE TABLE IF NOT EXISTS bic_sort_codes (
    sort_code VARCHAR(10) NOT NULL,
    bic_entry_id UUID NOT NULL REFERENCES bic_entries(id) ON DELETE CASCADE,
    PRIMARY KEY (sort_code)
);

CREATE INDEX IF NOT EXISTS idx_bic_sort_codes_entry ON bic_sort_codes(bic_entry_id);

-- Seed data: Minoa Bank and Isdalen Bank
INSERT INTO bic_entries (bic, institution_code, country_code, name, api_endpoint, currencies, capabilities)
VALUES
    ('MINOBRXX', 'MINO', 'BR', 'Minoa Bank',
     'http://bjoroy-bank-payment-engine.minoa-bank.svc:8083',
     ARRAY['NOK', 'BRG'], ARRAY['INST']),
    ('ISDABRXX', 'ISDA', 'BR', 'Isdalen Bank',
     'http://bjoroy-bank-payment-engine.isdalen-bank.svc:8083',
     ARRAY['NOK', 'BRG'], ARRAY['INST'])
ON CONFLICT (bic) DO NOTHING;

-- Fix: remove incorrect sort code 3688 (should have been 3188)
DELETE FROM bic_sort_codes WHERE sort_code = '3688';

INSERT INTO bic_sort_codes (sort_code, bic_entry_id)
SELECT '3188', id FROM bic_entries WHERE bic = 'MINOBRXX'
ON CONFLICT (sort_code) DO NOTHING;

INSERT INTO bic_sort_codes (sort_code, bic_entry_id)
SELECT '3606', id FROM bic_entries WHERE bic = 'MINOBRXX'
ON CONFLICT (sort_code) DO NOTHING;

INSERT INTO bic_sort_codes (sort_code, bic_entry_id)
SELECT '3607', id FROM bic_entries WHERE bic = 'MINOBRXX'
ON CONFLICT (sort_code) DO NOTHING;

INSERT INTO bic_sort_codes (sort_code, bic_entry_id)
SELECT '3608', id FROM bic_entries WHERE bic = 'MINOBRXX'
ON CONFLICT (sort_code) DO NOTHING;

INSERT INTO bic_sort_codes (sort_code, bic_entry_id)
SELECT '3609', id FROM bic_entries WHERE bic = 'MINOBRXX'
ON CONFLICT (sort_code) DO NOTHING;

INSERT INTO bic_sort_codes (sort_code, bic_entry_id)
SELECT '3610', id FROM bic_entries WHERE bic = 'MINOBRXX'
ON CONFLICT (sort_code) DO NOTHING;

INSERT INTO bic_sort_codes (sort_code, bic_entry_id)
SELECT '3288', id FROM bic_entries WHERE bic = 'ISDABRXX'
ON CONFLICT (sort_code) DO NOTHING;

-- ============================================================================
-- RTP Directory schema — IBAN-prefix based SP routing
-- ============================================================================

CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE SCHEMA IF NOT EXISTS rtp_directory;

CREATE TABLE IF NOT EXISTS rtp_directory.participants (
    id          TEXT PRIMARY KEY,
    name        TEXT NOT NULL,
    endpoint    TEXT NOT NULL,
    active      BOOLEAN NOT NULL DEFAULT TRUE,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS rtp_directory.iban_prefixes (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    participant_id  TEXT NOT NULL REFERENCES rtp_directory.participants(id) ON DELETE CASCADE,
    prefix          TEXT NOT NULL UNIQUE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_iban_prefixes_prefix ON rtp_directory.iban_prefixes(prefix);
CREATE INDEX IF NOT EXISTS idx_iban_prefixes_participant ON rtp_directory.iban_prefixes(participant_id);

-- ============================================================================
-- RTP Directory v2 — BIC-based SP routing with customer choice support
-- ============================================================================

-- SP registrations: maps BIC → participant (bank-level default routing)
CREATE TABLE IF NOT EXISTS rtp_directory.sp_registrations (
    participant_id  TEXT NOT NULL REFERENCES rtp_directory.participants(id) ON DELETE CASCADE,
    bic             TEXT NOT NULL,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (participant_id, bic)
);

CREATE INDEX IF NOT EXISTS idx_sp_registrations_bic ON rtp_directory.sp_registrations(bic);

-- Per-account overrides: customer can choose a different SP than their bank's default
CREATE TABLE IF NOT EXISTS rtp_directory.account_registrations (
    id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    identifier_type   TEXT NOT NULL,
    canonical_value   TEXT NOT NULL,
    participant_id    TEXT NOT NULL REFERENCES rtp_directory.participants(id) ON DELETE CASCADE,
    status            TEXT NOT NULL DEFAULT 'active',
    created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (identifier_type, canonical_value)
);

CREATE INDEX IF NOT EXISTS idx_account_registrations_lookup
    ON rtp_directory.account_registrations(identifier_type, canonical_value)
    WHERE status = 'active';

-- Sort code → BIC cache (replicated from BIC Registry, refreshed periodically)
CREATE TABLE IF NOT EXISTS rtp_directory.sort_code_bic_cache (
    sort_code   TEXT PRIMARY KEY,
    bic         TEXT NOT NULL,
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
