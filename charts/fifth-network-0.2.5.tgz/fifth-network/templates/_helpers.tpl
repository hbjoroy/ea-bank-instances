{{/*
Common labels
*/}}
{{- define "fifth-network.labels" -}}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Values.imageTag | default .Chart.AppVersion | quote }}
helm.sh/chart: {{ .Chart.Name }}-{{ .Chart.Version }}
{{- end }}

{{/*
Full DATABASE_URL
*/}}
{{- define "fifth-network.databaseUrl" -}}
postgres://{{ .Values.database.user }}:$(DB_PASSWORD)@{{ .Values.database.host }}:{{ .Values.database.port }}/{{ .Values.database.name }}
{{- end }}

{{/*
Database credentials secret — use existingSecret if provided
*/}}
{{- define "fifth-network.dbCredentialsSecret" -}}
{{- if .Values.database.existingSecret -}}
{{ .Values.database.existingSecret }}
{{- else -}}
{{ .Release.Name }}-db-credentials
{{- end -}}
{{- end }}

{{/*
Database credentials secret key
*/}}
{{- define "fifth-network.dbCredentialsSecretKey" -}}
{{ .Values.database.existingSecretKey | default "password" }}
{{- end }}
