-- ea-bank-accounting schema
-- GL accounting module for Bjørøy Bank

CREATE SCHEMA IF NOT EXISTS accounting;

-- Chart of accounts: hierarchical GL account structure
-- Follows NS 4102 (Norwegian standard) adapted for banking
-- Code format: 4 digits (NNNN), hierarchy derived from prefix
--   Class (kontoklasse):  first digit  (1-8)
--   Group (kontogruppe):  first 2 digits (10-89)
--   Account (konto):      full 4 digits (1000-8999)
CREATE TABLE IF NOT EXISTS accounting.chart_of_accounts (
    code        VARCHAR(10) PRIMARY KEY,
    name        VARCHAR(200) NOT NULL,
    description TEXT DEFAULT '',
    account_class   SMALLINT NOT NULL,  -- 1=Assets, 2=Liab+Equity, 3=Revenue, 4-7=Expenses, 8=Tax
    account_group   VARCHAR(10),        -- parent group code (first 2 digits for accounts)
    normal_side     VARCHAR(6) NOT NULL CHECK (normal_side IN ('debit', 'credit')),
    is_group        BOOLEAN DEFAULT FALSE,  -- true = group header, not postable
    is_active       BOOLEAN DEFAULT TRUE,
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- Accounting periods: monthly with lifecycle management
CREATE TABLE IF NOT EXISTS accounting.accounting_periods (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    year        SMALLINT NOT NULL,
    month       SMALLINT NOT NULL CHECK (month BETWEEN 1 AND 12),
    status      VARCHAR(10) NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'closed', 'locked')),
    opened_at   TIMESTAMPTZ DEFAULT NOW(),
    closed_at   TIMESTAMPTZ,
    locked_at   TIMESTAMPTZ,
    created_at  TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE (year, month)
);

-- Journal entries: GL-level transactions (may originate from core sync or manual entry)
CREATE TABLE IF NOT EXISTS accounting.journal_entries (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    period_id       UUID NOT NULL REFERENCES accounting.accounting_periods(id),
    entry_number    BIGINT,  -- sequential within period
    reference       VARCHAR(255) NOT NULL,      -- e.g. core transaction ID, or manual ref
    description     TEXT DEFAULT '',
    source          VARCHAR(20) NOT NULL DEFAULT 'manual' CHECK (source IN ('manual', 'sync', 'closing')),
    core_transaction_id UUID,                   -- link to core posting (NULL for manual entries)
    posted_at       TIMESTAMPTZ DEFAULT NOW(),
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- Journal lines: individual debit/credit per GL account
CREATE TABLE IF NOT EXISTS accounting.journal_lines (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    entry_id        UUID NOT NULL REFERENCES accounting.journal_entries(id),
    gl_account_code VARCHAR(10) NOT NULL REFERENCES accounting.chart_of_accounts(code),
    debit           NUMERIC(19, 4) NOT NULL DEFAULT 0,
    credit          NUMERIC(19, 4) NOT NULL DEFAULT 0,
    currency        VARCHAR(3) DEFAULT 'NOK',
    description     TEXT DEFAULT '',
    CONSTRAINT positive_amounts CHECK (debit >= 0 AND credit >= 0),
    CONSTRAINT one_side_only CHECK (debit = 0 OR credit = 0)
);

-- Balanced journal entry trigger
CREATE OR REPLACE FUNCTION accounting.check_journal_entry_balance()
RETURNS TRIGGER AS $$
DECLARE
    entry_total NUMERIC(19, 4);
BEGIN
    SELECT COALESCE(SUM(debit) - SUM(credit), 0)
    INTO entry_total
    FROM accounting.journal_lines
    WHERE entry_id = NEW.entry_id;

    -- Allow during insert (partial entry); final check via API before commit
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- GL mapping rules: core posting patterns → GL account codes
-- Used by sync process to auto-map core postings to journal entries
CREATE TABLE IF NOT EXISTS accounting.gl_mappings (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name                VARCHAR(100) NOT NULL,
    description         TEXT DEFAULT '',
    core_account_type   VARCHAR(20),            -- matches core.ledger_accounts.account_type
    core_account_subtype VARCHAR(40),           -- matches core.ledger_accounts.account_subtype
    currency            VARCHAR(3),             -- NULL = any currency
    posting_side        VARCHAR(6) NOT NULL CHECK (posting_side IN ('debit', 'credit')),
    gl_account_code     VARCHAR(10) NOT NULL REFERENCES accounting.chart_of_accounts(code),
    priority            INT DEFAULT 0,          -- higher = matched first
    is_active           BOOLEAN DEFAULT TRUE,
    created_at          TIMESTAMPTZ DEFAULT NOW(),
    updated_at          TIMESTAMPTZ DEFAULT NOW()
);

-- Materialized period balances for fast reporting
CREATE TABLE IF NOT EXISTS accounting.balances (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    period_id       UUID NOT NULL REFERENCES accounting.accounting_periods(id),
    gl_account_code VARCHAR(10) NOT NULL REFERENCES accounting.chart_of_accounts(code),
    debit_total     NUMERIC(19, 4) NOT NULL DEFAULT 0,
    credit_total    NUMERIC(19, 4) NOT NULL DEFAULT 0,
    balance         NUMERIC(19, 4) NOT NULL DEFAULT 0,  -- debit_total - credit_total (or inverse for credit-normal accounts)
    currency        VARCHAR(3) DEFAULT 'NOK',
    computed_at     TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE (period_id, gl_account_code, currency)
);

-- Sync state: track last synced core posting for incremental sync
CREATE TABLE IF NOT EXISTS accounting.sync_state (
    id                  VARCHAR(50) PRIMARY KEY DEFAULT 'default',
    last_synced_at      TIMESTAMPTZ,
    last_transaction_id UUID,
    sync_count          BIGINT DEFAULT 0,
    updated_at          TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_journal_entries_period ON accounting.journal_entries(period_id);
CREATE INDEX IF NOT EXISTS idx_journal_entries_core_tx ON accounting.journal_entries(core_transaction_id);
CREATE INDEX IF NOT EXISTS idx_journal_lines_entry ON accounting.journal_lines(entry_id);
CREATE INDEX IF NOT EXISTS idx_journal_lines_gl_account ON accounting.journal_lines(gl_account_code);
CREATE INDEX IF NOT EXISTS idx_balances_period ON accounting.balances(period_id);
CREATE INDEX IF NOT EXISTS idx_gl_mappings_pattern ON accounting.gl_mappings(core_account_type, core_account_subtype, currency);

-- Seed: default Norwegian bank chart of accounts (NS 4102 adaptation)
-- Groups (is_group = true) and key accounts

-- Class 1: Assets (Eiendeler)
INSERT INTO accounting.chart_of_accounts (code, name, account_class, normal_side, is_group) VALUES
    ('10', 'Immaterielle eiendeler', 1, 'debit', TRUE),
    ('11', 'Tomter og bygninger', 1, 'debit', TRUE),
    ('12', 'Transportmidler, inventar, maskiner', 1, 'debit', TRUE),
    ('13', 'Finansielle anleggsmidler', 1, 'debit', TRUE),
    ('14', 'Utlån til kunder', 1, 'debit', TRUE),
    ('15', 'Kortsiktige fordringer', 1, 'debit', TRUE),
    ('19', 'Kontanter og bankinnskudd', 1, 'debit', TRUE)
ON CONFLICT (code) DO NOTHING;

INSERT INTO accounting.chart_of_accounts (code, name, account_class, account_group, normal_side, is_group) VALUES
    ('1400', 'Utlån til kunder', 1, '14', 'debit', FALSE),
    ('1410', 'Nedbetalingslån', 1, '14', 'debit', FALSE),
    ('1420', 'Kassakreditt', 1, '14', 'debit', FALSE),
    ('1500', 'Kundefordringer', 1, '15', 'debit', FALSE),
    ('1900', 'Kontanter', 1, '19', 'debit', FALSE),
    ('1910', 'Bankinnskudd drift', 1, '19', 'debit', FALSE),
    ('1920', 'Bankinnskudd - Norges Bank', 1, '19', 'debit', FALSE),
    ('1930', 'Bankinnskudd - korrespondentbanker', 1, '19', 'debit', FALSE),
    ('1940', 'Oppgjørskonto', 1, '19', 'debit', FALSE)
ON CONFLICT (code) DO NOTHING;

-- Class 2: Liabilities & Equity (Gjeld og egenkapital)
INSERT INTO accounting.chart_of_accounts (code, name, account_class, normal_side, is_group) VALUES
    ('20', 'Egenkapital', 2, 'credit', TRUE),
    ('21', 'Avsetning for forpliktelser', 2, 'credit', TRUE),
    ('22', 'Annen langsiktig gjeld', 2, 'credit', TRUE),
    ('23', 'Innskudd fra kunder', 2, 'credit', TRUE),
    ('24', 'Leverandørgjeld', 2, 'credit', TRUE),
    ('26', 'Skattetrekk og offentlige avgifter', 2, 'credit', TRUE),
    ('27', 'Skyldig lønn og feriepenger', 2, 'credit', TRUE),
    ('29', 'Annen kortsiktig gjeld', 2, 'credit', TRUE)
ON CONFLICT (code) DO NOTHING;

INSERT INTO accounting.chart_of_accounts (code, name, account_class, account_group, normal_side, is_group) VALUES
    ('2000', 'Aksjekapital', 2, '20', 'credit', FALSE),
    ('2020', 'Overkursfond', 2, '20', 'credit', FALSE),
    ('2050', 'Annen egenkapital', 2, '20', 'credit', FALSE),
    ('2300', 'Kundeinnskudd - brukskonto', 2, '23', 'credit', FALSE),
    ('2310', 'Kundeinnskudd - sparekonto', 2, '23', 'credit', FALSE),
    ('2320', 'Kundeinnskudd - fastrentekonto', 2, '23', 'credit', FALSE),
    ('2400', 'Leverandørgjeld', 2, '24', 'credit', FALSE),
    ('2900', 'Annen kortsiktig gjeld', 2, '29', 'credit', FALSE)
ON CONFLICT (code) DO NOTHING;

-- Class 3: Revenue (Inntekter)
INSERT INTO accounting.chart_of_accounts (code, name, account_class, normal_side, is_group) VALUES
    ('30', 'Renteinntekter', 3, 'credit', TRUE),
    ('31', 'Provisjonsinntekter', 3, 'credit', TRUE),
    ('34', 'Gebyrinntekter', 3, 'credit', TRUE),
    ('38', 'Andre driftsinntekter', 3, 'credit', TRUE),
    ('39', 'Kursgevinster', 3, 'credit', TRUE)
ON CONFLICT (code) DO NOTHING;

INSERT INTO accounting.chart_of_accounts (code, name, account_class, account_group, normal_side, is_group) VALUES
    ('3000', 'Renteinntekter utlån', 3, '30', 'credit', FALSE),
    ('3010', 'Renteinntekter bankinnskudd', 3, '30', 'credit', FALSE),
    ('3100', 'Provisjonsinntekter betalingsformidling', 3, '31', 'credit', FALSE),
    ('3400', 'Gebyrinntekter kontohold', 3, '34', 'credit', FALSE),
    ('3410', 'Gebyrinntekter betalingstjenester', 3, '34', 'credit', FALSE),
    ('3800', 'Andre driftsinntekter', 3, '38', 'credit', FALSE)
ON CONFLICT (code) DO NOTHING;

-- Class 4: Cost of materials / Interest expenses
INSERT INTO accounting.chart_of_accounts (code, name, account_class, normal_side, is_group) VALUES
    ('40', 'Rentekostnader', 4, 'debit', TRUE),
    ('41', 'Andre finanskostnader', 4, 'debit', TRUE)
ON CONFLICT (code) DO NOTHING;

INSERT INTO accounting.chart_of_accounts (code, name, account_class, account_group, normal_side, is_group) VALUES
    ('4000', 'Rentekostnader kundeinnskudd', 4, '40', 'debit', FALSE),
    ('4010', 'Rentekostnader innlån', 4, '40', 'debit', FALSE),
    ('4100', 'Provisjonskostnader', 4, '41', 'debit', FALSE)
ON CONFLICT (code) DO NOTHING;

-- Class 5: Personnel expenses
INSERT INTO accounting.chart_of_accounts (code, name, account_class, normal_side, is_group) VALUES
    ('50', 'Lønn', 5, 'debit', TRUE),
    ('52', 'Arbeidsgiveravgift', 5, 'debit', TRUE),
    ('53', 'Pensjonskostnader', 5, 'debit', TRUE),
    ('59', 'Andre personalkostnader', 5, 'debit', TRUE)
ON CONFLICT (code) DO NOTHING;

INSERT INTO accounting.chart_of_accounts (code, name, account_class, account_group, normal_side, is_group) VALUES
    ('5000', 'Lønn', 5, '50', 'debit', FALSE),
    ('5200', 'Arbeidsgiveravgift', 5, '52', 'debit', FALSE),
    ('5300', 'Pensjonskostnader', 5, '53', 'debit', FALSE),
    ('5900', 'Andre personalkostnader', 5, '59', 'debit', FALSE)
ON CONFLICT (code) DO NOTHING;

-- Class 6-7: Other operating expenses
INSERT INTO accounting.chart_of_accounts (code, name, account_class, normal_side, is_group) VALUES
    ('60', 'Avskrivninger', 6, 'debit', TRUE),
    ('63', 'Tap på utlån', 6, 'debit', TRUE),
    ('65', 'IT-kostnader', 6, 'debit', TRUE),
    ('69', 'Andre driftskostnader', 6, 'debit', TRUE),
    ('70', 'Kontorkostnader', 7, 'debit', TRUE),
    ('77', 'Revisjon og rådgivning', 7, 'debit', TRUE),
    ('79', 'Andre driftskostnader 2', 7, 'debit', TRUE)
ON CONFLICT (code) DO NOTHING;

INSERT INTO accounting.chart_of_accounts (code, name, account_class, account_group, normal_side, is_group) VALUES
    ('6000', 'Avskrivninger', 6, '60', 'debit', FALSE),
    ('6300', 'Tap på utlån', 6, '63', 'debit', FALSE),
    ('6500', 'IT-drift og lisenser', 6, '65', 'debit', FALSE),
    ('6900', 'Andre driftskostnader', 6, '69', 'debit', FALSE),
    ('7000', 'Kontorkostnader', 7, '70', 'debit', FALSE),
    ('7700', 'Revisjon og rådgivning', 7, '77', 'debit', FALSE)
ON CONFLICT (code) DO NOTHING;

-- Class 8: Tax and extraordinary items
INSERT INTO accounting.chart_of_accounts (code, name, account_class, normal_side, is_group) VALUES
    ('80', 'Finansinntekter', 8, 'credit', TRUE),
    ('81', 'Finanskostnader', 8, 'debit', TRUE),
    ('83', 'Skattekostnad', 8, 'debit', TRUE),
    ('88', 'Årsresultat', 8, 'credit', TRUE)
ON CONFLICT (code) DO NOTHING;

INSERT INTO accounting.chart_of_accounts (code, name, account_class, account_group, normal_side, is_group) VALUES
    ('8000', 'Finansinntekter', 8, '80', 'credit', FALSE),
    ('8100', 'Finanskostnader', 8, '81', 'debit', FALSE),
    ('8300', 'Skattekostnad', 8, '83', 'debit', FALSE),
    ('8800', 'Årsresultat', 8, '88', 'credit', FALSE)
ON CONFLICT (code) DO NOTHING;

-- Default GL mappings: core posting patterns → GL accounts
-- These map the operational ledger events to the chart of accounts
INSERT INTO accounting.gl_mappings (name, core_account_type, core_account_subtype, currency, posting_side, gl_account_code, priority) VALUES
    ('Customer deposit - debit', 'general_ledger', NULL, 'NOK', 'debit', '1940', 10),
    ('Customer deposit - credit', 'customer', NULL, 'NOK', 'credit', '2300', 10),
    ('Fee income - debit', 'customer', NULL, 'NOK', 'debit', '2300', 5),
    ('Fee income - credit', NULL, 'fee_income', 'NOK', 'credit', '3400', 20),
    ('Loan disbursement - debit', 'customer', NULL, 'NOK', 'debit', '1400', 5),
    ('Loan disbursement - credit', 'general_ledger', NULL, 'NOK', 'credit', '1940', 5)
ON CONFLICT DO NOTHING;

-- Initialize sync state
INSERT INTO accounting.sync_state (id, sync_count) VALUES ('default', 0)
ON CONFLICT DO NOTHING;

-- ═══════════════════════════════════════════════════════════
-- Routine / operations tables
-- ═══════════════════════════════════════════════════════════

-- Reconciliation runs: one row per daily recon execution
CREATE TABLE IF NOT EXISTS accounting.reconciliation_runs (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    period_id       UUID NOT NULL REFERENCES accounting.accounting_periods(id),
    run_date        DATE NOT NULL,
    status          TEXT NOT NULL DEFAULT 'running'
                    CHECK (status IN ('running', 'clean', 'exceptions', 'failed')),
    total_accounts  INT NOT NULL DEFAULT 0,
    matched         INT NOT NULL DEFAULT 0,
    breaks          INT NOT NULL DEFAULT 0,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_recon_runs_date ON accounting.reconciliation_runs(run_date);

-- Reconciliation exceptions: individual breaks for investigation
CREATE TABLE IF NOT EXISTS accounting.reconciliation_exceptions (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    run_id          UUID NOT NULL REFERENCES accounting.reconciliation_runs(id),
    gl_account_code TEXT NOT NULL,
    gl_balance      NUMERIC(20,4) NOT NULL,
    core_balance    NUMERIC(20,4) NOT NULL,
    difference      NUMERIC(20,4) NOT NULL,
    currency        TEXT NOT NULL DEFAULT 'NOK',
    status          TEXT NOT NULL DEFAULT 'open'
                    CHECK (status IN ('open', 'investigating', 'resolved', 'written_off')),
    resolved_by     TEXT,
    resolved_at     TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_recon_exceptions_status ON accounting.reconciliation_exceptions(status);

-- Daily P&L flash: management summary per day
CREATE TABLE IF NOT EXISTS accounting.daily_flash (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    run_date        DATE NOT NULL,
    period_id       UUID NOT NULL REFERENCES accounting.accounting_periods(id),
    total_revenue   NUMERIC(20,4) NOT NULL DEFAULT 0,
    total_expenses  NUMERIC(20,4) NOT NULL DEFAULT 0,
    net_income      NUMERIC(20,4) NOT NULL DEFAULT 0,
    currency        TEXT NOT NULL DEFAULT 'NOK',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (run_date, currency)
);

-- Period snapshots: frozen financial statements for audit trail
CREATE TABLE IF NOT EXISTS accounting.period_snapshots (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    period_id       UUID NOT NULL REFERENCES accounting.accounting_periods(id),
    report_type     TEXT NOT NULL
                    CHECK (report_type IN ('trial_balance', 'balance_sheet', 'income_statement')),
    report_data     JSONB NOT NULL,
    generated_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (period_id, report_type)
);

-- Preserve missing sides separately from an observed zero in reconciliation.
ALTER TABLE accounting.reconciliation_exceptions
    ALTER COLUMN gl_balance DROP NOT NULL,
    ALTER COLUMN core_balance DROP NOT NULL;

ALTER TABLE accounting.reconciliation_runs
    ADD COLUMN IF NOT EXISTS bank_timezone TEXT,
    ADD COLUMN IF NOT EXISTS core_account_count BIGINT,
    ADD COLUMN IF NOT EXISTS core_posting_count BIGINT,
    ADD COLUMN IF NOT EXISTS failure_reason TEXT;

-- The GL insertion timestamp and the source transaction's effective timestamp
-- answer different questions when a core journal is imported late.
ALTER TABLE accounting.journal_entries
    ADD COLUMN IF NOT EXISTS core_transaction_timestamp TIMESTAMPTZ;

-- Positive operational savings liabilities are credits in the general ledger.
-- The product's expense/payable/capital roles are attached to individual postings.
INSERT INTO accounting.chart_of_accounts(code,name,account_class,account_group,normal_side,is_group)
VALUES ('2330','Påløpte renter på kundeinnskudd',2,'23','credit',FALSE)
ON CONFLICT (code) DO NOTHING;

INSERT INTO accounting.gl_mappings (id,name,core_account_type,core_account_subtype,posting_side,gl_account_code,priority)
SELECT md5('savings-interest-v1:' || role || ':' || side)::uuid,
       'Savings interest ' || role || ' ' || side, kind, role, side, code, 20
FROM (VALUES ('general_ledger','interest_expense','4000'),
             ('sub_account','accrual:interest','2330'),
             ('customer','savings_interest_capital','2310'),
             ('customer','savings_principal','2310'),('general_ledger','savings_settlement','1940')) roles(kind,role,code)
CROSS JOIN (VALUES ('debit'),('credit')) sides(side)
ON CONFLICT (id) DO NOTHING;

ALTER TABLE accounting.journal_entries ADD COLUMN IF NOT EXISTS interest_bank_date DATE;
ALTER TABLE accounting.journal_entries ADD COLUMN IF NOT EXISTS savings_movement BOOLEAN NOT NULL DEFAULT FALSE;

-- One imported savings accrual or capitalisation per immutable Core transaction.
CREATE UNIQUE INDEX IF NOT EXISTS savings_movement_journal_source
    ON accounting.journal_entries(core_transaction_id)
    WHERE savings_movement OR interest_bank_date IS NOT NULL;


-- One certified economic decision per bank, period and rule. A new workflow
-- attempt can link the same economics to another verified readiness receipt.
CREATE TABLE IF NOT EXISTS accounting.monthend_interest_basis (
    bank_instance_id UUID NOT NULL, period_id UUID NOT NULL REFERENCES accounting.accounting_periods(id),
    stage TEXT NOT NULL CHECK(stage IN ('accruals','provisions')),
    bank_date DATE NOT NULL, bank_timezone TEXT NOT NULL, currencies TEXT[] NOT NULL,
    evidence JSONB NOT NULL, PRIMARY KEY(bank_instance_id,period_id,stage)
);
CREATE TABLE IF NOT EXISTS accounting.monthend_interest_steps (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(), stage TEXT NOT NULL, run_id UUID NOT NULL,
    bank_instance_id UUID NOT NULL, bank_date DATE NOT NULL, bank_timezone TEXT NOT NULL,
    period_id UUID NOT NULL, readiness_id UUID NOT NULL, currencies TEXT[] NOT NULL,
    result TEXT NOT NULL CHECK(result='verified'), created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(readiness_id,stage),
    FOREIGN KEY(bank_instance_id,period_id,stage) REFERENCES accounting.monthend_interest_basis(bank_instance_id,period_id,stage)
);
CREATE TABLE IF NOT EXISTS accounting.monthend_postings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(), run_id UUID NOT NULL, bank_instance_id UUID NOT NULL,
    bank_date DATE NOT NULL, bank_timezone TEXT NOT NULL, period_id UUID NOT NULL REFERENCES accounting.accounting_periods(id),
    readiness_id UUID NOT NULL UNIQUE, currencies TEXT[] NOT NULL,
    accruals_receipt_id UUID NOT NULL REFERENCES accounting.monthend_interest_steps(id),
    provisions_receipt_id UUID NOT NULL REFERENCES accounting.monthend_interest_steps(id),
    result TEXT NOT NULL CHECK(result='posted'), additional_journal_count INTEGER NOT NULL CHECK(additional_journal_count=0),
    evidence JSONB NOT NULL, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE OR REPLACE FUNCTION accounting.guard_monthend_interest_receipt() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
    RAISE EXCEPTION 'Certified month-end savings evidence is immutable' USING ERRCODE='55000';
END;
$$;
DROP TRIGGER IF EXISTS immutable_monthend_interest_basis ON accounting.monthend_interest_basis;
CREATE TRIGGER immutable_monthend_interest_basis BEFORE UPDATE OR DELETE ON accounting.monthend_interest_basis
    FOR EACH ROW EXECUTE FUNCTION accounting.guard_monthend_interest_receipt();
DROP TRIGGER IF EXISTS immutable_monthend_interest_step ON accounting.monthend_interest_steps;
CREATE TRIGGER immutable_monthend_interest_step BEFORE UPDATE OR DELETE ON accounting.monthend_interest_steps
    FOR EACH ROW EXECUTE FUNCTION accounting.guard_monthend_interest_receipt();
DROP TRIGGER IF EXISTS immutable_monthend_posting ON accounting.monthend_postings;
CREATE TRIGGER immutable_monthend_posting BEFORE UPDATE OR DELETE ON accounting.monthend_postings
    FOR EACH ROW EXECUTE FUNCTION accounting.guard_monthend_interest_receipt();

-- A dated close certifies the published amounts, period, ID and timestamp.
ALTER TABLE accounting.daily_flash ADD COLUMN IF NOT EXISTS certified BOOLEAN NOT NULL DEFAULT false;
CREATE OR REPLACE FUNCTION accounting.guard_certified_flash() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
    IF OLD.certified AND (TG_OP = 'DELETE' OR NEW IS DISTINCT FROM OLD) THEN
        RAISE EXCEPTION 'Certified daily P&L receipt % is immutable', OLD.id;
    END IF;
    IF TG_OP = 'DELETE' THEN RETURN OLD; END IF;
    RETURN NEW;
END;
$$;
DROP TRIGGER IF EXISTS guard_certified_flash ON accounting.daily_flash;
CREATE TRIGGER guard_certified_flash BEFORE UPDATE OR DELETE ON accounting.daily_flash
    FOR EACH ROW EXECUTE FUNCTION accounting.guard_certified_flash();

-- The primary key arbitrates concurrent new imports even for older binaries
-- and direct INSERTs. Existing journals need no rewrite or uniqueness cleanup.
CREATE TABLE IF NOT EXISTS accounting.core_journal_sources (
    core_transaction_id UUID PRIMARY KEY
);

CREATE OR REPLACE FUNCTION accounting.claim_core_journal_source() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
    IF TG_OP = 'UPDATE' THEN
        IF OLD.core_transaction_id IS NOT DISTINCT FROM NEW.core_transaction_id THEN RETURN NEW; END IF;
        IF OLD.core_transaction_id IS NOT NULL THEN
            RAISE EXCEPTION 'Cannot change the source of Core journal %', OLD.id;
        END IF;
    END IF;
    IF NEW.core_transaction_id IS NULL THEN RETURN NEW; END IF;
    PERFORM pg_advisory_xact_lock(hashtextextended(NEW.core_transaction_id::text,162025));
    INSERT INTO accounting.core_journal_sources(core_transaction_id) VALUES(NEW.core_transaction_id)
        ON CONFLICT DO NOTHING;
    IF NOT FOUND OR EXISTS (SELECT 1 FROM accounting.journal_entries WHERE core_transaction_id=NEW.core_transaction_id) THEN
        RAISE EXCEPTION 'Core transaction % already has journal evidence', NEW.core_transaction_id USING ERRCODE='23505';
    END IF;
    RETURN NEW;
END;
$$;
DROP TRIGGER IF EXISTS claim_core_journal_source ON accounting.journal_entries;
CREATE TRIGGER claim_core_journal_source BEFORE INSERT OR UPDATE OF core_transaction_id ON accounting.journal_entries
    FOR EACH ROW EXECUTE FUNCTION accounting.claim_core_journal_source();

CREATE TABLE IF NOT EXISTS accounting.monthend_final_sync (
    id UUID PRIMARY KEY,
    run_id UUID NOT NULL, bank_instance_id UUID NOT NULL,
    bank_date DATE NOT NULL, bank_timezone TEXT NOT NULL,
    result JSONB NOT NULL, recorded_at TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp()
);
CREATE TABLE IF NOT EXISTS accounting.monthend_readiness (
    id UUID PRIMARY KEY,
    run_id UUID NOT NULL, bank_instance_id UUID NOT NULL,
    bank_date DATE NOT NULL, bank_timezone TEXT NOT NULL,
    period_id UUID REFERENCES accounting.accounting_periods(id),
    result TEXT NOT NULL CHECK(result IN ('ready','incomplete')),
    currencies TEXT[] NOT NULL,
    evidence JSONB NOT NULL, blockers JSONB NOT NULL,
    recorded_at TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    CHECK (result <> 'ready' OR
       (period_id IS NOT NULL AND cardinality(currencies)>0 AND blockers='[]'::jsonb))
);
CREATE INDEX IF NOT EXISTS monthend_readiness_bank_date
    ON accounting.monthend_readiness(bank_instance_id,bank_date);
CREATE OR REPLACE FUNCTION accounting.reject_monthend_receipt_change() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
    RAISE EXCEPTION 'Month-end control receipts are immutable';
END;
$$;
DROP TRIGGER IF EXISTS immutable_monthend_final_sync ON accounting.monthend_final_sync;
CREATE TRIGGER immutable_monthend_final_sync BEFORE UPDATE OR DELETE ON accounting.monthend_final_sync
    FOR EACH ROW EXECUTE FUNCTION accounting.reject_monthend_receipt_change();
DROP TRIGGER IF EXISTS immutable_monthend_readiness ON accounting.monthend_readiness;
CREATE TRIGGER immutable_monthend_readiness BEFORE UPDATE OR DELETE ON accounting.monthend_readiness
    FOR EACH ROW EXECUTE FUNCTION accounting.reject_monthend_receipt_change();

-- Seals the dated journal view used by readiness and final close. UTC rendering
-- keeps the digest independent of the client's session timezone.
CREATE OR REPLACE FUNCTION accounting.monthend_journal_digest(bank_day DATE, bank_timezone TEXT)
RETURNS TEXT LANGUAGE SQL STABLE SET TimeZone='UTC' AS $$
    SELECT encode(sha256(convert_to(COALESCE(string_agg(
        encode(sha256(convert_to(jsonb_build_array(
            e.id,e.period_id,e.reference,e.source,e.core_transaction_id,e.core_transaction_timestamp,
            e.interest_bank_date,e.posted_at,e.savings_movement,l.id,l.gl_account_code,l.currency,l.debit,l.credit,
            c.name,c.account_class,c.account_group,c.normal_side,c.is_group,c.is_active
        )::text,'UTF8')),'hex'),'' ORDER BY e.id,l.id),''),'UTF8')),'hex')
    FROM accounting.journal_entries e
    LEFT JOIN accounting.journal_lines l ON l.entry_id=e.id
    LEFT JOIN accounting.chart_of_accounts c ON c.code=l.gl_account_code
    WHERE COALESCE(e.interest_bank_date,(COALESCE(e.core_transaction_timestamp,e.posted_at) AT TIME ZONE bank_timezone)::date)<=bank_day
$$;

-- Certified monthly reports and the atomic period rollover.
CREATE TABLE IF NOT EXISTS accounting.monthend_report_steps(
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(), period_id UUID NOT NULL REFERENCES accounting.accounting_periods,
    run_id UUID NOT NULL, bank_instance_id UUID NOT NULL, bank_date DATE NOT NULL, bank_timezone TEXT NOT NULL,
    readiness_id UUID NOT NULL, posting_receipt_id UUID NOT NULL, stage TEXT NOT NULL CHECK(stage IN ('balances','statements')),
    journal_sha256 TEXT NOT NULL, evidence JSONB NOT NULL, created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE(run_id,stage)
);
CREATE TABLE IF NOT EXISTS accounting.monthend_closes(
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(), period_id UUID NOT NULL UNIQUE REFERENCES accounting.accounting_periods,
    next_period_id UUID NOT NULL REFERENCES accounting.accounting_periods,
    run_id UUID NOT NULL UNIQUE, bank_instance_id UUID NOT NULL, bank_date DATE NOT NULL UNIQUE, bank_timezone TEXT NOT NULL,
    readiness_id UUID NOT NULL, posting_receipt_id UUID NOT NULL,
    balances_receipt_id UUID NOT NULL REFERENCES accounting.monthend_report_steps,
    statements_receipt_id UUID NOT NULL REFERENCES accounting.monthend_report_steps,
    journal_sha256 TEXT NOT NULL, created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE OR REPLACE FUNCTION accounting.keep_monthend_receipt() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN RAISE EXCEPTION 'certified monthly evidence is immutable'; END $$;
CREATE OR REPLACE TRIGGER immutable_monthend_report BEFORE UPDATE OR DELETE ON accounting.monthend_report_steps
FOR EACH ROW EXECUTE FUNCTION accounting.keep_monthend_receipt();
CREATE OR REPLACE TRIGGER immutable_monthend_close BEFORE UPDATE OR DELETE ON accounting.monthend_closes
FOR EACH ROW EXECUTE FUNCTION accounting.keep_monthend_receipt();
CREATE OR REPLACE FUNCTION accounting.guard_certified_period() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
    IF OLD.status='open' AND NEW.status<>'open' AND NOT EXISTS(SELECT 1 FROM accounting.monthend_closes WHERE period_id=OLD.id) THEN
        RAISE EXCEPTION 'certified month-end evidence is required';
    END IF;
    IF EXISTS(SELECT 1 FROM accounting.monthend_closes WHERE period_id=OLD.id) AND
       (NEW.status='open' OR (NEW.year,NEW.month) IS DISTINCT FROM (OLD.year,OLD.month)) THEN
        RAISE EXCEPTION 'certified month cannot reopen or change dates';
    END IF;
    RETURN NEW;
END $$;
CREATE OR REPLACE TRIGGER guard_certified_period BEFORE UPDATE ON accounting.accounting_periods
FOR EACH ROW EXECUTE FUNCTION accounting.guard_certified_period();

CREATE OR REPLACE FUNCTION accounting.guard_monthend_journal() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE hdr accounting.journal_entries%ROWTYPE; old_hdr accounting.journal_entries%ROWTYPE;
BEGIN
    -- A shared writer lock makes the final digest and close a single boundary.
    PERFORM pg_advisory_xact_lock_shared(83032,1);
    IF TG_TABLE_NAME='journal_lines' THEN
        IF TG_OP<>'DELETE' THEN SELECT * INTO hdr FROM accounting.journal_entries WHERE id=NEW.entry_id; END IF;
        IF TG_OP<>'INSERT' THEN SELECT * INTO old_hdr FROM accounting.journal_entries WHERE id=OLD.entry_id; END IF;
    ELSE
        IF TG_OP<>'DELETE' THEN hdr := NEW; END IF;
        IF TG_OP<>'INSERT' THEN old_hdr := OLD; END IF;
    END IF;
    IF EXISTS(SELECT 1 FROM accounting.monthend_closes c
        WHERE c.period_id IN (hdr.period_id,old_hdr.period_id)
        OR COALESCE(hdr.interest_bank_date,(COALESCE(hdr.core_transaction_timestamp,hdr.posted_at) AT TIME ZONE c.bank_timezone)::date)<=c.bank_date
        OR COALESCE(old_hdr.interest_bank_date,(COALESCE(old_hdr.core_transaction_timestamp,old_hdr.posted_at) AT TIME ZONE c.bank_timezone)::date)<=c.bank_date)
    THEN RAISE EXCEPTION 'certified bank month cannot receive or change journal movements'; END IF;
    IF TG_OP='DELETE' THEN RETURN OLD; END IF;
    RETURN NEW;
END $$;
CREATE OR REPLACE TRIGGER guard_monthend_headers BEFORE INSERT OR UPDATE OR DELETE ON accounting.journal_entries
FOR EACH ROW EXECUTE FUNCTION accounting.guard_monthend_journal();
CREATE OR REPLACE TRIGGER guard_monthend_lines BEFORE INSERT OR UPDATE OR DELETE ON accounting.journal_lines
FOR EACH ROW EXECUTE FUNCTION accounting.guard_monthend_journal();
CREATE OR REPLACE TRIGGER protect_certified_statements BEFORE UPDATE OR DELETE ON accounting.period_snapshots
FOR EACH ROW WHEN (OLD.report_data ? 'journal_sha256') EXECUTE FUNCTION accounting.keep_monthend_receipt();

-- Distinct current-deposit liability for the two configured demand products.
-- Untagged historical entries retain their original classifications.
INSERT INTO accounting.gl_mappings(id,name,core_account_type,core_account_subtype,currency,posting_side,gl_account_code,priority)
SELECT md5('current-deposit-v1:'||role||':'||ccy||':'||side)::uuid,
       'Current deposit '||role||' '||ccy||' '||side,'customer',role,ccy,side,'2300',20
FROM (VALUES ('current_principal'),('current_interest_capital')) r(role)
CROSS JOIN (VALUES ('NOK'),('BRG')) c(ccy) CROSS JOIN (VALUES ('debit'),('credit')) s(side)
ON CONFLICT(id) DO NOTHING;

-- Proven reservation hold/release legs are memorandum items outside the
-- balance sheet and earnings. Bragd correspondent cash is a distinct asset.
INSERT INTO accounting.chart_of_accounts(code,name,account_class,normal_side,is_group)
VALUES ('9901','Reservert betalingsbeløp',9,'debit',false),
       ('9902','Motpost betalingsreservasjon',9,'credit',false)
ON CONFLICT(code) DO NOTHING;
INSERT INTO accounting.gl_mappings(id,name,core_account_type,core_account_subtype,currency,posting_side,gl_account_code,priority)
SELECT md5('verified-deposit-legs-v1:'||role||':'||ccy||':'||side)::uuid,
       'Verified deposit leg '||role||' '||ccy||' '||side,kind,role,ccy,side,code,20
FROM (VALUES ('nostro','deposit_nostro_bragd','1930'),('sub_account','reservation_hold','9901'),
             ('general_ledger','reservation_control','9902')) r(kind,role,code)
CROSS JOIN (VALUES ('NOK'),('BRG')) c(ccy) CROSS JOIN (VALUES ('debit'),('credit')) s(side)
ON CONFLICT(id) DO NOTHING;

-- Each bank database can cross the prospective deposit boundary once.
CREATE TABLE IF NOT EXISTS accounting.deposit_openings(
 singleton boolean PRIMARY KEY DEFAULT true CHECK(singleton),
 id uuid UNIQUE NOT NULL, bank_instance_id uuid NOT NULL, first_bank_date date NOT NULL,
 bank_timezone text NOT NULL, cutoff_at timestamptz NOT NULL, sha256 text NOT NULL,
 approved_by text NOT NULL, evidence jsonb NOT NULL, booked_entries uuid[] NOT NULL,
 approved_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS accounting.deposit_opening_sources(
 core_transaction_id uuid PRIMARY KEY, opening_id uuid NOT NULL REFERENCES accounting.deposit_openings(id)
);
CREATE OR REPLACE TRIGGER keep_deposit_opening BEFORE UPDATE OR DELETE ON accounting.deposit_openings
FOR EACH ROW EXECUTE FUNCTION accounting.keep_monthend_receipt();
CREATE OR REPLACE TRIGGER keep_deposit_opening_source BEFORE UPDATE OR DELETE ON accounting.deposit_opening_sources
FOR EACH ROW EXECUTE FUNCTION accounting.keep_monthend_receipt();

CREATE OR REPLACE FUNCTION accounting.protect_deposit_opening() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE o accounting.deposit_openings%ROWTYPE; ids uuid[];
BEGIN
    SELECT * INTO o FROM accounting.deposit_openings WHERE singleton;
    IF FOUND THEN
        IF TG_TABLE_NAME='journal_entries' THEN
            IF TG_OP<>'INSERT' AND (OLD.id=ANY(o.booked_entries) OR EXISTS(SELECT 1 FROM accounting.deposit_opening_sources s WHERE s.core_transaction_id=OLD.core_transaction_id)) THEN
                RAISE EXCEPTION 'sealed original or opening journal %',OLD.id;
            END IF;
            IF TG_OP<>'DELETE' AND (NEW.source='deposit_opening' OR EXISTS(SELECT 1 FROM accounting.deposit_opening_sources s WHERE s.core_transaction_id=NEW.core_transaction_id)
                    OR coalesce(NEW.core_transaction_timestamp,NEW.posted_at)<o.cutoff_at OR NEW.interest_bank_date<o.first_bank_date) THEN
                RAISE EXCEPTION 'new or changed journal crosses certified opening';
            END IF;
        ELSE
            ids:=CASE TG_OP WHEN 'INSERT' THEN ARRAY[NEW.entry_id] WHEN 'DELETE' THEN ARRAY[OLD.entry_id] ELSE ARRAY[OLD.entry_id,NEW.entry_id] END;
            IF EXISTS(SELECT 1 FROM accounting.journal_entries j WHERE j.id=ANY(ids) AND (j.id=ANY(o.booked_entries) OR EXISTS(SELECT 1 FROM accounting.deposit_opening_sources s WHERE s.core_transaction_id=j.core_transaction_id))) THEN
                RAISE EXCEPTION 'sealed original or opening lines';
            END IF;
        END IF;
    END IF;
    IF TG_OP='DELETE' THEN RETURN OLD; END IF;
    RETURN NEW;
END $$;
CREATE OR REPLACE TRIGGER protect_opening_headers BEFORE INSERT OR UPDATE OR DELETE ON accounting.journal_entries
FOR EACH ROW EXECUTE FUNCTION accounting.protect_deposit_opening();
CREATE OR REPLACE TRIGGER protect_opening_lines BEFORE INSERT OR UPDATE OR DELETE ON accounting.journal_lines
FOR EACH ROW EXECUTE FUNCTION accounting.protect_deposit_opening();

DO $$ BEGIN
 IF EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid='accounting.journal_entries'::regclass AND conname='journal_entries_source_check' AND pg_get_constraintdef(oid) NOT LIKE '%deposit_opening%') THEN
    ALTER TABLE accounting.journal_entries DROP CONSTRAINT journal_entries_source_check;
    ALTER TABLE accounting.journal_entries ADD CONSTRAINT journal_entries_source_check CHECK(source IN ('manual','sync','closing','deposit_opening'));
 END IF;
END $$;
