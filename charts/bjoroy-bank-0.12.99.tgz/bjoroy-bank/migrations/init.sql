-- Banking platform schema baseline.
-- Each service gets its own schema for logical separation.
--
-- NOTE: Database creation is handled by the setup job (job-setup.yaml)
-- with instance-scoped names. This script only manages schemas and tables
-- within the bank database.

-- ============================================================
-- EXTENSIONS
-- ============================================================

CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE EXTENSION IF NOT EXISTS btree_gist;

-- ============================================================
-- SCHEMAS
-- ============================================================

CREATE SCHEMA IF NOT EXISTS core;
CREATE SCHEMA IF NOT EXISTS payments;
CREATE SCHEMA IF NOT EXISTS channels;
CREATE SCHEMA IF NOT EXISTS admin;

-- ============================================================
-- CORE SCHEMA
-- ============================================================

-- Banking institutions (BIC registry)
CREATE TABLE IF NOT EXISTS core.banking_institutions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    bic VARCHAR(11) NOT NULL UNIQUE,           -- ISO 9362 BIC (8 or 11 chars)
    name VARCHAR(255) NOT NULL,
    country_code VARCHAR(2) NOT NULL DEFAULT 'NO',
    is_own BOOLEAN NOT NULL DEFAULT false,      -- true = this is our bank
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Institution prefixes — generic routing/identification codes assigned to an institution.
-- Covers Norwegian bank registration numbers (BKREG, 4-digit), EMV BINs (BIN, 6-8 digit),
-- SWIFT routing codes, and any future prefix scheme.
-- Each prefix carries JSONB tags for metadata (brand, usage, etc.).
-- Norwegian: "registreringsnummer" / "bankregnummer".
CREATE TABLE IF NOT EXISTS core.institution_prefixes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    institution_id UUID NOT NULL REFERENCES core.banking_institutions(id),
    prefix_type VARCHAR(10) NOT NULL,           -- BKREG, BIN, SWIFT, etc.
    prefix_value VARCHAR(20) NOT NULL,          -- e.g. '3688', '45717360'
    tags JSONB NOT NULL DEFAULT '[]',           -- metadata: [{"brand":"Bjorøy Bank"},{"usage":"current"}]
    status VARCHAR(20) NOT NULL DEFAULT 'active',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT chk_prefix_type CHECK (prefix_type IN ('BKREG', 'BIN', 'SWIFT')),
    UNIQUE (prefix_type, prefix_value)
);

-- Account number series (BBAN ranges managed by a bank)
CREATE TABLE IF NOT EXISTS core.account_number_series (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    institution_id UUID NOT NULL REFERENCES core.banking_institutions(id),
    prefix_id UUID REFERENCES core.institution_prefixes(id), -- link to registered prefix
    name VARCHAR(100) NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    bank_reg_number VARCHAR(4) NOT NULL,       -- Norwegian: 4-digit bank registration number
    range_start INT NOT NULL,                  -- Start of 6-digit range (e.g. 110000)
    range_end INT NOT NULL,                    -- End of 6-digit range   (e.g. 112999)
    next_number INT NOT NULL,                  -- Next number to allocate from this series
    country_code VARCHAR(2) NOT NULL DEFAULT 'NO',
    currency VARCHAR(3) NOT NULL DEFAULT 'NOK',
    status VARCHAR(20) NOT NULL DEFAULT 'active',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT chk_range CHECK (range_start <= range_end),
    CONSTRAINT chk_next CHECK (next_number >= range_start AND next_number <= range_end + 1)
);

-- Prevent overlapping account number series for the same prefix.
-- Uses an exclusion constraint with int4range to block overlapping ranges.
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint WHERE conname = 'excl_series_range_overlap'
    ) THEN
        ALTER TABLE core.account_number_series
            ADD CONSTRAINT excl_series_range_overlap
            EXCLUDE USING gist (
                prefix_id WITH =,
                int4range(range_start, range_end, '[]') WITH &&
            ) WHERE (status = 'active');
    END IF;
END
$$;

-- Account numbers (allocated BBANs with lifecycle tracking)
-- States: reserved → active → deleted
-- Transitions: reserved→active, reserved→unused (delete row), active→deleted
-- Deleted numbers cannot be reused for 10 years.
CREATE TABLE IF NOT EXISTS core.account_numbers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    series_id UUID NOT NULL REFERENCES core.account_number_series(id),
    bban VARCHAR(11) NOT NULL UNIQUE,          -- Full 11-digit BBAN (bank_reg + 6 digits + check)
    iban VARCHAR(15) NOT NULL UNIQUE,          -- Calculated: NOkk + BBAN
    status VARCHAR(20) NOT NULL DEFAULT 'reserved',
    reserved_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    activated_at TIMESTAMPTZ,
    deleted_at TIMESTAMPTZ,
    CONSTRAINT chk_account_number_status CHECK (status IN ('reserved', 'active', 'deleted'))
);

-- Ledger accounts (internal bookkeeping unit)
-- Sub-account hierarchy: parent_account_id links sub-accounts to their parent.
CREATE TABLE IF NOT EXISTS core.ledger_accounts (
    id UUID PRIMARY KEY,
    account_type VARCHAR(20) NOT NULL,
    currency VARCHAR(3) NOT NULL DEFAULT 'NOK',
    parent_account_id UUID REFERENCES core.ledger_accounts(id),
    account_subtype VARCHAR(40),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_ledger_accounts_parent
    ON core.ledger_accounts (parent_account_id)
    WHERE parent_account_id IS NOT NULL;

-- Transactions (groups postings)
CREATE TABLE IF NOT EXISTS core.transactions (
    id UUID PRIMARY KEY,
    reference VARCHAR(255) NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    timestamp TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Postings (individual debit/credit entries)
-- Positive = debit, negative = credit
CREATE TABLE IF NOT EXISTS core.postings (
    id UUID PRIMARY KEY,
    transaction_id UUID NOT NULL REFERENCES core.transactions(id),
    account_id UUID NOT NULL REFERENCES core.ledger_accounts(id),
    amount NUMERIC(19, 4) NOT NULL,
    currency VARCHAR(3) NOT NULL DEFAULT 'NOK'
);

-- Enforce double-entry: every transaction's postings must sum to zero.
-- This is checked via a trigger rather than a check constraint,
-- because the constraint must span multiple rows.
CREATE OR REPLACE FUNCTION core.check_transaction_balance()
RETURNS TRIGGER AS $$
BEGIN
    IF (SELECT COALESCE(SUM(amount), 0) FROM core.postings WHERE transaction_id = NEW.transaction_id) != 0 THEN
        RAISE EXCEPTION 'Transaction % postings do not balance to zero', NEW.transaction_id;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Note: This trigger fires per-statement after all postings for a batch insert.
-- For row-level inserts, balance is validated in application logic before commit.
DROP TRIGGER IF EXISTS trg_check_balance ON core.postings;
CREATE CONSTRAINT TRIGGER trg_check_balance
    AFTER INSERT ON core.postings
    DEFERRABLE INITIALLY DEFERRED
    FOR EACH ROW
    EXECUTE FUNCTION core.check_transaction_balance();

-- Products catalog
CREATE TABLE IF NOT EXISTS core.products (
    id UUID PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    product_type VARCHAR(20) NOT NULL,
    default_currency VARCHAR(3) NOT NULL DEFAULT 'NOK',
    default_interest_rate NUMERIC(8, 6) NOT NULL,
    default_account_number_series_id UUID REFERENCES core.account_number_series(id)
);

CREATE UNIQUE INDEX IF NOT EXISTS uq_product_name
    ON core.products (name);

-- Versioned product definitions loaded from OCI artifacts.
CREATE TABLE IF NOT EXISTS core.product_definitions (
    id UUID PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    version VARCHAR(20) NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    product_type VARCHAR(30) NOT NULL,
    base_currency VARCHAR(3) NOT NULL DEFAULT 'NOK',
    spec JSONB NOT NULL DEFAULT '{}',
    status VARCHAR(20) NOT NULL DEFAULT 'active',
    validation_result JSONB,
    loaded_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (name, version)
);

CREATE INDEX IF NOT EXISTS idx_product_definitions_name ON core.product_definitions (name);

-- KYC policy requirements per product definition + role.
-- Defines what KYC evidence is needed before granting access.
CREATE TABLE IF NOT EXISTS core.product_kyc_policies (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    definition_name     VARCHAR(100) NOT NULL,
    role                VARCHAR(50) NOT NULL,
    required_attributes JSONB NOT NULL,
    created_at          TIMESTAMPTZ DEFAULT now(),
    UNIQUE (definition_name, role)
);

-- Arrangements (metadata → ledger account link)
-- product_id is kept for backward compatibility but no longer required;
-- new arrangements are created from definition_name alone.
-- customer_id references the customer-master service (no local FK).
CREATE TABLE IF NOT EXISTS core.arrangements (
    id UUID PRIMARY KEY,
    ledger_account_id UUID NOT NULL REFERENCES core.ledger_accounts(id),
    product_id UUID,                            -- deprecated: use definition_name instead
    customer_id UUID NOT NULL,                  -- references customer-master service (no local FK)
    name VARCHAR(255) NOT NULL,
    currency VARCHAR(3) NOT NULL DEFAULT 'NOK',
    status VARCHAR(20) NOT NULL DEFAULT 'active',
    definition_name VARCHAR(100),
    definition_version VARCHAR(20),
    lifecycle_state VARCHAR(30) DEFAULT 'active',
    policy_overrides JSONB,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- A pending key and its balanced transaction commit together. The deferred
-- reference allows the key to be claimed before creating any ledger entries.
CREATE TABLE IF NOT EXISTS core.interest_postings (
    arrangement_id UUID NOT NULL REFERENCES core.arrangements(id),
    bank_date DATE NOT NULL,
    interest_type TEXT NOT NULL,
    transaction_id UUID NOT NULL UNIQUE REFERENCES core.transactions(id) DEFERRABLE INITIALLY DEFERRED,
    ledger_account_id UUID NOT NULL REFERENCES core.ledger_accounts(id),
    amount NUMERIC(19,4) NOT NULL,
    currency VARCHAR(3) NOT NULL,
    PRIMARY KEY (arrangement_id, bank_date, interest_type)
);

CREATE INDEX IF NOT EXISTS idx_arrangements_name_lower
    ON core.arrangements (LOWER(name));
CREATE INDEX IF NOT EXISTS idx_arrangements_customer_id
    ON core.arrangements (customer_id);
CREATE INDEX IF NOT EXISTS idx_arrangements_product_id
    ON core.arrangements (product_id);
CREATE INDEX IF NOT EXISTS idx_arrangements_status
    ON core.arrangements (status);
CREATE INDEX IF NOT EXISTS idx_arrangements_currency
    ON core.arrangements (currency);
CREATE INDEX IF NOT EXISTS idx_arrangements_created_at
    ON core.arrangements (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_arrangements_customer_status
    ON core.arrangements (customer_id, status)
    WHERE status = 'active';
CREATE INDEX IF NOT EXISTS idx_arrangements_definition
    ON core.arrangements (definition_name, definition_version);

-- Earliest instant for which today's pinned inputs can be established.
-- Existing rows begin at migration, never at an inferred historical date.
ALTER TABLE core.arrangements ADD COLUMN IF NOT EXISTS interest_inputs_since
    TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE core.product_definitions ADD COLUMN IF NOT EXISTS interest_inputs_since
    TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP;

-- Capture only observed changes. No history is reconstructed before the
-- verification boundary established when these columns were introduced.
CREATE TABLE IF NOT EXISTS core.interest_arrangement_history (
    arrangement_id UUID NOT NULL,
    ledger_account_id UUID NOT NULL,
    product_id UUID,
    currency VARCHAR(3) NOT NULL,
    status VARCHAR(20) NOT NULL,
    lifecycle_state VARCHAR(30),
    definition_name VARCHAR(100),
    definition_version VARCHAR(20),
    policy_overrides JSONB,
    created_at TIMESTAMPTZ NOT NULL,
    valid_from TIMESTAMPTZ NOT NULL,
    valid_until TIMESTAMPTZ NOT NULL CHECK (valid_until > valid_from),
    PRIMARY KEY (arrangement_id, valid_from)
);
CREATE TABLE IF NOT EXISTS core.interest_definition_history (
    id UUID NOT NULL,
    name VARCHAR(100) NOT NULL,
    version VARCHAR(20) NOT NULL,
    product_type VARCHAR(30) NOT NULL,
    base_currency VARCHAR(3) NOT NULL,
    spec JSONB NOT NULL,
    loaded_at TIMESTAMPTZ NOT NULL,
    valid_from TIMESTAMPTZ NOT NULL,
    valid_until TIMESTAMPTZ NOT NULL CHECK (valid_until > valid_from),
    PRIMARY KEY (id, valid_from)
);
CREATE INDEX IF NOT EXISTS interest_definition_history_lookup
    ON core.interest_definition_history(name, version, valid_from);

CREATE OR REPLACE FUNCTION core.touch_interest_inputs() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE changed_at timestamptz := clock_timestamp();
BEGIN
    IF changed_at > OLD.interest_inputs_since THEN
        IF TG_TABLE_NAME = 'arrangements' THEN
            INSERT INTO core.interest_arrangement_history VALUES
                (OLD.id, OLD.ledger_account_id, OLD.product_id, OLD.currency, OLD.status,
                 OLD.lifecycle_state, OLD.definition_name, OLD.definition_version,
                 OLD.policy_overrides, OLD.created_at, OLD.interest_inputs_since, changed_at);
        ELSE
            INSERT INTO core.interest_definition_history VALUES
                (OLD.id, OLD.name, OLD.version, OLD.product_type, OLD.base_currency,
                 OLD.spec, OLD.loaded_at, OLD.interest_inputs_since, changed_at);
        END IF;
    END IF;
    IF TG_OP = 'DELETE' THEN RETURN OLD; END IF;
    NEW.interest_inputs_since = GREATEST(changed_at, OLD.interest_inputs_since);
    RETURN NEW;
END;
$$;

CREATE OR REPLACE VIEW core.interest_arrangement_versions AS
    SELECT id AS arrangement_id, ledger_account_id, product_id, currency, status, lifecycle_state,
           definition_name, definition_version, policy_overrides, created_at,
           interest_inputs_since AS valid_from, NULL::timestamptz AS valid_until
    FROM core.arrangements
    UNION ALL SELECT * FROM core.interest_arrangement_history;
CREATE OR REPLACE VIEW core.interest_definition_versions AS
    SELECT id, name, version, product_type, base_currency, spec, loaded_at,
           interest_inputs_since AS valid_from, NULL::timestamptz AS valid_until
    FROM core.product_definitions
    UNION ALL SELECT * FROM core.interest_definition_history;

DROP TRIGGER IF EXISTS archive_deleted_interest_arrangement ON core.arrangements;
CREATE TRIGGER archive_deleted_interest_arrangement BEFORE DELETE ON core.arrangements
    FOR EACH ROW EXECUTE FUNCTION core.touch_interest_inputs();
DROP TRIGGER IF EXISTS archive_deleted_interest_definition ON core.product_definitions;
CREATE TRIGGER archive_deleted_interest_definition BEFORE DELETE ON core.product_definitions
    FOR EACH ROW EXECUTE FUNCTION core.touch_interest_inputs();
DROP TRIGGER IF EXISTS arrangement_interest_inputs_changed ON core.arrangements;
CREATE TRIGGER arrangement_interest_inputs_changed BEFORE UPDATE ON core.arrangements
    FOR EACH ROW WHEN (
        (OLD.ledger_account_id, OLD.product_id, OLD.currency, OLD.status, OLD.lifecycle_state, OLD.definition_name,
         OLD.definition_version, OLD.policy_overrides->'interest') IS DISTINCT FROM
        (NEW.ledger_account_id, NEW.product_id, NEW.currency, NEW.status, NEW.lifecycle_state, NEW.definition_name,
         NEW.definition_version, NEW.policy_overrides->'interest'))
    EXECUTE FUNCTION core.touch_interest_inputs();
DROP TRIGGER IF EXISTS definition_interest_inputs_changed ON core.product_definitions;
CREATE TRIGGER definition_interest_inputs_changed BEFORE UPDATE ON core.product_definitions
    FOR EACH ROW WHEN (
        (OLD.name, OLD.version, OLD.spec, OLD.base_currency, OLD.product_type) IS DISTINCT FROM
        (NEW.name, NEW.version, NEW.spec, NEW.base_currency, NEW.product_type))
    EXECUTE FUNCTION core.touch_interest_inputs();

-- Freeze one exact successful input/output per account agreement and bank day.
CREATE TABLE IF NOT EXISTS core.daily_interest_basis (
    arrangement_id UUID NOT NULL REFERENCES core.arrangements(id),
    bank_date DATE NOT NULL,
    ledger_account_id UUID NOT NULL REFERENCES core.ledger_accounts(id),
    currency VARCHAR(3) NOT NULL,
    result TEXT NOT NULL CHECK (result IN ('calculated', 'zero', 'no_interest')),
    numerator NUMERIC NOT NULL CHECK (numerator >= 0),
    denominator INTEGER NOT NULL CHECK (denominator > 0),
    basis JSONB NOT NULL,
    recorded_at TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    PRIMARY KEY (arrangement_id, bank_date),
    CHECK ((result = 'calculated') = (numerator > 0)),
    CHECK ((basis->>'calculation_result' = result
        AND (basis #>> '{daily_calculation,arrangement_id}')::uuid = arrangement_id
        AND (basis #>> '{daily_calculation,bank_date}')::date = bank_date
        AND (basis #>> '{daily_calculation,ledger_account_id}')::uuid = ledger_account_id
        AND basis #>> '{daily_calculation,currency}' = currency
        AND (basis #>> '{daily_calculation,numerator}')::numeric = numerator
        AND (basis #>> '{daily_calculation,denominator}')::integer = denominator) IS TRUE)
);
CREATE OR REPLACE FUNCTION core.reject_daily_interest_basis_change() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
    RAISE EXCEPTION 'Recorded % row cannot be changed', TG_TABLE_NAME USING ERRCODE = '55000';
END;
$$;
DROP TRIGGER IF EXISTS immutable_daily_interest_basis ON core.daily_interest_basis;
CREATE TRIGGER immutable_daily_interest_basis BEFORE UPDATE OR DELETE ON core.daily_interest_basis
    FOR EACH ROW EXECUTE FUNCTION core.reject_daily_interest_basis_change();

DROP TRIGGER IF EXISTS immutable_interest_arrangement_history ON core.interest_arrangement_history;
CREATE TRIGGER immutable_interest_arrangement_history BEFORE UPDATE OR DELETE ON core.interest_arrangement_history
    FOR EACH ROW EXECUTE FUNCTION core.reject_daily_interest_basis_change();
DROP TRIGGER IF EXISTS immutable_interest_definition_history ON core.interest_definition_history;
CREATE TRIGGER immutable_interest_definition_history BEFORE UPDATE OR DELETE ON core.interest_definition_history
    FOR EACH ROW EXECUTE FUNCTION core.reject_daily_interest_basis_change();

-- A retry of the same account-opening node returns its original agreement.
CREATE TABLE IF NOT EXISTS core.arrangement_opening_receipts (
    instance_id UUID NOT NULL,
    node_id TEXT NOT NULL,
    arrangement_id UUID NOT NULL UNIQUE REFERENCES core.arrangements(id) DEFERRABLE INITIALLY DEFERRED,
    request JSONB NOT NULL,
    PRIMARY KEY (instance_id,node_id)
);

-- Mandates (user ↔ account permissions)
CREATE TABLE IF NOT EXISTS core.mandates (
    id UUID PRIMARY KEY,
    user_subject VARCHAR(255) NOT NULL,
    arrangement_id UUID NOT NULL REFERENCES core.arrangements(id),
    permissions JSONB NOT NULL DEFAULT '["view"]'
);

-- Company mandates (company ↔ account permissions, with signatory rules)
CREATE TABLE IF NOT EXISTS core.company_mandates (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_customer_id UUID NOT NULL,              -- customer ID from customer-master (entity_type='company')
    arrangement_id UUID NOT NULL REFERENCES core.arrangements(id),
    signatory_rules JSONB NOT NULL DEFAULT '{"min_signatories": 1}',
    permissions JSONB NOT NULL DEFAULT '["view"]',
    status VARCHAR(30) NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'suspended', 'revoked')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (company_customer_id, arrangement_id)
);
CREATE INDEX IF NOT EXISTS idx_company_mandates_company
    ON core.company_mandates(company_customer_id);
CREATE INDEX IF NOT EXISTS idx_company_mandates_arrangement
    ON core.company_mandates(arrangement_id);

-- Company user mandates (person's role within a company mandate)
CREATE TABLE IF NOT EXISTS core.company_user_mandates (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_mandate_id UUID NOT NULL REFERENCES core.company_mandates(id) ON DELETE CASCADE,
    person_id UUID NOT NULL,                         -- internal person ID from customer-master
    role VARCHAR(50) NOT NULL CHECK (role IN ('viewer', 'initiator', 'approver', 'admin')),
    amount_limit NUMERIC(18,4) CHECK (amount_limit IS NULL OR amount_limit >= 0),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (company_mandate_id, person_id)
);
CREATE INDEX IF NOT EXISTS idx_company_user_mandates_person
    ON core.company_user_mandates(person_id);

-- API clients for M2M access (bound to company)
CREATE TABLE IF NOT EXISTS core.api_clients (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_customer_id UUID NOT NULL,               -- which company owns this client
    client_id VARCHAR(255) NOT NULL UNIQUE,           -- OAuth2 client_id in Authentik
    name VARCHAR(255) NOT NULL,
    scopes TEXT[] NOT NULL DEFAULT '{}',
    status VARCHAR(50) NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'suspended', 'revoked')),
    created_by_person_id UUID NOT NULL,               -- person who registered (audit trail)
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    revoked_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_api_clients_company
    ON core.api_clients(company_customer_id);

-- Account identifiers (ISO 20022 — multiple identifiers per arrangement)
-- identifier_type follows ISO 20022 ExternalAccountIdentification1Code
-- and ExternalProxyAccountType1Code
CREATE TABLE IF NOT EXISTS core.account_identifiers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    arrangement_id UUID NOT NULL REFERENCES core.arrangements(id) ON DELETE CASCADE,
    identifier_type VARCHAR(4) NOT NULL,        -- IBAN, BBAN, TELE, EMAL, DNAM, etc.
    identifier_value VARCHAR(255) NOT NULL,
    is_primary BOOLEAN NOT NULL DEFAULT false,  -- primary identifier for this type
    account_number_id UUID REFERENCES core.account_numbers(id), -- link to account_numbers for IBAN/BBAN
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT chk_identifier_type CHECK (identifier_type IN (
        'IBAN', 'BBAN',                        -- Account identification codes
        'TELE', 'EMAL', 'DNAM',               -- Proxy/alias codes
        'SHID', 'ORGN', 'NIDN'                -- Other proxy codes
    )),
    UNIQUE (identifier_type, identifier_value)  -- no two arrangements share the same identifier
);

-- Only one primary identifier per type per arrangement.
-- Prevents an arrangement from accumulating multiple primary IBANs.
CREATE UNIQUE INDEX IF NOT EXISTS uq_primary_identifier_per_type
    ON core.account_identifiers (arrangement_id, identifier_type)
    WHERE is_primary = true;

CREATE INDEX IF NOT EXISTS idx_account_identifiers_value_lower
    ON core.account_identifiers (LOWER(identifier_value));

-- Pricing rules
CREATE TABLE IF NOT EXISTS core.pricing_rules (
    id UUID PRIMARY KEY,
    product_id UUID REFERENCES core.products(id),
    arrangement_id UUID REFERENCES core.arrangements(id),
    rule_type VARCHAR(20) NOT NULL,
    config JSONB NOT NULL DEFAULT '{}'
);

-- ============================================================
-- PAYMENTS SCHEMA
-- ============================================================

-- Payment orders
-- Identifier columns (debtor_identifier, creditor_identifier) hold IBAN, BBAN,
-- or ISO 20022 proxy values (DNAM, TELE, EMAL, etc.).
-- Resolution to IBAN happens in the Heart process.
CREATE TABLE IF NOT EXISTS payments.payment_orders (
    id UUID PRIMARY KEY,
    debtor_account_id UUID,
    creditor_account_id UUID,
    amount NUMERIC(19, 4) NOT NULL,
    currency VARCHAR(3) NOT NULL DEFAULT 'NOK',
    status VARCHAR(20) NOT NULL DEFAULT 'RCVD',
    reference VARCHAR(255),
    payment_type VARCHAR(20) NOT NULL DEFAULT 'immediate',
    requested_execution_date DATE,
    end_to_end_id VARCHAR(255),
    debtor_identifier VARCHAR(34),
    creditor_identifier VARCHAR(34),
    debtor_identifier_type VARCHAR(4),          -- ExternalProxyAccountType1Code
    creditor_identifier_type VARCHAR(4),        -- ExternalProxyAccountType1Code
    creditor_name VARCHAR(255),
    debtor_name VARCHAR(255),
    description TEXT,
    initiator_subject VARCHAR(255),
    initiator_customer_id UUID,
    is_internal BOOLEAN NOT NULL DEFAULT false,
    sca_exempt BOOLEAN,
    sca_exemption_reason VARCHAR(100),
    heart_process_id UUID,
    heart_execution_process_id UUID,
    pending_work_item_id UUID,
    standing_order_id UUID,
    sca_proof_id UUID,
    rejection_reason VARCHAR(255),
    reserve_immediately BOOLEAN NOT NULL DEFAULT false,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ISO 20022-inspired messages (stored as JSON)
CREATE TABLE IF NOT EXISTS payments.iso_messages (
    id UUID PRIMARY KEY,
    payment_order_id UUID REFERENCES payments.payment_orders(id),
    message_type VARCHAR(20) NOT NULL,
    direction VARCHAR(10) NOT NULL,
    payload JSONB NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- SCA authorisations — generic table for payment and consent authorisation.
-- resource_type + resource_id point to the thing being authorised (e.g. 'payment' + payment_order.id).
-- Reusable for any BG authorisation sub-resource.
CREATE TABLE IF NOT EXISTS payments.payment_authorisations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    resource_type VARCHAR(30) NOT NULL DEFAULT 'payment',
    resource_id UUID NOT NULL,
    sca_status VARCHAR(30) NOT NULL DEFAULT 'received',
    user_subject VARCHAR(255),
    resource_data JSONB,                       -- structured data for SCA display (amount, IBANs, etc.)
    resource_data_hash VARCHAR(64),             -- SHA-256 hash of resource_data at creation (tamper detection)
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_authorisations_resource
    ON payments.payment_authorisations (resource_type, resource_id);

-- SCA proofs — cryptographically signed attestation of SCA completion.
CREATE TABLE IF NOT EXISTS payments.sca_proofs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    authorisation_id UUID NOT NULL REFERENCES payments.payment_authorisations(id),
    payload JSONB NOT NULL,
    signature VARCHAR(128) NOT NULL,
    public_key VARCHAR(64) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_sca_proofs_authorisation ON payments.sca_proofs (authorisation_id);

-- Standing orders — recurring payments
-- Identifier columns use the generalised naming (debtor_identifier, creditor_identifier)
-- to support IBAN, BBAN, or ISO 20022 proxy values.
CREATE TABLE IF NOT EXISTS payments.standing_orders (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    customer_id UUID NOT NULL,
    debtor_account_id UUID NOT NULL,
    debtor_identifier VARCHAR(34) NOT NULL,
    creditor_identifier VARCHAR(34) NOT NULL,
    creditor_name VARCHAR(255) NOT NULL,
    amount NUMERIC(19, 4) NOT NULL,
    currency VARCHAR(3) NOT NULL DEFAULT 'NOK',
    description TEXT,
    display_name VARCHAR(70),
    frequency VARCHAR(20) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE,
    next_execution_date DATE NOT NULL,
    day_of_execution VARCHAR(2),
    execution_rule VARCHAR(20) NOT NULL DEFAULT 'following',
    status VARCHAR(20) NOT NULL DEFAULT 'received',
    last_execution_date DATE,
    execution_count INTEGER NOT NULL DEFAULT 0,
    max_executions INTEGER,
    lead_days INTEGER NOT NULL DEFAULT 0,
    sca_exempt BOOLEAN,
    sca_exemption_reason VARCHAR(100),
    pending_work_item_id UUID,
    heart_process_id UUID,
    last_failure_reason TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_standing_orders_next ON payments.standing_orders (next_execution_date)
    WHERE status = 'active';
CREATE INDEX IF NOT EXISTS idx_standing_orders_customer ON payments.standing_orders (customer_id);

-- Reservations — tracks blocked funds on sub-accounts
CREATE TABLE IF NOT EXISTS core.reservations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    sub_account_id UUID NOT NULL REFERENCES core.ledger_accounts(id),
    payment_order_id UUID NOT NULL REFERENCES payments.payment_orders(id),
    amount NUMERIC(19, 4) NOT NULL,
    currency VARCHAR(3) NOT NULL DEFAULT 'NOK',
    status VARCHAR(20) NOT NULL DEFAULT 'active',
    posting_id UUID REFERENCES core.postings(id),
    release_posting_id UUID REFERENCES core.postings(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at TIMESTAMPTZ,
    settled_at TIMESTAMPTZ,
    CONSTRAINT chk_reservation_status CHECK (status IN ('active', 'settled', 'released', 'expired'))
);

CREATE INDEX IF NOT EXISTS idx_reservations_sub_account
    ON core.reservations (sub_account_id)
    WHERE status = 'active';
CREATE INDEX IF NOT EXISTS idx_reservations_payment_order
    ON core.reservations (payment_order_id);

-- ============================================================
-- CHANNELS SCHEMA
-- ============================================================

-- Consents (BG OpenFinance)
CREATE TABLE IF NOT EXISTS channels.consents (
    id UUID PRIMARY KEY,
    user_subject VARCHAR(255) NOT NULL,
    consent_type VARCHAR(30) NOT NULL DEFAULT 'account-access',
    status VARCHAR(30) NOT NULL DEFAULT 'received',
    access JSONB NOT NULL DEFAULT '{}',
    valid_until TIMESTAMPTZ,
    frequency_per_day INT NOT NULL DEFAULT 4,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- User profiles (OIDC sub ↔ customer mapping)
CREATE TABLE IF NOT EXISTS channels.user_profiles (
    id UUID PRIMARY KEY,
    user_subject VARCHAR(255) NOT NULL UNIQUE,
    customer_id UUID NOT NULL,
    display_name VARCHAR(255),
    settings JSONB NOT NULL DEFAULT '{}',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Saved recipients (per customer)
CREATE TABLE IF NOT EXISTS channels.saved_recipients (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    customer_id UUID NOT NULL,
    short_id VARCHAR(4) NOT NULL,
    short_name VARCHAR(50) NOT NULL,
    full_name VARCHAR(255) NOT NULL,
    account_number VARCHAR(34) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (customer_id, short_id)
);

CREATE INDEX IF NOT EXISTS idx_saved_recipients_customer
    ON channels.saved_recipients(customer_id);

-- Payment templates (per customer)
CREATE TABLE IF NOT EXISTS channels.payment_templates (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    customer_id UUID NOT NULL,
    short_id VARCHAR(4) NOT NULL,
    short_name VARCHAR(50) NOT NULL,
    description TEXT,
    debtor_iban VARCHAR(34),
    creditor_iban VARCHAR(34) NOT NULL,
    creditor_name VARCHAR(255) NOT NULL,
    amount VARCHAR(20),
    currency VARCHAR(3) NOT NULL DEFAULT 'NOK',
    reference TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (customer_id, short_id)
);

CREATE INDEX IF NOT EXISTS idx_payment_templates_customer
    ON channels.payment_templates(customer_id);

-- ============================================================
-- ADMIN SCHEMA
-- ============================================================

-- Bank-internal users (operators and administrators)
CREATE TABLE IF NOT EXISTS admin.users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    username VARCHAR(100) NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    display_name VARCHAR(255) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'active',
    oidc_sub TEXT UNIQUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Module-level permissions for bank users
-- role: 'operator' (read + create/execute) or 'admin' (operator + update/delete + manage)
CREATE TABLE IF NOT EXISTS admin.user_permissions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES admin.users(id) ON DELETE CASCADE,
    module VARCHAR(50) NOT NULL,
    role VARCHAR(20) NOT NULL CHECK (role IN ('operator', 'admin')),
    UNIQUE (user_id, module)
);

-- Session tokens for admin users
CREATE TABLE IF NOT EXISTS admin.sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES admin.users(id) ON DELETE CASCADE,
    token TEXT NOT NULL UNIQUE,
    expires_at TIMESTAMPTZ NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- SEED DATA: initial bank-admin superuser
-- Password: 'bank-admin' hashed with pgcrypto (argon2 done in app;
-- this seed uses a known bcrypt hash for bootstrap only).
-- The application should rehash on first login.
-- ============================================================

INSERT INTO admin.users (id, username, password_hash, display_name, status)
VALUES (
    '00000000-0000-0000-0000-000000000001',
    'bank-admin',
    crypt('bank-admin', gen_salt('bf')),
    'Bank Administrator',
    'active'
) ON CONFLICT (id) DO NOTHING;

INSERT INTO admin.user_permissions (user_id, module, role) VALUES
    ('00000000-0000-0000-0000-000000000001', 'customers',    'admin'),
    ('00000000-0000-0000-0000-000000000001', 'products',     'admin'),
    ('00000000-0000-0000-0000-000000000001', 'arrangements', 'admin'),
    ('00000000-0000-0000-0000-000000000001', 'ledger',       'admin'),
    ('00000000-0000-0000-0000-000000000001', 'payments',     'admin'),
    ('00000000-0000-0000-0000-000000000001', 'clock',        'admin'),
    ('00000000-0000-0000-0000-000000000001', 'users',        'admin'),
    ('00000000-0000-0000-0000-000000000001', 'profiles',     'admin')
ON CONFLICT (user_id, module) DO NOTHING;

-- ============================================================
-- SCHEDULES
-- ============================================================

CREATE TABLE IF NOT EXISTS admin.schedules (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(100) NOT NULL UNIQUE,
    definition_namespace VARCHAR(100) NOT NULL DEFAULT 'default',
    definition_name VARCHAR(200) NOT NULL,
    definition_version VARCHAR(50) NOT NULL DEFAULT '1.0.0',
    schedule_type VARCHAR(20) NOT NULL CHECK (schedule_type IN (
        'continuous', 'intraday', 'daily', 'month-end', 'year-end', 'manual'
    )),
    cron_expression VARCHAR(100),
    interval_seconds INTEGER,
    enabled BOOLEAN NOT NULL DEFAULT true,
    description TEXT,
    last_run_at TIMESTAMPTZ,
    last_instance_id UUID,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Seed schedule configuration for existing Heart definitions
INSERT INTO admin.schedules (name, definition_namespace, definition_name, definition_version, schedule_type, cron_expression, interval_seconds, enabled, description) VALUES
    ('due-payments',         'default', 'payment-execution',   '1.0.0', 'continuous',  NULL,              60,   true,  'Check and execute due-dated payments'),
    ('eod-batch',            'default', 'eod-batch',           '1.0.0', 'daily',       '0 23 * * *',      NULL, true,  'End-of-day accounting batch'),
    ('daily-reconciliation', 'default', 'daily-reconciliation','1.0.0', 'daily',       '0 23 30 * *',     NULL, true,  'Daily GL-to-core reconciliation'),
    ('daily-pnl',            'default', 'daily-pnl',           '1.0.0', 'daily',       '0 23 * * *',      NULL, true,  'Daily profit & loss calculation'),
    ('daily-position',       'default', 'daily-position',      '1.0.0', 'daily',       '0 22 * * *',      NULL, true,  'Treasury daily position snapshot'),
    ('month-end-close',      'default', 'month-end-batch',     '1.0.0', 'month-end',   '0 2 L * *',       NULL, true,  'Monthly accounting close'),
    ('gl-sync',              'default', 'gl-sync',             '1.0.0', 'daily',       '0 21 * * *',      NULL, true,  'Sync core ledger to general ledger')
ON CONFLICT (name) DO NOTHING;

CREATE TABLE IF NOT EXISTS admin.schedule_runs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    schedule_id UUID NOT NULL REFERENCES admin.schedules(id) ON DELETE CASCADE,
    instance_id UUID,
    status VARCHAR(20) NOT NULL DEFAULT 'started' CHECK (status IN ('started', 'completed', 'failed')),
    triggered_by VARCHAR(20) NOT NULL DEFAULT 'scheduler' CHECK (triggered_by IN ('scheduler', 'manual')),
    error_message TEXT,
    started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_schedule_runs_schedule_id ON admin.schedule_runs(schedule_id);
CREATE INDEX IF NOT EXISTS idx_schedule_runs_started_at ON admin.schedule_runs(started_at DESC);

CREATE TABLE IF NOT EXISTS admin.schedule_alerts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    schedule_id UUID NOT NULL REFERENCES admin.schedules(id) ON DELETE CASCADE,
    alert_type VARCHAR(20) NOT NULL CHECK (alert_type IN ('failed', 'overdue')),
    message TEXT NOT NULL,
    run_id UUID REFERENCES admin.schedule_runs(id) ON DELETE SET NULL,
    acknowledged BOOLEAN NOT NULL DEFAULT false,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    resolved_at TIMESTAMPTZ,
    UNIQUE (schedule_id, alert_type, resolved_at)
);

CREATE INDEX IF NOT EXISTS idx_schedule_alerts_active ON admin.schedule_alerts(schedule_id) WHERE resolved_at IS NULL;

CREATE TABLE IF NOT EXISTS admin.schedule_dependencies (
    schedule_id UUID NOT NULL REFERENCES admin.schedules(id) ON DELETE CASCADE,
    depends_on UUID NOT NULL REFERENCES admin.schedules(id) ON DELETE CASCADE,
    PRIMARY KEY (schedule_id, depends_on),
    CHECK (schedule_id != depends_on)
);

-- Default dependency: month-end-close depends on eod-batch
INSERT INTO admin.schedule_dependencies (schedule_id, depends_on)
SELECT mc.id, eod.id
FROM admin.schedules mc, admin.schedules eod
WHERE mc.name = 'month-end-close' AND eod.name = 'eod-batch'
ON CONFLICT DO NOTHING;

-- ============================================================
-- TERMS & CONDITIONS
-- ============================================================

CREATE TABLE IF NOT EXISTS core.terms_and_conditions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    document_type VARCHAR(100) NOT NULL,        -- "account_general", "savings_specific", "privacy", "onboarding"
    version VARCHAR(20) NOT NULL,               -- semver: "1.0.0", "2.1.0"
    title VARCHAR(500) NOT NULL,
    description TEXT,
    oci_reference VARCHAR(500),                 -- oci://oci.bjoroy.me/<instance>/terms/<type>:<version>
    content_hash VARCHAR(64),                   -- SHA256 for integrity verification
    effective_from TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    effective_to TIMESTAMPTZ,                   -- NULL = currently effective
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (document_type, version)
);

CREATE INDEX IF NOT EXISTS idx_tc_document_type ON core.terms_and_conditions(document_type);
CREATE INDEX IF NOT EXISTS idx_tc_effective ON core.terms_and_conditions(document_type, effective_from);

CREATE TABLE IF NOT EXISTS core.tc_acceptances (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    customer_id UUID NOT NULL,
    tc_id UUID NOT NULL REFERENCES core.terms_and_conditions(id),
    arrangement_id UUID,                        -- NULL for pre-arrangement acceptances (onboarding)
    process_instance_id UUID,                   -- Heart process instance that triggered
    accepted_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    proof_signature TEXT NOT NULL,               -- Ed25519 signature hex
    proof_public_key TEXT NOT NULL,              -- Ed25519 public key hex
    proof_payload JSONB NOT NULL,               -- Signed payload: {tc_id, version, customer_id, content_hash, timestamp}
    ip_address VARCHAR(45),                     -- IPv4 or IPv6
    user_agent TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_tc_accept_customer ON core.tc_acceptances(customer_id);
CREATE INDEX IF NOT EXISTS idx_tc_accept_tc ON core.tc_acceptances(tc_id);
CREATE INDEX IF NOT EXISTS idx_tc_accept_arrangement ON core.tc_acceptances(arrangement_id) WHERE arrangement_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_tc_accept_process ON core.tc_acceptances(process_instance_id) WHERE process_instance_id IS NOT NULL;

-- Seed default T&C documents
INSERT INTO core.terms_and_conditions (document_type, version, title, description, effective_from)
VALUES
    ('account_general', '1.0.0', 'General Account Terms', 'General terms and conditions for all bank accounts', NOW()),
    ('savings_specific', '1.0.0', 'Savings Account Terms', 'Additional terms for savings accounts', NOW()),
    ('privacy', '1.0.0', 'Privacy Policy', 'Data processing and privacy policy', NOW()),
    ('onboarding', '1.0.0', 'Customer Onboarding Terms', 'Terms for becoming a customer', NOW())
ON CONFLICT (document_type, version) DO NOTHING;

-- ============================================================
-- SCHEMA MIGRATIONS (idempotent ALTER statements for existing databases)
-- ============================================================

-- v1.4.18: Allow nullable account IDs for interbank payments.
-- External counterparties (creditor at another bank, or debtor for incoming)
-- don't have local accounts, so these must be nullable.
ALTER TABLE payments.payment_orders ALTER COLUMN debtor_account_id DROP NOT NULL;
ALTER TABLE payments.payment_orders ALTER COLUMN creditor_account_id DROP NOT NULL;
ALTER TABLE payments.payment_orders ADD COLUMN IF NOT EXISTS debtor_name VARCHAR(255);

-- v1.4.25: Retry columns for payment execution back-off
ALTER TABLE payments.payment_orders ADD COLUMN IF NOT EXISTS retry_count INT NOT NULL DEFAULT 0;
ALTER TABLE payments.payment_orders ADD COLUMN IF NOT EXISTS next_retry_at TIMESTAMPTZ;
ALTER TABLE payments.payment_orders ADD COLUMN IF NOT EXISTS retry_deadline TIMESTAMPTZ;

CREATE INDEX IF NOT EXISTS idx_payment_orders_retry
    ON payments.payment_orders (status, next_retry_at)
    WHERE status = 'RTRY';

-- Remove broken due-payments schedule if it exists (was wrongly triggering
-- payment-execution without metadata). ExecutionScheduler handles this.
DELETE FROM admin.schedule_runs WHERE schedule_id IN (
    SELECT id FROM admin.schedules WHERE name = 'due-payments'
      AND definition_name = 'payment-execution'
);
DELETE FROM admin.schedule_alerts WHERE schedule_id IN (
    SELECT id FROM admin.schedules WHERE name = 'due-payments'
      AND definition_name = 'payment-execution'
);
DELETE FROM admin.schedules WHERE name = 'due-payments'
    AND definition_name = 'payment-execution';

-- v1.4.38: OIDC subject link for admin users (external access via channel-gateway)
ALTER TABLE admin.users ADD COLUMN IF NOT EXISTS oidc_sub TEXT UNIQUE;

-- ============================================================
-- RTP SCHEMA — Request to Pay service
-- ============================================================

CREATE SCHEMA IF NOT EXISTS rtp;

CREATE TABLE IF NOT EXISTS rtp.requests (
    id              UUID PRIMARY KEY,
    end_to_end_id   TEXT NOT NULL,
    message_id      TEXT NOT NULL UNIQUE,
    payee_name      TEXT NOT NULL,
    payee_iban      TEXT NOT NULL,
    payee_bic       TEXT,
    payer_iban      TEXT NOT NULL,
    amount          NUMERIC(18,2) NOT NULL,
    currency        TEXT NOT NULL DEFAULT 'EUR',
    remittance_info TEXT,
    status          TEXT NOT NULL DEFAULT 'created'
                    CHECK (status IN (
                        'created', 'sent', 'received', 'accepted', 'rejected',
                        'expired', 'cancelled', 'payment_pending', 'payment_settled', 'payment_failed'
                    )),
    expiry          TIMESTAMPTZ NOT NULL,
    created_at      TIMESTAMPTZ NOT NULL,
    updated_at      TIMESTAMPTZ NOT NULL,
    process_instance_id TEXT,
    payee_sp_endpoint   TEXT
);

CREATE INDEX IF NOT EXISTS idx_rtp_requests_message_id ON rtp.requests(message_id);
CREATE INDEX IF NOT EXISTS idx_rtp_requests_payer_iban ON rtp.requests(payer_iban);
CREATE INDEX IF NOT EXISTS idx_rtp_requests_status ON rtp.requests(status);
CREATE INDEX IF NOT EXISTS idx_rtp_requests_expiry ON rtp.requests(expiry) WHERE status NOT IN ('payment_settled', 'payment_failed', 'rejected', 'expired', 'cancelled');

CREATE TABLE IF NOT EXISTS rtp.status_history (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    request_id      UUID NOT NULL REFERENCES rtp.requests(id),
    from_status     TEXT NOT NULL,
    to_status       TEXT NOT NULL,
    actor           TEXT NOT NULL,
    reason          TEXT,
    transitioned_at TIMESTAMPTZ NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_rtp_status_history_request ON rtp.status_history(request_id);

CREATE TABLE IF NOT EXISTS rtp.inter_sp_messages (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    message_id      TEXT NOT NULL,
    direction       TEXT NOT NULL CHECK (direction IN ('sent', 'received')),
    message_type    TEXT NOT NULL CHECK (message_type IN ('pain.013', 'pain.014', 'payment_confirmation')),
    payload         JSONB NOT NULL,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_rtp_inter_sp_msg_id ON rtp.inter_sp_messages(message_id);

-- ============================================================
-- STRUCTURED REMITTANCE SUPPORT (ISO 20022)
-- ============================================================

-- Add end_to_end_id and structured remittance to ledger transactions
ALTER TABLE core.transactions ADD COLUMN IF NOT EXISTS end_to_end_id TEXT;
ALTER TABLE core.transactions ADD COLUMN IF NOT EXISTS remittance_information_structured JSONB;
CREATE INDEX IF NOT EXISTS idx_transactions_e2e_id ON core.transactions(end_to_end_id) WHERE end_to_end_id IS NOT NULL;

-- Add structured remittance fields to payment orders
ALTER TABLE payments.payment_orders ADD COLUMN IF NOT EXISTS creditor_reference TEXT;
ALTER TABLE payments.payment_orders ADD COLUMN IF NOT EXISTS referenced_document_number TEXT;
ALTER TABLE payments.payment_orders ADD COLUMN IF NOT EXISTS referenced_document_type TEXT;

-- Prospective savings interest. Monetary fractions are carried in currency units
-- times lcm(360,365) so both supported day counts remain exact.
CREATE TABLE IF NOT EXISTS core.savings_interest_enrolments (
    arrangement_id UUID PRIMARY KEY REFERENCES core.arrangements(id),
    start_date DATE NOT NULL,
    ledger_account_id UUID NOT NULL REFERENCES core.ledger_accounts(id),
    currency VARCHAR(3) NOT NULL,
    accrued_account_id UUID NOT NULL UNIQUE REFERENCES core.ledger_accounts(id),
    CHECK (ledger_account_id <> accrued_account_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS savings_interest_master_once ON core.savings_interest_enrolments(ledger_account_id);
CREATE UNIQUE INDEX IF NOT EXISTS savings_interest_expense_currency
    ON core.ledger_accounts(currency) WHERE account_type='general_ledger' AND account_subtype='interest_expense';
ALTER TABLE core.transactions ADD COLUMN IF NOT EXISTS interest_bank_date DATE;
ALTER TABLE core.postings ADD COLUMN IF NOT EXISTS interest_role TEXT
    CHECK (interest_role IN ('savings_interest_expense','savings_interest_payable','savings_interest_capital'));
-- These two published contracts use flat ACT/365 direct daily credit.
CREATE OR REPLACE FUNCTION core.is_dated_current(kind text, name text, version text, currency text, spec jsonb)
RETURNS boolean LANGUAGE sql IMMUTABLE AS $$
    SELECT coalesce(kind='current_account' AND version='1.0.0'
       AND (name,currency) IN (('current-account','NOK'),('current-account-brg','BRG'))
       AND spec #>> '{policies,interest,type}'='flat_rate'
       AND spec #>> '{lifecycle,interest_accrual}'='products/interest-accrual:1.0.0'
       AND spec #> '{policies,interest,config,accrual}' IS NULL,false)
$$;
ALTER TABLE core.postings DROP CONSTRAINT IF EXISTS postings_interest_role_check;
ALTER TABLE core.postings ADD CONSTRAINT postings_interest_role_check
    CHECK (interest_role IN ('savings_interest_expense','savings_interest_payable','savings_interest_capital','current_interest_capital'));
-- Stamp the economics at posting time. Existing customer and loan entries
-- retain the classification written when they were created.
ALTER TABLE core.postings ADD COLUMN IF NOT EXISTS savings_movement_role TEXT
    CHECK (savings_movement_role IN ('savings_principal','savings_settlement','savings_unmapped_counterparty'));
ALTER TABLE core.postings DROP CONSTRAINT IF EXISTS postings_savings_movement_role_check;
ALTER TABLE core.postings ADD CONSTRAINT postings_savings_movement_role_check
    CHECK (savings_movement_role IN ('savings_principal','current_principal','savings_settlement','savings_unmapped_counterparty'));
CREATE TABLE IF NOT EXISTS core.savings_settlement_counterparties (
    account_id UUID PRIMARY KEY REFERENCES core.ledger_accounts(id),
    currency VARCHAR(3) NOT NULL
);

-- Preserve the booked journal and classify only a two-legged same-currency
-- event whose deposit, settlement or reservation provenance is independently
-- provable. Both extracts use this interpretation.
CREATE OR REPLACE VIEW core.proved_deposit_principals AS
SELECT p.id, a.arrangement_id, a.product_id, a.definition_name, a.definition_version,
       CASE WHEN d.product_type='current_account' THEN 'current_principal' ELSE 'savings_principal' END AS role
FROM core.postings p JOIN core.transactions t ON t.id=p.transaction_id
JOIN core.ledger_accounts l ON l.id=p.account_id AND l.account_type='customer'
    AND l.parent_account_id IS NULL AND l.currency=p.currency
JOIN core.interest_arrangement_versions a ON a.ledger_account_id=l.id AND a.currency=p.currency
    AND a.valid_from<=t.timestamp AND (a.valid_until IS NULL OR t.timestamp<a.valid_until)
LEFT JOIN core.interest_definition_versions d ON (d.name,d.version)=(a.definition_name,a.definition_version)
    AND d.base_currency=p.currency AND d.valid_from<=t.timestamp AND (d.valid_until IS NULL OR t.timestamp<d.valid_until)
WHERE t.interest_bank_date IS NULL AND p.interest_role IS NULL AND p.amount<>0
  AND (d.product_type='savings' OR core.is_dated_current(d.product_type,d.name,d.version,d.base_currency,d.spec)
       OR (a.definition_name IS NULL AND a.definition_version IS NULL AND a.currency='NOK'
           AND a.product_id='10000000-0000-0000-0000-000000000201'::uuid
           AND EXISTS(SELECT 1 FROM core.products catalogue WHERE catalogue.id=a.product_id
                AND catalogue.product_type IN ('savings','savings_account') AND catalogue.default_currency='NOK'
                AND catalogue.default_interest_rate=3.500000)))
  AND NOT EXISTS(SELECT 1 FROM core.interest_arrangement_versions other WHERE other.ledger_account_id=a.ledger_account_id
      AND other.arrangement_id<>a.arrangement_id AND other.valid_from<=t.timestamp AND (other.valid_until IS NULL OR t.timestamp<other.valid_until));

CREATE OR REPLACE VIEW core.proved_ordinary_posting_roles AS
WITH paired AS NOT MATERIALIZED (
    SELECT p.id,p.account_id,p.currency,p.amount,q.id AS opposite,q.account_id AS opposite_account
    FROM core.postings p JOIN core.postings q ON q.transaction_id=p.transaction_id AND p.id<>q.id
        AND p.currency=q.currency AND p.amount=-q.amount AND q.interest_role IS NULL
    JOIN core.transactions t ON t.id=p.transaction_id AND t.interest_bank_date IS NULL
    WHERE p.interest_role IS NULL AND p.amount<>0 AND NOT EXISTS(
        SELECT 1 FROM core.postings third WHERE third.transaction_id=p.transaction_id AND third.id NOT IN(p.id,q.id))
), funding AS NOT MATERIALIZED (
    SELECT p.id,p.opposite,deposit.role,CASE WHEN peer.id IS NOT NULL THEN peer.role
              WHEN gl.account_type='nostro' AND gl.account_subtype='nostro_bragd' AND gl.parent_account_id IS NULL THEN 'deposit_nostro_bragd'
              WHEN gl.account_type='general_ledger' AND gl.account_subtype IS NULL AND gl.parent_account_id IS NULL
                AND EXISTS(SELECT 1 FROM core.savings_settlement_counterparties c WHERE c.account_id=gl.id AND c.currency=p.currency)
              THEN 'savings_settlement' END AS peer_role
    FROM paired p JOIN core.proved_deposit_principals deposit ON deposit.id=p.id
    LEFT JOIN core.proved_deposit_principals peer ON peer.id=p.opposite
    JOIN core.ledger_accounts gl ON gl.id=p.opposite_account AND gl.currency=p.currency
), holds AS NOT MATERIALIZED (
    SELECT p.id,p.opposite FROM paired p JOIN core.reservations r ON r.sub_account_id=p.account_id AND r.currency=p.currency
        AND ((r.posting_id=p.id AND r.amount=p.amount) OR (r.release_posting_id=p.id AND r.amount=-p.amount))
    JOIN core.ledger_accounts sub ON sub.id=p.account_id AND sub.account_type='sub_account'
        AND sub.account_subtype='payment-reservation' AND sub.currency=p.currency
    JOIN core.ledger_accounts parent ON parent.id=sub.parent_account_id AND parent.account_type='customer' AND parent.currency=p.currency
    JOIN core.ledger_accounts gl ON gl.id=p.opposite_account AND gl.account_type='general_ledger'
        AND gl.account_subtype IS NULL AND gl.parent_account_id IS NULL AND gl.currency=p.currency
)
SELECT id,role FROM funding WHERE peer_role IS NOT NULL
UNION SELECT opposite,peer_role FROM funding WHERE peer_role IS NOT NULL
UNION SELECT id,'reservation_hold' FROM holds
UNION SELECT opposite,'reservation_control' FROM holds;

CREATE OR REPLACE VIEW core.typed_postings AS
SELECT p.*,coalesce(p.interest_role,nullif(p.savings_movement_role,'savings_unmapped_counterparty'),typed.role,p.savings_movement_role) AS economic_role
FROM core.postings p LEFT JOIN core.proved_ordinary_posting_roles typed ON typed.id=p.id;

CREATE OR REPLACE FUNCTION core.classify_savings_movement() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE
    event_time TIMESTAMPTZ;
    interest_day DATE;
    principal_role TEXT;
BEGIN
    IF NEW.interest_role IS NOT NULL THEN RETURN NULL; END IF;
    SELECT timestamp,interest_bank_date INTO STRICT event_time,interest_day FROM core.transactions WHERE id=NEW.transaction_id;
    IF interest_day IS NOT NULL THEN RETURN NULL; END IF;
    SELECT CASE WHEN d.product_type='savings' THEN 'savings_principal' ELSE 'current_principal' END INTO principal_role
        FROM core.savings_interest_enrolments e
        JOIN core.interest_arrangement_versions a ON a.arrangement_id=e.arrangement_id
        JOIN core.interest_definition_versions d ON (d.name,d.version)=(a.definition_name,a.definition_version)
        WHERE e.ledger_account_id=NEW.account_id AND a.ledger_account_id=NEW.account_id
        AND (d.product_type='savings' OR core.is_dated_current(d.product_type,d.name,d.version,d.base_currency,d.spec)) AND a.currency=NEW.currency AND e.currency=NEW.currency
        AND a.valid_from<=event_time AND (a.valid_until IS NULL OR event_time<a.valid_until)
        AND d.valid_from<=event_time AND (d.valid_until IS NULL OR event_time<d.valid_until)
        AND (event_time AT TIME ZONE COALESCE(d.spec #>> '{policies,interest,config,accrual,bank_timezone}',
                                              'Europe/Oslo'))::date >= e.start_date;
    IF FOUND THEN
        UPDATE core.postings SET savings_movement_role=principal_role WHERE id=NEW.id;
    END IF;
    IF EXISTS (SELECT 1 FROM core.postings WHERE transaction_id=NEW.transaction_id AND savings_movement_role IN ('savings_principal','current_principal')) THEN
        UPDATE core.postings p SET savings_movement_role=
            CASE WHEN EXISTS (SELECT 1 FROM core.savings_settlement_counterparties c WHERE c.account_id=p.account_id AND c.currency=p.currency)
                 THEN 'savings_settlement' ELSE 'savings_unmapped_counterparty' END
        WHERE p.transaction_id=NEW.transaction_id AND p.interest_role IS NULL AND p.savings_movement_role IS NULL;
    END IF;
    RETURN NULL;
END;
$$;
DROP TRIGGER IF EXISTS mark_prospective_savings_movement ON core.postings;
CREATE TRIGGER mark_prospective_savings_movement AFTER INSERT ON core.postings
    FOR EACH ROW EXECUTE FUNCTION core.classify_savings_movement();

CREATE TABLE IF NOT EXISTS core.savings_interest_days (
    arrangement_id UUID NOT NULL REFERENCES core.savings_interest_enrolments(arrangement_id),
    bank_date DATE NOT NULL,
    currency VARCHAR(3) NOT NULL,
    accrued_amount NUMERIC(19,4) NOT NULL,
    capitalised_amount NUMERIC(19,4) NOT NULL,
    booked_accrual NUMERIC(19,4) NOT NULL,
    carry_units NUMERIC NOT NULL,
    terms JSONB,
    accrual_transaction_id UUID UNIQUE REFERENCES core.transactions(id),
    capitalisation_transaction_id UUID UNIQUE REFERENCES core.transactions(id),
    PRIMARY KEY (arrangement_id,bank_date),
    FOREIGN KEY (arrangement_id,bank_date) REFERENCES core.daily_interest_basis(arrangement_id,bank_date),
    CHECK ((accrual_transaction_id IS NULL) = (accrued_amount=0)),
    CHECK ((capitalisation_transaction_id IS NULL) = (capitalised_amount=0))
);

CREATE OR REPLACE FUNCTION core.reject_settled_interest_change() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
    RAISE EXCEPTION 'Settled savings interest receipts are immutable' USING ERRCODE='55000';
END;
$$;
DROP TRIGGER IF EXISTS immutable_savings_interest_day ON core.savings_interest_days;
CREATE TRIGGER immutable_savings_interest_day BEFORE UPDATE OR DELETE ON core.savings_interest_days
    FOR EACH ROW EXECUTE FUNCTION core.reject_settled_interest_change();

CREATE OR REPLACE FUNCTION core.savings_interest_transfer(
    arrangement UUID, day DATE, ccy TEXT, amount NUMERIC,
    source_id UUID, source_role TEXT, target_id UUID, target_role TEXT, purpose TEXT
) RETURNS UUID LANGUAGE plpgsql AS $$
DECLARE
    tx_id UUID := gen_random_uuid();
BEGIN
    IF amount=0 THEN RETURN NULL; END IF;
    INSERT INTO core.transactions(id,reference,description,interest_bank_date)
    VALUES (tx_id, format('SAV-INT-%s-%s-%s',arrangement,day,purpose), purpose,day);
    INSERT INTO core.postings(id,transaction_id,account_id,amount,currency,interest_role)
    VALUES (gen_random_uuid(),tx_id,source_id,-amount,ccy,source_role),
           (gen_random_uuid(),tx_id,target_id, amount,ccy,target_role);
    RETURN tx_id;
END;
$$;

-- A closure fixes the last earning day while the account is empty. The bank
-- returns any final interest to available funds before the account can close.
CREATE TABLE IF NOT EXISTS core.savings_interest_closures (
    arrangement_id UUID PRIMARY KEY REFERENCES core.savings_interest_enrolments(arrangement_id),
    bank_date DATE NOT NULL,
    bank_timezone TEXT NOT NULL,
    requested_at TIMESTAMPTZ NOT NULL DEFAULT transaction_timestamp(),
    settled_at TIMESTAMPTZ,
    capitalised_amount NUMERIC(19,4),
    capitalisation_transaction_id UUID UNIQUE REFERENCES core.transactions(id),
    cleared_carry_units NUMERIC,
    closed_at TIMESTAMPTZ,
    CHECK ((settled_at IS NULL) = (capitalised_amount IS NULL)),
    CHECK ((settled_at IS NULL) = (cleared_carry_units IS NULL)),
    CHECK ((capitalisation_transaction_id IS NOT NULL) = COALESCE(capitalised_amount<>0,false)),
    CHECK (closed_at IS NULL OR settled_at IS NOT NULL)
);

CREATE OR REPLACE FUNCTION core.guard_savings_closure_receipt() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
    IF TG_OP='DELETE'
        OR (NEW.arrangement_id,NEW.bank_date,NEW.bank_timezone,NEW.requested_at)
            IS DISTINCT FROM (OLD.arrangement_id,OLD.bank_date,OLD.bank_timezone,OLD.requested_at)
        OR (OLD.settled_at IS NOT NULL AND
            (NEW.settled_at,NEW.capitalised_amount,NEW.capitalisation_transaction_id,NEW.cleared_carry_units)
            IS DISTINCT FROM (OLD.settled_at,OLD.capitalised_amount,OLD.capitalisation_transaction_id,OLD.cleared_carry_units))
        OR (OLD.closed_at IS NOT NULL AND NEW.closed_at IS DISTINCT FROM OLD.closed_at) THEN
        RAISE EXCEPTION 'Final savings receipt history is immutable';
    END IF;
    RETURN NEW;
END;
$$;
DROP TRIGGER IF EXISTS guard_savings_closure_receipt ON core.savings_interest_closures;
CREATE TRIGGER guard_savings_closure_receipt BEFORE UPDATE OR DELETE ON core.savings_interest_closures
    FOR EACH ROW EXECUTE FUNCTION core.guard_savings_closure_receipt();

CREATE OR REPLACE FUNCTION core.finish_savings_interest(day_row core.savings_interest_days)
RETURNS VOID LANGUAGE plpgsql AS $$
DECLARE
    request core.savings_interest_closures;
    enrolled core.savings_interest_enrolments;
    transfer UUID;
BEGIN
    SELECT * INTO request FROM core.savings_interest_closures
      WHERE arrangement_id=day_row.arrangement_id AND bank_date=day_row.bank_date FOR UPDATE;
    IF NOT FOUND OR request.settled_at IS NOT NULL THEN RETURN; END IF;
    SELECT * INTO STRICT enrolled FROM core.savings_interest_enrolments WHERE arrangement_id=request.arrangement_id;
    IF (SELECT COALESCE(sum(amount),0) FROM core.postings WHERE account_id=enrolled.accrued_account_id)
       <> day_row.booked_accrual THEN RAISE EXCEPTION 'Final interest payable fails reconciliation'; END IF;
    transfer := day_row.capitalisation_transaction_id;
    IF day_row.booked_accrual<>0 THEN
        transfer := core.savings_interest_transfer(request.arrangement_id,request.bank_date,enrolled.currency,
            day_row.booked_accrual,enrolled.accrued_account_id,'savings_interest_payable',
            enrolled.ledger_account_id,'savings_interest_capital','final savings interest capitalisation');
    END IF;
    UPDATE core.savings_interest_closures SET settled_at=transaction_timestamp(),
        capitalised_amount=day_row.capitalised_amount+day_row.booked_accrual,
        capitalisation_transaction_id=transfer, cleared_carry_units=day_row.carry_units
        WHERE arrangement_id=request.arrangement_id;
END;
$$;

-- Incoming clearing accepts an order before the asynchronous credit posts.
-- Registration must see the admitted order, or admission must see closure.
CREATE INDEX IF NOT EXISTS pending_incoming_creditor ON payments.payment_orders(creditor_account_id)
    WHERE payment_type IN ('incoming','incoming-inst') AND status NOT IN ('ACSC','RJCT','CANC');
CREATE OR REPLACE FUNCTION core.has_pending_incoming_credit(agreement UUID)
RETURNS BOOLEAN LANGUAGE SQL STABLE AS $$
    SELECT EXISTS (SELECT 1 FROM payments.payment_orders p
        WHERE p.payment_type IN ('incoming','incoming-inst') AND p.status NOT IN ('ACSC','RJCT','CANC')
        AND (p.creditor_account_id=agreement OR (p.creditor_account_id IS NULL AND EXISTS (
            SELECT 1 FROM core.account_identifiers i WHERE i.arrangement_id=agreement
                AND i.identifier_type='IBAN' AND i.identifier_value=p.creditor_identifier))));
$$;
CREATE OR REPLACE FUNCTION core.guard_incoming_credit_admission() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE
    current_status TEXT;
BEGIN
    IF NEW.payment_type NOT IN ('incoming','incoming-inst') OR NEW.status IN ('ACSC','RJCT','CANC')
        THEN RETURN NEW; END IF;
    IF NEW.creditor_account_id IS NULL THEN
        SELECT arrangement_id INTO NEW.creditor_account_id FROM core.account_identifiers
            WHERE identifier_type='IBAN' AND identifier_value=NEW.creditor_identifier;
    END IF;
    IF NEW.creditor_account_id IS NULL THEN RETURN NEW; END IF;
    SELECT status INTO current_status FROM core.arrangements WHERE id=NEW.creditor_account_id FOR SHARE;
    IF current_status='closed' OR EXISTS(SELECT 1 FROM core.savings_interest_closures
            WHERE arrangement_id=NEW.creditor_account_id) THEN
        RAISE EXCEPTION 'Creditor account no longer accepts deposits' USING ERRCODE='P0491';
    END IF;
    RETURN NEW;
END;
$$;
DROP TRIGGER IF EXISTS guard_incoming_credit_admission ON payments.payment_orders;
CREATE TRIGGER guard_incoming_credit_admission BEFORE INSERT OR UPDATE OF creditor_account_id,creditor_identifier,payment_type,status
    ON payments.payment_orders FOR EACH ROW EXECUTE FUNCTION core.guard_incoming_credit_admission();

-- A delayed dormancy task must not invalidate the closing day's eligibility
-- or reopen the agreement after final withdrawal.
CREATE OR REPLACE FUNCTION core.guard_savings_closure_lifecycle() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
    IF (NEW.status,NEW.lifecycle_state) IS DISTINCT FROM (OLD.status,OLD.lifecycle_state)
       AND EXISTS (SELECT 1 FROM core.savings_interest_closures WHERE arrangement_id=OLD.id)
       AND (OLD.status='closed' OR NEW.status<>'closed' OR NEW.lifecycle_state IS DISTINCT FROM 'closed'
            OR NOT EXISTS (SELECT 1 FROM core.savings_interest_closures WHERE arrangement_id=OLD.id AND settled_at IS NOT NULL)
            OR core.has_pending_incoming_credit(OLD.id)
            OR EXISTS (SELECT 1 FROM core.reservations r JOIN core.ledger_accounts l ON l.id=r.sub_account_id
                WHERE COALESCE(l.parent_account_id,l.id)=OLD.ledger_account_id AND r.status='active')
            OR (SELECT COALESCE(sum(amount),0) FROM core.postings WHERE account_id=OLD.ledger_account_id)<>0) THEN
        RAISE EXCEPTION 'Savings closure requires final settlement and withdrawal';
    END IF;
    RETURN NEW;
END;
$$;
DROP TRIGGER IF EXISTS guard_savings_closure_lifecycle ON core.arrangements;
CREATE TRIGGER guard_savings_closure_lifecycle BEFORE UPDATE OF status,lifecycle_state ON core.arrangements
    FOR EACH ROW EXECUTE FUNCTION core.guard_savings_closure_lifecycle();

ALTER TABLE core.transactions ADD COLUMN IF NOT EXISTS savings_closure_payment_id UUID REFERENCES payments.payment_orders(id);
CREATE UNIQUE INDEX IF NOT EXISTS savings_closure_payment_once ON core.transactions(savings_closure_payment_id)
    WHERE savings_closure_payment_id IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS savings_interest_role_once ON core.postings(transaction_id,interest_role)
    WHERE interest_role IS NOT NULL;

-- Some payment writers create the reservation directly. Taking the same
-- arrangement lock also covers those writers when they create or revive a hold.
CREATE OR REPLACE FUNCTION core.guard_closing_reservation() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE
    agreement RECORD;
    available NUMERIC;
BEGIN
    IF NEW.status<>'active' THEN RETURN NEW; END IF;
    SELECT a.id,a.status,a.currency,a.ledger_account_id INTO agreement FROM core.ledger_accounts l
        JOIN core.arrangements a ON a.ledger_account_id=COALESCE(l.parent_account_id,l.id)
        WHERE l.id=NEW.sub_account_id FOR SHARE OF a;
    IF NOT FOUND THEN RETURN NEW; END IF;
    IF agreement.status='closed' THEN RAISE EXCEPTION 'Cannot reserve funds on a closed account'; END IF;
    PERFORM 1 FROM core.savings_interest_closures WHERE arrangement_id=agreement.id FOR UPDATE;
    IF FOUND THEN
        IF EXISTS (SELECT 1 FROM core.reservations WHERE payment_order_id=NEW.payment_order_id
            AND status='active' AND id<>NEW.id)
            OR EXISTS (SELECT 1 FROM core.transactions WHERE savings_closure_payment_id=NEW.payment_order_id)
        THEN RAISE EXCEPTION 'Final payment already reserved or booked'; END IF;
        SELECT COALESCE(sum(amount),0) INTO available FROM core.postings WHERE account_id=agreement.ledger_account_id;
        available := available - (SELECT COALESCE(sum(r.amount),0) FROM core.reservations r
            JOIN core.ledger_accounts l ON l.id=r.sub_account_id
            WHERE COALESCE(l.parent_account_id,l.id)=agreement.ledger_account_id AND r.status='active' AND r.id<>NEW.id);
        IF NEW.currency<>agreement.currency OR NEW.amount<=0 OR NEW.amount>available THEN
            RAISE EXCEPTION 'Reservation exceeds available final withdrawal';
        END IF;
    END IF;
    RETURN NEW;
END;
$$;
DROP TRIGGER IF EXISTS guard_closing_reservation ON core.reservations;
CREATE TRIGGER guard_closing_reservation BEFORE INSERT OR UPDATE ON core.reservations
    FOR EACH ROW EXECUTE FUNCTION core.guard_closing_reservation();

-- Posted money on closing accounts cannot be rewritten. Ordinary write-time
-- classification may still populate the non-economic movement-role column.
CREATE OR REPLACE FUNCTION core.guard_closing_posting_change() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE
    agreement RECORD;
BEGIN
    FOR agreement IN SELECT a.id,a.status FROM core.ledger_accounts l
        JOIN core.arrangements a ON a.ledger_account_id=COALESCE(l.parent_account_id,l.id)
        WHERE l.id=OLD.account_id OR (TG_OP='UPDATE' AND l.id=NEW.account_id)
        ORDER BY a.id FOR SHARE OF a
    LOOP
        IF agreement.status='closed' OR EXISTS (SELECT 1 FROM core.savings_interest_closures WHERE arrangement_id=agreement.id)
        THEN RAISE EXCEPTION 'Posted money on a closing account cannot be changed'; END IF;
    END LOOP;
    IF TG_OP='DELETE' THEN RETURN OLD; END IF;
    RETURN NEW;
END;
$$;
DROP TRIGGER IF EXISTS guard_closing_posting_change ON core.postings;
CREATE TRIGGER guard_closing_posting_change BEFORE DELETE OR UPDATE OF account_id,transaction_id,amount,currency,interest_role
    ON core.postings FOR EACH ROW EXECUTE FUNCTION core.guard_closing_posting_change();

-- Classification alone cannot authorise a credit after the closure request.
-- The monetary transaction must appear on a committed settlement receipt.
CREATE OR REPLACE FUNCTION core.verify_closing_interest_posting() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE
    enrolled core.savings_interest_enrolments;
BEGIN
    SELECT e.* INTO enrolled FROM core.savings_interest_enrolments e
        JOIN core.savings_interest_closures c USING(arrangement_id)
        WHERE NEW.account_id IN (e.ledger_account_id,e.accrued_account_id);
    IF NOT FOUND THEN RETURN NULL; END IF;
    IF NEW.account_id=enrolled.ledger_account_id AND NEW.interest_role IS NULL THEN RETURN NULL; END IF;
    IF NEW.account_id=enrolled.ledger_account_id AND NEW.interest_role IN ('savings_interest_capital','current_interest_capital') AND (
        EXISTS (SELECT 1 FROM core.savings_interest_days WHERE arrangement_id=enrolled.arrangement_id
            AND capitalisation_transaction_id=NEW.transaction_id AND capitalised_amount=NEW.amount)
        OR EXISTS (SELECT 1 FROM core.savings_interest_closures WHERE arrangement_id=enrolled.arrangement_id
            AND capitalisation_transaction_id=NEW.transaction_id AND capitalised_amount=NEW.amount))
    THEN RETURN NULL; END IF;
    IF NEW.account_id=enrolled.accrued_account_id AND NEW.interest_role='savings_interest_payable' AND (
        EXISTS (SELECT 1 FROM core.savings_interest_days WHERE arrangement_id=enrolled.arrangement_id
            AND ((accrual_transaction_id=NEW.transaction_id AND accrued_amount=NEW.amount)
             OR (capitalisation_transaction_id=NEW.transaction_id AND capitalised_amount=-NEW.amount)))
        OR EXISTS (SELECT 1 FROM core.savings_interest_closures WHERE arrangement_id=enrolled.arrangement_id
            AND capitalisation_transaction_id=NEW.transaction_id AND capitalised_amount=-NEW.amount))
    THEN RETURN NULL; END IF;
    RAISE EXCEPTION 'Closing interest posting requires a matching dated receipt';
END;
$$;
DROP TRIGGER IF EXISTS verify_closing_interest_posting ON core.postings;
CREATE CONSTRAINT TRIGGER verify_closing_interest_posting AFTER INSERT ON core.postings DEFERRABLE INITIALLY DEFERRED
    FOR EACH ROW EXECUTE FUNCTION core.verify_closing_interest_posting();

-- Take the same arrangement lock as the close gate. This includes the posting
-- of a reservation on a child account before its active reservation is inserted.
CREATE OR REPLACE FUNCTION core.guard_closing_posting() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE
    agreement RECORD;
    payment UUID;
    other_holds NUMERIC;
BEGIN
    SELECT a.id,a.status,a.ledger_account_id INTO agreement FROM core.ledger_accounts account
        JOIN core.arrangements a ON a.ledger_account_id=COALESCE(account.parent_account_id,account.id)
        WHERE account.id=NEW.account_id FOR SHARE OF a;
    IF NOT FOUND THEN RETURN NEW; END IF;
    IF agreement.status='closed' THEN RAISE EXCEPTION 'Account is closed'; END IF;
    IF NEW.account_id=agreement.ledger_account_id AND EXISTS (
        SELECT 1 FROM core.savings_interest_closures WHERE arrangement_id=agreement.id)
        AND coalesce(NEW.interest_role,'') NOT IN ('savings_interest_capital','current_interest_capital') THEN
        IF NEW.amount>0 THEN RAISE EXCEPTION 'Account is awaiting final withdrawal'; END IF;
        -- Competing cash withdrawals must agree on the remaining customer funds.
        PERFORM 1 FROM core.savings_interest_closures WHERE arrangement_id=agreement.id FOR UPDATE;
        payment := NULLIF(current_setting('core.executing_payment',true),'')::uuid;
        IF payment IS NOT NULL THEN
            IF NOT EXISTS (SELECT 1 FROM payments.payment_orders WHERE id=payment AND debtor_account_id=agreement.id
                AND amount=-NEW.amount AND currency=NEW.currency AND status NOT IN ('RJCT','CANC')) THEN
                RAISE EXCEPTION 'Payment does not match final savings withdrawal';
            END IF;
            UPDATE core.transactions SET savings_closure_payment_id=payment WHERE id=NEW.transaction_id;
        END IF;
        SELECT COALESCE(sum(r.amount),0) INTO other_holds FROM core.reservations r
            JOIN core.ledger_accounts l ON l.id=r.sub_account_id
            WHERE COALESCE(l.parent_account_id,l.id)=agreement.ledger_account_id AND r.status='active'
              AND r.payment_order_id IS DISTINCT FROM payment;
        IF NEW.amount+(SELECT COALESCE(sum(amount),0) FROM core.postings WHERE account_id=NEW.account_id)<other_holds
        THEN RAISE EXCEPTION 'Final withdrawal exceeds unreserved balance'; END IF;
    END IF;
    RETURN NEW;
END;
$$;
DROP TRIGGER IF EXISTS guard_closing_posting ON core.postings;
CREATE TRIGGER guard_closing_posting BEFORE INSERT ON core.postings FOR EACH ROW EXECUTE FUNCTION core.guard_closing_posting();

CREATE OR REPLACE FUNCTION core.settle_savings_interest_day(arrangement UUID, day DATE)
RETURNS core.savings_interest_days LANGUAGE plpgsql AS $$
DECLARE
    enrolled core.savings_interest_enrolments;
    previous core.savings_interest_days;
    settled core.savings_interest_days;
    frozen RECORD;
    settings JSONB;
    exact_units NUMERIC;
    scaled_units NUMERIC;
    integral NUMERIC;
    fraction NUMERIC;
    scale_factor NUMERIC;
    rounded_total NUMERIC;
    expense_id UUID;
    period_end BOOLEAN;
    current_daily BOOLEAN;
BEGIN
    SELECT * INTO STRICT enrolled FROM core.savings_interest_enrolments WHERE arrangement_id=arrangement FOR UPDATE;
    SELECT * INTO settled FROM core.savings_interest_days WHERE arrangement_id=arrangement AND bank_date=day;
    IF FOUND THEN PERFORM core.finish_savings_interest(settled); RETURN settled; END IF;
    IF EXISTS (SELECT 1 FROM core.savings_interest_closures WHERE arrangement_id=arrangement AND bank_date<day) THEN
        RAISE EXCEPTION 'After final savings earning day';
    END IF;
    SELECT * INTO previous FROM core.savings_interest_days WHERE arrangement_id=arrangement ORDER BY bank_date DESC LIMIT 1;
    IF day <> COALESCE(previous.bank_date+1,enrolled.start_date) THEN
        RAISE EXCEPTION 'Previous enrolled savings day must be settled before %', day;
    END IF;
    -- The receipt and actual sub-ledger must agree before any customer transfer.
    IF (SELECT COALESCE(sum(amount),0) FROM core.postings WHERE account_id=enrolled.accrued_account_id)
       <> COALESCE(previous.booked_accrual,0) THEN
        RAISE EXCEPTION 'Accrued interest sub-account differs from its settled balance';
    END IF;
    SELECT * INTO STRICT frozen FROM core.daily_interest_basis WHERE arrangement_id=arrangement AND bank_date=day;
    IF frozen.currency <> enrolled.currency OR frozen.ledger_account_id <> enrolled.ledger_account_id THEN
        RAISE EXCEPTION 'Frozen account or currency differs from savings enrolment';
    END IF;
    IF frozen.result NOT IN ('calculated','zero','no_interest') OR frozen.numerator < 0
       OR (frozen.result='no_interest' AND frozen.numerator<>0)
       OR (frozen.denominator NOT IN (360,365) AND NOT (frozen.result='no_interest' AND frozen.denominator=1)) THEN
        RAISE EXCEPTION 'Unsupported frozen interest basis';
    END IF;
    settings := NULLIF(frozen.basis #> '{daily_calculation,terms}', 'null'::jsonb);
    IF settings IS NULL AND frozen.result <> 'no_interest' THEN
        RAISE EXCEPTION 'Missing frozen interest conventions';
    END IF;
    -- A disabled rate contributes zero, but previously earned interest remains owed.
    settings := COALESCE(settings,previous.terms);
    current_daily := coalesce(frozen.basis #>> '{daily_calculation,settlement_contract}'='current_daily_v1',false);
    IF current_daily AND NOT (settings @> '{"capitalisation_frequency":"daily","rounding_basis":"daily","rounding":"half_even","posting_scale":2,"remainder":"discard_after_daily_credit","day_count":"actual_365_fixed"}'::jsonb AND frozen.denominator=365) THEN
        RAISE EXCEPTION 'Unsupported demand deposit settlement terms';
    END IF;
    IF NOT current_daily AND settings IS NOT NULL AND (
        COALESCE(settings->>'capitalisation_frequency','') NOT IN ('monthly','quarterly')
        OR COALESCE(settings->>'rounding','') NOT IN ('half_even','half_up')
        OR COALESCE(settings->>'posting_scale','') NOT IN ('0','1','2','3','4')
        OR COALESCE(settings->>'remainder','') <> 'carry_signed'
        OR COALESCE(settings->>'rounding_basis','') <> 'period_to_date') THEN
        RAISE EXCEPTION 'Unsupported settlement conventions: %',settings;
    END IF;
    exact_units := (COALESCE(previous.booked_accrual,0)*26280) + COALESCE(previous.carry_units,0)
                   + frozen.numerator*(26280/frozen.denominator);
    scale_factor := power(10::numeric, COALESCE((settings->>'posting_scale')::int,2));
    scaled_units := abs(exact_units)*scale_factor;
    integral := div(scaled_units,26280);
    fraction := mod(scaled_units,26280);
    IF fraction*2 > 26280 OR (fraction*2=26280 AND (settings->>'rounding'='half_up' OR mod(integral,2)=1)) THEN
        integral := integral+1;
    END IF;
    rounded_total := sign(exact_units)*integral/scale_factor;
    IF rounded_total < 0 THEN RAISE EXCEPTION 'Settlement policy change requires review of signed remainder'; END IF;
    settled.arrangement_id := arrangement;
    settled.bank_date := day;
    settled.currency := enrolled.currency;
    settled.terms := settings;
    settled.accrued_amount := rounded_total - COALESCE(previous.booked_accrual,0);
    settled.carry_units := CASE WHEN current_daily THEN 0 ELSE exact_units - rounded_total*26280 END;
    period_end := extract(day FROM day+1)=1 AND
        (settings->>'capitalisation_frequency'='monthly' OR
         (settings->>'capitalisation_frequency'='quarterly' AND extract(month FROM day)::int % 3=0));
    period_end := current_daily OR COALESCE(period_end,false) OR EXISTS (
        SELECT 1 FROM core.savings_interest_closures WHERE arrangement_id=arrangement AND bank_date=day);
    settled.capitalised_amount := CASE WHEN period_end THEN rounded_total ELSE 0 END;
    settled.booked_accrual := rounded_total-settled.capitalised_amount;
    IF settled.accrued_amount<>0 THEN
        INSERT INTO core.ledger_accounts(id,account_type,account_subtype,currency)
        VALUES(gen_random_uuid(),'general_ledger','interest_expense',enrolled.currency)
        ON CONFLICT (currency) WHERE account_type='general_ledger' AND account_subtype='interest_expense' DO NOTHING;
        SELECT id INTO STRICT expense_id FROM core.ledger_accounts WHERE account_type='general_ledger'
            AND account_subtype='interest_expense' AND currency=enrolled.currency;
        settled.accrual_transaction_id := core.savings_interest_transfer(arrangement,day,enrolled.currency,
            settled.accrued_amount,expense_id,'savings_interest_expense',enrolled.accrued_account_id,
            'savings_interest_payable','daily savings interest');
    END IF;
    settled.capitalisation_transaction_id := core.savings_interest_transfer(arrangement,day,enrolled.currency,
        settled.capitalised_amount,enrolled.accrued_account_id,'savings_interest_payable',enrolled.ledger_account_id,
        CASE WHEN current_daily THEN 'current_interest_capital' ELSE 'savings_interest_capital' END,'savings interest capitalisation');
    INSERT INTO core.savings_interest_days SELECT settled.*;
    PERFORM core.finish_savings_interest(settled);
    RETURN settled;
END;
$$;

-- Add referenced document fields to RTP requests
ALTER TABLE rtp.requests ADD COLUMN IF NOT EXISTS referenced_document_number TEXT;
ALTER TABLE rtp.requests ADD COLUMN IF NOT EXISTS referenced_document_type TEXT;

-- Structured remittance (JSONB) — carries creditor references (SCOR, MCOR, etc.)
-- and referenced document information through the RTP lifecycle.
ALTER TABLE rtp.requests ADD COLUMN IF NOT EXISTS structured_remittance JSONB;

-- The database is provisioned per bank. Keep its identity across process restarts.
CREATE TABLE IF NOT EXISTS admin.batch_bank (
    singleton BOOLEAN PRIMARY KEY DEFAULT true CHECK (singleton),
    id UUID NOT NULL UNIQUE DEFAULT gen_random_uuid()
);
ALTER TABLE admin.batch_bank ADD COLUMN IF NOT EXISTS bank_timezone TEXT NOT NULL DEFAULT 'UTC';
INSERT INTO admin.batch_bank (singleton) VALUES (true) ON CONFLICT DO NOTHING;

ALTER TABLE admin.schedule_runs
    ADD COLUMN IF NOT EXISTS bank_instance_id UUID REFERENCES admin.batch_bank(id),
    ADD COLUMN IF NOT EXISTS bank_date DATE,
    ADD COLUMN IF NOT EXISTS bank_timezone TEXT,
    ADD COLUMN IF NOT EXISTS scheduled_for TIMESTAMPTZ,
    ADD COLUMN IF NOT EXISTS slot TIMESTAMPTZ,
    ADD COLUMN IF NOT EXISTS start_request JSONB;
-- A dated job has one slot at UTC midnight. Subdaily jobs retain their own slots.
CREATE UNIQUE INDEX IF NOT EXISTS schedule_runs_bank_slot
    ON admin.schedule_runs (bank_instance_id, schedule_id, slot);

-- #18. Bank-date identity is derived from the scheduled occurrence in the
-- bank calendar. Existing schedules keep their original (same-day) contract.
ALTER TABLE admin.schedules ADD COLUMN IF NOT EXISTS bank_date_offset SMALLINT
    NOT NULL DEFAULT 0 CHECK (bank_date_offset IN (-1,0));
INSERT INTO admin.schedules(name,definition_namespace,definition_name,definition_version,
                            schedule_type,cron_expression,enabled,bank_date_offset,description)
VALUES ('daily-savings-batch','default','daily-savings-batch','1.0.0','daily',
        '15 12 * * *',false,-1,'Settle savings for the previous local bank date')
ON CONFLICT (name) DO NOTHING;

CREATE TABLE IF NOT EXISTS core.savings_interest_batches (
    id UUID PRIMARY KEY, bank_instance_id UUID NOT NULL, bank_date DATE NOT NULL,
    bank_timezone TEXT NOT NULL, cutoff TIMESTAMPTZ NOT NULL, frozen_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    expected BIGINT NOT NULL DEFAULT 0, UNIQUE(bank_instance_id,bank_date)
);
CREATE TABLE IF NOT EXISTS core.savings_interest_batch_members (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    batch_id UUID NOT NULL REFERENCES core.savings_interest_batches(id),
    arrangement_id UUID NOT NULL, ledger_account_id UUID NOT NULL,
    definition_name TEXT, definition_version TEXT, lifecycle TEXT, enrolment_start DATE,
    state TEXT NOT NULL CHECK (state IN ('pending','started','posted','skipped','failed')),
    reason TEXT, child_instance_id UUID, next_poll_at TIMESTAMPTZ NOT NULL DEFAULT '-infinity',
    accrual_transaction_id UUID, capitalisation_transaction_id UUID,
    UNIQUE(batch_id,arrangement_id)
);
CREATE INDEX IF NOT EXISTS savings_interest_batch_dispatch ON core.savings_interest_batch_members
    (batch_id,state,next_poll_at,id);

-- Scheduler evidence from the observed Heart terminal instance. Older rows remain unverified.
ALTER TABLE admin.schedule_runs ADD COLUMN IF NOT EXISTS terminal_evidence JSONB;


-- Apply the closed-day calendar once. Later Helm upgrades must preserve operator edits.
CREATE TABLE IF NOT EXISTS admin.calendar_migrations (
    name TEXT PRIMARY KEY,
    applied_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
DO $calendar$
BEGIN
    INSERT INTO admin.calendar_migrations (name) VALUES ('closed-bank-day-v1')
    ON CONFLICT DO NOTHING;
    IF NOT FOUND THEN RETURN; END IF;

    -- Only move the stock EOD definition and calendar. Preserve an operator's enable switch.
    UPDATE admin.schedules
       SET definition_version='2.0.0', cron_expression='15 12 * * *', bank_date_offset=-1,
           last_run_at=GREATEST(COALESCE(last_run_at, created_at), now()), updated_at=now()
     WHERE name='eod-batch' AND definition_namespace='default' AND definition_name=name
       AND definition_version='1.0.0' AND schedule_type='daily' AND interval_seconds IS NULL
       AND bank_date_offset=0 AND cron_expression='0 23 * * *';

    IF FOUND THEN
        -- EOD owns both activities. Keep the standalone schedules for operator use.
        UPDATE admin.schedules
           SET enabled=false,
               definition_version=CASE name WHEN 'daily-reconciliation' THEN '2.0.0' ELSE definition_version END,
               bank_date_offset=CASE name WHEN 'daily-reconciliation' THEN -1 ELSE bank_date_offset END,
               cron_expression=CASE name WHEN 'daily-reconciliation'
               THEN '30 23 * * *' ELSE '45 23 * * *' END, updated_at=now()
         WHERE definition_namespace='default' AND definition_name=name
           AND schedule_type='daily' AND definition_version='1.0.0'
           AND bank_date_offset=0 AND interval_seconds IS NULL
           AND EXISTS (SELECT 1 FROM admin.schedules WHERE name='eod-batch' AND enabled)
           AND ((name='daily-reconciliation' AND cron_expression IN ('0 23 30 * *','30 23 * * *'))
             OR (name='daily-pnl' AND cron_expression IN ('0 23 45 * *','0 23 * * *')));

        INSERT INTO admin.schedule_dependencies (schedule_id, depends_on)
        SELECT eod.id, savings.id FROM admin.schedules eod, admin.schedules savings
         WHERE eod.name='eod-batch' AND savings.name='daily-savings-batch'
        ON CONFLICT DO NOTHING;
    END IF;

    -- A customised or parked EOD can leave the standalone plans in service.
    -- Repair the two exact published cron typos even in that configuration.
    UPDATE admin.schedules
       SET cron_expression=CASE name WHEN 'daily-reconciliation' THEN '30 23 * * *'
                                ELSE '45 23 * * *' END, updated_at=now()
     WHERE definition_namespace='default' AND definition_name=name AND definition_version='1.0.0'
       AND schedule_type='daily' AND bank_date_offset=0 AND interval_seconds IS NULL
       AND ((name='daily-reconciliation' AND cron_expression='0 23 30 * *')
         OR (name='daily-pnl' AND cron_expression='0 23 45 * *'));

    UPDATE admin.schedules
       SET definition_version='2.0.0', cron_expression='15 12 * * *', bank_date_offset=-1,
           last_run_at=GREATEST(COALESCE(last_run_at, created_at), now()), updated_at=now()
     WHERE name='daily-position' AND definition_namespace='default' AND definition_name=name
       AND definition_version='1.0.0' AND schedule_type='daily' AND interval_seconds IS NULL
       AND bank_date_offset=0 AND cron_expression='0 22 * * *';

    IF FOUND THEN
        INSERT INTO admin.schedule_dependencies (schedule_id, depends_on)
        SELECT position.id, savings.id FROM admin.schedules position, admin.schedules savings
         WHERE position.name='daily-position' AND savings.name='daily-savings-batch'
        UNION ALL
        SELECT eod.id, position.id FROM admin.schedules eod, admin.schedules position
         WHERE eod.name='eod-batch' AND eod.definition_namespace='default'
           AND eod.definition_name=eod.name AND eod.definition_version='2.0.0'
           AND eod.bank_date_offset=-1 AND eod.cron_expression='15 12 * * *' AND position.name='daily-position'
        ON CONFLICT DO NOTHING;
    END IF;

    -- Move the published month-end slot to the following month, preserving its enable switch.
    UPDATE admin.schedules
       SET cron_expression='15 13 1 * *', bank_date_offset=-1,
           last_run_at=GREATEST(COALESCE(last_run_at, created_at), now()), updated_at=now()
     WHERE name='month-end-close' AND definition_name='month-end-batch'
       AND definition_namespace='default' AND definition_version='1.0.0'
       AND schedule_type='month-end' AND interval_seconds IS NULL
       AND bank_date_offset=0 AND cron_expression='0 2 L * *';
END
$calendar$;

-- The original slot is retained on superseded EOD attempts. Only the active
-- attempt occupies the unique dispatch slot; all attempts remain audit rows.
ALTER TABLE admin.schedule_runs
    ADD COLUMN IF NOT EXISTS attempt_number INTEGER NOT NULL DEFAULT 1 CHECK (attempt_number > 0),
    ADD COLUMN IF NOT EXISTS retry_of UUID REFERENCES admin.schedule_runs(id),
    ADD COLUMN IF NOT EXISTS retry_reason TEXT,
    ADD COLUMN IF NOT EXISTS retry_actor UUID,
    ADD COLUMN IF NOT EXISTS superseded_slot TIMESTAMPTZ,
    ADD COLUMN IF NOT EXISTS failure_evidence JSONB;
CREATE UNIQUE INDEX IF NOT EXISTS schedule_runs_retry_of ON admin.schedule_runs(retry_of) WHERE retry_of IS NOT NULL;

-- Previously parked schedules keep their operator setting. Only change the known stock pin once.
WITH upgrade AS (
    INSERT INTO admin.calendar_migrations(name) VALUES ('month-end-batch-v2')
    ON CONFLICT DO NOTHING RETURNING name
)
UPDATE admin.schedules SET definition_version='2.0.0', updated_at=now()
WHERE EXISTS (SELECT 1 FROM upgrade) AND name='month-end-close' AND definition_namespace='default'
  AND definition_name='month-end-batch' AND definition_version='1.0.0'
  AND schedule_type='month-end' AND cron_expression='15 13 1 * *' AND bank_date_offset=-1;

CREATE INDEX IF NOT EXISTS savings_interest_days_period ON core.savings_interest_days(bank_date);
CREATE INDEX IF NOT EXISTS savings_interest_closures_period ON core.savings_interest_closures(bank_date)
    WHERE capitalisation_transaction_id IS NOT NULL;

-- A versioned post-sync activation records the prospective cutover as one transaction.
CREATE TABLE IF NOT EXISTS admin.bank_calendar_activations (
    version TEXT PRIMARY KEY,
    instance_id TEXT NOT NULL,
    activated_at TIMESTAMPTZ NOT NULL,
    first_bank_date DATE NOT NULL,
    first_close_month DATE NOT NULL,
    first_daily_run_at TIMESTAMPTZ NOT NULL,
    first_monthly_run_at TIMESTAMPTZ NOT NULL,
    legacy_savings_bound BIGINT NOT NULL,
    agreements_enrolled BIGINT NOT NULL
);

ALTER TABLE admin.bank_calendar_activations ADD COLUMN IF NOT EXISTS current_pins_repaired BIGINT NOT NULL DEFAULT 0;

-- Original journals and customer balances survive conversion. This receipt
-- captures their presentation at the opening of the new accounting system.
CREATE TABLE IF NOT EXISTS core.deposit_openings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    bank_instance_id UUID UNIQUE NOT NULL REFERENCES admin.batch_bank(id),
    bank_timezone TEXT NOT NULL, first_bank_date DATE NOT NULL, cutoff_at TIMESTAMPTZ NOT NULL,
    balances JSONB NOT NULL, account_count BIGINT NOT NULL, posting_count BIGINT NOT NULL
);
CREATE TABLE IF NOT EXISTS core.deposit_opening_transactions (
    transaction_id UUID PRIMARY KEY REFERENCES core.transactions(id),
    opening_id UUID NOT NULL REFERENCES core.deposit_openings(id)
);
CREATE TABLE IF NOT EXISTS core.deposit_opening_legs (
    posting_id UUID PRIMARY KEY REFERENCES core.postings(id), opening_id UUID NOT NULL REFERENCES core.deposit_openings(id),
    account_id UUID NOT NULL, currency TEXT NOT NULL, role TEXT NOT NULL, amount NUMERIC NOT NULL
);
CREATE OR REPLACE FUNCTION core.guard_opening_boundary() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE cutoff core.deposit_openings;
BEGIN
    SELECT * INTO cutoff FROM core.deposit_openings LIMIT 1;
    IF NOT FOUND THEN IF TG_OP='DELETE' THEN RETURN OLD; ELSE RETURN NEW; END IF; END IF;
    IF TG_TABLE_NAME='transactions' THEN
        IF TG_OP<>'INSERT' AND EXISTS(SELECT 1 FROM core.deposit_opening_transactions WHERE transaction_id=OLD.id) THEN
            RAISE EXCEPTION 'Source transaction belongs to certified opening';
        END IF;
        IF TG_OP<>'DELETE' AND (NEW.timestamp < cutoff.cutoff_at OR NEW.interest_bank_date<cutoff.first_bank_date) THEN
            RAISE EXCEPTION 'Posting predates the certified opening boundary';
        END IF;
    ELSE
        IF (TG_OP<>'INSERT' AND EXISTS(SELECT 1 FROM core.deposit_opening_transactions WHERE transaction_id=OLD.transaction_id))
          OR (TG_OP<>'DELETE' AND EXISTS(SELECT 1 FROM core.deposit_opening_transactions WHERE transaction_id=NEW.transaction_id)) THEN
            RAISE EXCEPTION 'Posting belongs to certified opening';
        END IF;
    END IF;
    IF TG_OP='DELETE' THEN RETURN OLD; ELSE RETURN NEW; END IF;
END
$$;
DROP TRIGGER IF EXISTS certified_opening_source ON core.transactions;
CREATE TRIGGER certified_opening_source BEFORE INSERT OR UPDATE OR DELETE ON core.transactions FOR EACH ROW EXECUTE FUNCTION core.guard_opening_boundary();
DROP TRIGGER IF EXISTS certified_opening_leg ON core.postings;
CREATE TRIGGER certified_opening_leg BEFORE INSERT OR UPDATE OR DELETE ON core.postings FOR EACH ROW EXECUTE FUNCTION core.guard_opening_boundary();
DROP TRIGGER IF EXISTS immutable_deposit_opening ON core.deposit_openings;
CREATE TRIGGER immutable_deposit_opening BEFORE UPDATE OR DELETE ON core.deposit_openings FOR EACH ROW EXECUTE FUNCTION core.reject_settled_interest_change();
DROP TRIGGER IF EXISTS immutable_deposit_opening_transactions ON core.deposit_opening_transactions;
CREATE TRIGGER immutable_deposit_opening_transactions BEFORE UPDATE OR DELETE ON core.deposit_opening_transactions FOR EACH ROW EXECUTE FUNCTION core.reject_settled_interest_change();
DROP TRIGGER IF EXISTS immutable_deposit_opening_legs ON core.deposit_opening_legs;
CREATE TRIGGER immutable_deposit_opening_legs BEFORE UPDATE OR DELETE ON core.deposit_opening_legs FOR EACH ROW EXECUTE FUNCTION core.reject_settled_interest_change();

ALTER TABLE core.deposit_openings ADD COLUMN IF NOT EXISTS captured_xid xid8 NOT NULL DEFAULT pg_current_xact_id();
CREATE OR REPLACE FUNCTION core.guard_opening_membership() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
    IF NOT EXISTS(SELECT 1 FROM core.deposit_openings WHERE id=NEW.opening_id AND captured_xid=pg_current_xact_id()) THEN
        RAISE EXCEPTION 'Certified opening membership is sealed';
    END IF;
    RETURN NEW;
END
$$;
DROP TRIGGER IF EXISTS seal_opening_transactions ON core.deposit_opening_transactions;
CREATE TRIGGER seal_opening_transactions BEFORE INSERT ON core.deposit_opening_transactions FOR EACH ROW EXECUTE FUNCTION core.guard_opening_membership();
DROP TRIGGER IF EXISTS seal_opening_legs ON core.deposit_opening_legs;
CREATE TRIGGER seal_opening_legs BEFORE INSERT ON core.deposit_opening_legs FOR EACH ROW EXECUTE FUNCTION core.guard_opening_membership();
-- Scheduling waits for the actual Accounting opening receipt matching the approval.
CREATE TABLE IF NOT EXISTS admin.bank_calendar_opening_releases (
    version TEXT PRIMARY KEY REFERENCES admin.bank_calendar_activations(version),
    bank_instance_id UUID NOT NULL REFERENCES admin.batch_bank(id),
    opening_id UUID NOT NULL,
    first_bank_date DATE NOT NULL,
    sha256 TEXT NOT NULL CHECK (sha256 ~ '^[0-9a-f]{64}$'),
    approved_by TEXT NOT NULL,
    released_at TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp()
);

DROP TRIGGER IF EXISTS immutable_bank_calendar_activation ON admin.bank_calendar_activations;
CREATE TRIGGER immutable_bank_calendar_activation BEFORE UPDATE OR DELETE ON admin.bank_calendar_activations
    FOR EACH ROW EXECUTE FUNCTION core.reject_settled_interest_change();
DROP TRIGGER IF EXISTS immutable_bank_calendar_opening_release ON admin.bank_calendar_opening_releases;
CREATE TRIGGER immutable_bank_calendar_opening_release BEFORE UPDATE OR DELETE ON admin.bank_calendar_opening_releases
    FOR EACH ROW EXECUTE FUNCTION core.reject_settled_interest_change();

-- Core observes retired first-node v1 reads. Original scheduler rows, Heart
-- instances, and unpicked assignments retain their actual state.
CREATE TABLE IF NOT EXISTS admin.calendar_retired_reports (
    version TEXT NOT NULL REFERENCES admin.bank_calendar_activations(version),
    schedule_run_id UUID PRIMARY KEY REFERENCES admin.schedule_runs(id),
    instance_id UUID UNIQUE NOT NULL, work_item_id UUID UNIQUE NOT NULL,
    evidence JSONB NOT NULL, observed_at TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp()
);
DROP TRIGGER IF EXISTS immutable_calendar_retired_reports ON admin.calendar_retired_reports;
CREATE TRIGGER immutable_calendar_retired_reports BEFORE UPDATE OR DELETE ON admin.calendar_retired_reports
FOR EACH ROW EXECUTE FUNCTION core.reject_settled_interest_change();
