-- Immutable starter identity for whole-instance cancellation authorization.
-- No backfill: phase-one v2 rows were offline contract fixtures, not executions.
CREATE TABLE IF NOT EXISTS heart.v2_instance_owner (
    instance_id UUID PRIMARY KEY REFERENCES heart.v2_instance(id),
    actor_id UUID NOT NULL CHECK (actor_id <> '00000000-0000-0000-0000-000000000000')
);
