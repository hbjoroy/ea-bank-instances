-- Heart — Idempotent Schema Initialization
-- Safe to run on every startup. Creates tables/indexes only if missing.

CREATE SCHEMA IF NOT EXISTS heart;

-- ═══════════════════════════════════════════════════════════════
-- Enum types (created only if they don't already exist)
-- ═══════════════════════════════════════════════════════════════

DO $$ BEGIN
    CREATE TYPE heart.instance_status AS ENUM (
        'running', 'waiting', 'completed', 'failed', 'cancelled'
    );
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
    CREATE TYPE heart.work_item_status AS ENUM (
        'pending', 'processing', 'completed', 'failed'
    );
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

-- ═══════════════════════════════════════════════════════════════
-- Process Definitions
-- ═══════════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS heart.definition (
    id              UUID PRIMARY KEY,
    name            TEXT NOT NULL,
    namespace       TEXT NOT NULL DEFAULT 'default',
    version         TEXT NOT NULL,
    description     TEXT,
    source_yaml     TEXT NOT NULL,
    parsed_json     JSONB NOT NULL,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),

    CONSTRAINT uq_definition_ns_name_version UNIQUE (namespace, name, version),
    CONSTRAINT ck_definition_name CHECK (name ~ '^[a-z][a-z0-9-]*[a-z0-9]$'),
    CONSTRAINT ck_definition_namespace CHECK (namespace ~ '^[a-z][a-z0-9-]*[a-z0-9]$')
);

CREATE INDEX IF NOT EXISTS idx_definition_ns_name ON heart.definition (namespace, name);

-- ═══════════════════════════════════════════════════════════════
-- Process Instances
-- ═══════════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS heart.instance (
    id              UUID PRIMARY KEY,
    definition_id   UUID NOT NULL,
    namespace       TEXT NOT NULL DEFAULT 'default',
    status          heart.instance_status NOT NULL DEFAULT 'running',
    current_node    TEXT NOT NULL,
    metadata        JSONB NOT NULL DEFAULT '{}',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    completed_at    TIMESTAMPTZ,

    CONSTRAINT fk_instance_definition
        FOREIGN KEY (definition_id) REFERENCES heart.definition(id)
);

CREATE INDEX IF NOT EXISTS idx_instance_definition_id ON heart.instance (definition_id);
CREATE INDEX IF NOT EXISTS idx_instance_status ON heart.instance (status);
CREATE INDEX IF NOT EXISTS idx_instance_created_at ON heart.instance (created_at);
CREATE INDEX IF NOT EXISTS idx_instance_namespace ON heart.instance (namespace);

-- ═══════════════════════════════════════════════════════════════
-- Transition Log
-- ═══════════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS heart.transition (
    id              UUID PRIMARY KEY,
    instance_id     UUID NOT NULL,
    seq             INTEGER NOT NULL,
    from_node       TEXT NOT NULL,
    to_node         TEXT NOT NULL,
    metadata_snapshot JSONB NOT NULL,
    transitioned_at TIMESTAMPTZ NOT NULL DEFAULT now(),

    CONSTRAINT uq_transition_instance_seq UNIQUE (instance_id, seq),
    CONSTRAINT fk_transition_instance
        FOREIGN KEY (instance_id) REFERENCES heart.instance(id)
);

CREATE INDEX IF NOT EXISTS idx_transition_instance_id ON heart.transition (instance_id);
CREATE INDEX IF NOT EXISTS idx_transition_transitioned_at ON heart.transition (transitioned_at);

-- ═══════════════════════════════════════════════════════════════
-- Work Queue
-- ═══════════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS heart.work_item (
    id              UUID PRIMARY KEY,
    instance_id     UUID NOT NULL,
    namespace       TEXT NOT NULL DEFAULT 'default',
    queue_name      TEXT NOT NULL,
    node_id         TEXT NOT NULL,
    status          heart.work_item_status NOT NULL DEFAULT 'pending',
    metadata        JSONB NOT NULL,
    result_metadata JSONB,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    picked_at       TIMESTAMPTZ,
    completed_at    TIMESTAMPTZ,

    CONSTRAINT fk_work_item_instance
        FOREIGN KEY (instance_id) REFERENCES heart.instance(id)
);

CREATE INDEX IF NOT EXISTS idx_work_item_ns_queue_status ON heart.work_item (namespace, queue_name, status);
CREATE INDEX IF NOT EXISTS idx_work_item_instance_id ON heart.work_item (instance_id);

-- ═══════════════════════════════════════════════════════════════
-- Instance Archive
-- ═══════════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS heart.instance_archive (
    id                  UUID PRIMARY KEY,
    definition_id       UUID NOT NULL,
    definition_name     TEXT NOT NULL,
    namespace           TEXT NOT NULL DEFAULT 'default',
    definition_version  TEXT NOT NULL,
    status              heart.instance_status NOT NULL,
    final_node          TEXT NOT NULL,
    metadata            JSONB NOT NULL,
    transitions         JSONB NOT NULL,
    created_at          TIMESTAMPTZ NOT NULL,
    completed_at        TIMESTAMPTZ NOT NULL,
    archived_at         TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_instance_archive_ns_definition
    ON heart.instance_archive (namespace, definition_name, definition_version);
CREATE INDEX IF NOT EXISTS idx_instance_archive_completed_at
    ON heart.instance_archive (completed_at);

-- ═══════════════════════════════════════════════════════════════
-- Message Subscriptions (receive nodes)
-- ═══════════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS heart.message_subscription (
    id                UUID        PRIMARY KEY,
    instance_id       UUID        NOT NULL REFERENCES heart.instance(id),
    namespace         TEXT        NOT NULL,
    node_id           TEXT        NOT NULL,
    correlation_key   TEXT        NOT NULL,
    correlation_value TEXT        NOT NULL,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_message_sub_ns_key_value
    ON heart.message_subscription (namespace, correlation_key, correlation_value);
CREATE INDEX IF NOT EXISTS idx_message_sub_instance
    ON heart.message_subscription (instance_id);
-- ═══════════════════════════════════════════════════════════════
-- Instance start keys (caller-scoped start idempotency)
-- ═══════════════════════════════════════════════════════════════
-- Mirrors migrations/004_idempotent_instance_start.sql. Both paths must be kept
-- in sync: this const is what a plain `heart-api` start applies, while
-- `heart-api migrate` applies migrations/ through sqlx. A table added to only
-- one of them is missing on half the deployments.

CREATE TABLE IF NOT EXISTS heart.instance_start_key (
    namespace       TEXT        NOT NULL,
    client_id       TEXT        NOT NULL,
    idempotency_key TEXT        NOT NULL,
    definition_id   UUID        NOT NULL,
    metadata        JSONB       NOT NULL,
    instance_id     UUID        NOT NULL,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (namespace, client_id, idempotency_key)
);

CREATE INDEX IF NOT EXISTS idx_instance_start_key_instance
    ON heart.instance_start_key (instance_id);
