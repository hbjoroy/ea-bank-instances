-- V2 work lives in separate tables: a v1 worker cannot claim it accidentally.
-- Existing definitions/instances retain v1 semantics. No instance conversion.
ALTER TABLE heart.definition ADD COLUMN IF NOT EXISTS runtime_model TEXT NOT NULL DEFAULT 'v1';
ALTER TABLE heart.instance ADD COLUMN IF NOT EXISTS runtime_model TEXT NOT NULL DEFAULT 'v1';

DO $$ BEGIN
    ALTER TABLE heart.definition ADD CONSTRAINT definition_runtime_model
        CHECK (runtime_model IN ('v1', 'v2') AND
            runtime_model = COALESCE(parsed_json->>'runtime', 'v1'));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
CREATE UNIQUE INDEX IF NOT EXISTS definition_id_runtime ON heart.definition(id, runtime_model);
DO $$ BEGIN
    ALTER TABLE heart.instance ADD CONSTRAINT instance_runtime_v1 CHECK (runtime_model = 'v1');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
    ALTER TABLE heart.instance ADD CONSTRAINT instance_definition_runtime
        FOREIGN KEY (definition_id, runtime_model) REFERENCES heart.definition(id, runtime_model);
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE TABLE IF NOT EXISTS heart.v2_instance (
    id UUID PRIMARY KEY,
    definition_id UUID NOT NULL,
    runtime_model TEXT NOT NULL DEFAULT 'v2' CHECK (runtime_model = 'v2'),
    namespace TEXT NOT NULL,
    status heart.instance_status NOT NULL DEFAULT 'running',
    revision BIGINT NOT NULL DEFAULT 0 CHECK (revision >= 0),
    input_metadata JSONB NOT NULL CHECK (jsonb_typeof(input_metadata) = 'object'
        AND octet_length(input_metadata::text) <= 262144),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    completed_at TIMESTAMPTZ,
    FOREIGN KEY (definition_id, runtime_model) REFERENCES heart.definition(id, runtime_model)
);
CREATE INDEX IF NOT EXISTS v2_instance_status ON heart.v2_instance(status, created_at);

CREATE TABLE IF NOT EXISTS heart.v2_fork (
    id UUID PRIMARY KEY,
    instance_id UUID NOT NULL REFERENCES heart.v2_instance(id),
    origin_activation_id UUID NOT NULL UNIQUE CHECK (id = origin_activation_id),
    fork_node_id TEXT NOT NULL,
    join_node_id TEXT NOT NULL,
    parent_metadata JSONB NOT NULL CHECK (jsonb_typeof(parent_metadata) = 'object'
        AND octet_length(parent_metadata::text) <= 262144),
    status TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'joined', 'cancelled', 'failed')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (id, instance_id)
);
CREATE TABLE IF NOT EXISTS heart.v2_fork_branch (
    fork_id UUID NOT NULL,
    instance_id UUID NOT NULL,
    branch_key TEXT NOT NULL CHECK (branch_key ~ '^[a-z][a-z0-9-]*[a-z0-9]$'
        AND length(branch_key) BETWEEN 2 AND 64),
    PRIMARY KEY (fork_id, branch_key),
    UNIQUE (fork_id, instance_id, branch_key),
    FOREIGN KEY (fork_id, instance_id) REFERENCES heart.v2_fork(id, instance_id)
);

-- Ready rows are durable continuations, not an in-memory notification queue.
CREATE TABLE IF NOT EXISTS heart.v2_activation (
    id UUID PRIMARY KEY,
    instance_id UUID NOT NULL REFERENCES heart.v2_instance(id),
    node_id TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'ready'
        CHECK (status IN ('ready', 'leased', 'waiting', 'consumed', 'cancelled', 'failed')),
    metadata JSONB NOT NULL CHECK (jsonb_typeof(metadata) = 'object'
        AND octet_length(metadata::text) <= 262144),
    fork_id UUID,
    branch_key TEXT,
    revision BIGINT NOT NULL DEFAULT 0 CHECK (revision >= 0),
    lease_token UUID,
    lease_until TIMESTAMPTZ,
    ready_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    completed_at TIMESTAMPTZ,
    result_metadata JSONB CHECK (jsonb_typeof(result_metadata) = 'object'
        AND octet_length(result_metadata::text) <= 262144),
    UNIQUE (id, instance_id),
    UNIQUE (id, instance_id, fork_id, branch_key),
    CHECK ((fork_id IS NULL) = (branch_key IS NULL)),
    CHECK ((status = 'leased') = (lease_token IS NOT NULL AND lease_until IS NOT NULL)),
    CHECK ((lease_token IS NULL) = (lease_until IS NULL)),
    FOREIGN KEY (fork_id, instance_id, branch_key)
        REFERENCES heart.v2_fork_branch(fork_id, instance_id, branch_key)
);
CREATE INDEX IF NOT EXISTS v2_activation_ready ON heart.v2_activation(ready_at, id)
    WHERE status = 'ready';
CREATE INDEX IF NOT EXISTS v2_activation_expired_lease ON heart.v2_activation(lease_until, id)
    WHERE status = 'leased';
CREATE INDEX IF NOT EXISTS v2_activation_instance ON heart.v2_activation(instance_id);
DO $$ BEGIN
    ALTER TABLE heart.v2_fork ADD CONSTRAINT v2_fork_origin
        FOREIGN KEY (origin_activation_id, instance_id)
        REFERENCES heart.v2_activation(id, instance_id) DEFERRABLE INITIALLY DEFERRED;
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE TABLE IF NOT EXISTS heart.v2_join_arrival (
    fork_id UUID NOT NULL,
    instance_id UUID NOT NULL,
    branch_key TEXT NOT NULL,
    activation_id UUID NOT NULL UNIQUE,
    result_metadata JSONB NOT NULL CHECK (jsonb_typeof(result_metadata) = 'object'
        AND octet_length(result_metadata::text) <= 262144),
    arrived_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (fork_id, branch_key),
    FOREIGN KEY (fork_id, instance_id, branch_key)
        REFERENCES heart.v2_fork_branch(fork_id, instance_id, branch_key),
    FOREIGN KEY (activation_id, instance_id, fork_id, branch_key)
        REFERENCES heart.v2_activation(id, instance_id, fork_id, branch_key)
);

CREATE TABLE IF NOT EXISTS heart.v2_user_task (
    id UUID PRIMARY KEY,
    instance_id UUID NOT NULL,
    activation_id UUID NOT NULL UNIQUE CHECK (id = activation_id),
    assignee_id UUID NOT NULL CHECK (assignee_id <> '00000000-0000-0000-0000-000000000000'),
    status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'completed', 'cancelled')),
    result_metadata JSONB CHECK (jsonb_typeof(result_metadata) = 'object'
        AND octet_length(result_metadata::text) <= 262144),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    completed_at TIMESTAMPTZ,
    cancelled_at TIMESTAMPTZ,
    FOREIGN KEY (activation_id, instance_id) REFERENCES heart.v2_activation(id, instance_id)
);
CREATE INDEX IF NOT EXISTS v2_user_task_instance ON heart.v2_user_task(instance_id, created_at);
CREATE INDEX IF NOT EXISTS v2_user_task_assignee ON heart.v2_user_task(assignee_id, created_at)
    WHERE status = 'pending';

CREATE TABLE IF NOT EXISTS heart.v2_start_receipt (
    namespace TEXT NOT NULL,
    client_id TEXT NOT NULL CHECK (length(client_id) BETWEEN 1 AND 128),
    idempotency_key TEXT NOT NULL CHECK (length(idempotency_key) BETWEEN 1 AND 128),
    instance_id UUID NOT NULL UNIQUE REFERENCES heart.v2_instance(id),
    request JSONB NOT NULL CHECK (jsonb_typeof(request) = 'object'),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (namespace, client_id, idempotency_key)
);
CREATE TABLE IF NOT EXISTS heart.v2_command_receipt (
    instance_id UUID NOT NULL REFERENCES heart.v2_instance(id),
    client_id TEXT NOT NULL CHECK (length(client_id) BETWEEN 1 AND 128),
    idempotency_key TEXT NOT NULL CHECK (length(idempotency_key) BETWEEN 1 AND 128),
    actor_id UUID NOT NULL,
    request JSONB NOT NULL CHECK (jsonb_typeof(request) = 'object'),
    response JSONB NOT NULL CHECK (jsonb_typeof(response) = 'object'),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (instance_id, client_id, idempotency_key)
);
CREATE TABLE IF NOT EXISTS heart.v2_transition (
    id UUID PRIMARY KEY,
    instance_id UUID NOT NULL REFERENCES heart.v2_instance(id),
    seq BIGINT NOT NULL CHECK (seq > 0),
    activation_id UUID,
    event_type TEXT NOT NULL,
    body JSONB NOT NULL CHECK (jsonb_typeof(body) = 'object'),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (instance_id, seq),
    FOREIGN KEY (activation_id, instance_id) REFERENCES heart.v2_activation(id, instance_id)
);
