-- Task IDs are activation IDs. A completion and successor activation are atomic.
CREATE TABLE IF NOT EXISTS heart.user_task (
    id UUID PRIMARY KEY,
    instance_id UUID NOT NULL REFERENCES heart.instance(id) ON DELETE CASCADE,
    status TEXT NOT NULL CHECK (status IN ('pending', 'completed')),
    body JSONB NOT NULL,
    completion_command JSONB
);
CREATE UNIQUE INDEX IF NOT EXISTS user_task_one_active
    ON heart.user_task(instance_id) WHERE status = 'pending';
CREATE INDEX IF NOT EXISTS user_task_instance ON heart.user_task(instance_id);
