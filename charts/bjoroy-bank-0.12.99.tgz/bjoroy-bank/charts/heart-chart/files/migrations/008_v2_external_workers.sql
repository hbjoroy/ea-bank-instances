-- External jobs are isolated from v1 queues and v2's internal scheduler leases.
CREATE TABLE IF NOT EXISTS heart.v2_external_job (
    id UUID PRIMARY KEY,
    instance_id UUID NOT NULL,
    namespace TEXT NOT NULL,
    task_type TEXT NOT NULL,
    contract_version INTEGER NOT NULL CHECK (contract_version > 0),
    input JSONB NOT NULL CHECK (jsonb_typeof(input) = 'object' AND octet_length(input::text) <= 262144),
    status TEXT NOT NULL DEFAULT 'queued'
        CHECK (status IN ('queued', 'leased', 'completed', 'failed', 'cancelled')),
    attempt INTEGER NOT NULL DEFAULT 0 CHECK (attempt >= 0),
    available_at TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    last_claimed_at TIMESTAMPTZ,
    finished_at TIMESTAMPTZ,
    lease_principal TEXT,
    lease_fingerprint BYTEA CHECK (octet_length(lease_fingerprint) = 32),
    lease_expires_at TIMESTAMPTZ,
    lease_deadline TIMESTAMPTZ,
    failure_code TEXT CHECK (failure_code ~ '^[a-z][a-z0-9_-]{0,63}$'),
    CHECK (num_nonnulls(lease_principal, lease_fingerprint, lease_expires_at, lease_deadline)
        = CASE WHEN status = 'leased' THEN 4 ELSE 0 END),
    CHECK (status <> 'leased' OR attempt > 0),
    CHECK ((attempt > 0) = (last_claimed_at IS NOT NULL)),
    CHECK ((status IN ('completed', 'failed', 'cancelled')) = (finished_at IS NOT NULL)),
    CHECK (lease_expires_at <= lease_deadline),
    FOREIGN KEY (id, instance_id) REFERENCES heart.v2_activation(id, instance_id)
);

CREATE INDEX IF NOT EXISTS v2_external_job_ready
    ON heart.v2_external_job(namespace, task_type, contract_version, available_at, id)
    WHERE status = 'queued';
CREATE INDEX IF NOT EXISTS v2_external_job_expired
    ON heart.v2_external_job(lease_expires_at, id)
    WHERE status = 'leased';
CREATE INDEX IF NOT EXISTS v2_external_job_principal
    ON heart.v2_external_job(lease_principal, lease_expires_at)
    WHERE status = 'leased';
CREATE INDEX IF NOT EXISTS v2_external_job_active_instance
    ON heart.v2_external_job(instance_id)
    WHERE status IN ('queued', 'leased');
CREATE INDEX IF NOT EXISTS v2_external_job_recent_failure
    ON heart.v2_external_job(finished_at)
    WHERE status = 'failed';

CREATE TABLE IF NOT EXISTS heart.v2_external_job_receipt (
    job_id UUID NOT NULL REFERENCES heart.v2_external_job(id),
    principal TEXT NOT NULL,
    idempotency_key TEXT NOT NULL CHECK (octet_length(idempotency_key) BETWEEN 1 AND 128),
    lease_fingerprint BYTEA NOT NULL CHECK (octet_length(lease_fingerprint) = 32),
    request JSONB NOT NULL CHECK (jsonb_typeof(request) = 'object'),
    response JSONB NOT NULL CHECK (jsonb_typeof(response) = 'object'),
    created_at TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    PRIMARY KEY (job_id, principal, idempotency_key)
);
