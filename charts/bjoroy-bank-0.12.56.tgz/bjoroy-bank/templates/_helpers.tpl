{{/*
Service name — use plain service name (namespace provides isolation).
*/}}
{{- define "bjoroy-bank.serviceName" -}}
{{- . -}}
{{- end }}

{{/*
Common labels
*/}}
{{- define "bjoroy-bank.labels" -}}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Values.global.imageTag | default .Chart.AppVersion | quote }}
helm.sh/chart: {{ .Chart.Name }}-{{ .Chart.Version }}
{{- end }}

{{/*
Full image reference
*/}}
{{- define "bjoroy-bank.image" -}}
{{ .Values.global.imageRegistry }}/{{ .image }}:{{ .Values.global.imageTag | default .Chart.AppVersion }}
{{- end }}

{{/*
Validate instanceId — REQUIRED, no default instance concept.
Reads from global.instanceId so it flows to subcharts automatically.
*/}}
{{- define "bjoroy-bank.instanceId" -}}
{{- required "global.instanceId is required. Set --set global.instanceId=<name> (e.g. --set global.instanceId=minoa)" .Values.global.instanceId -}}
{{- end }}

{{/*
Postgres-safe identifier — replaces hyphens with underscores.
Postgres identifiers with hyphens require quoting everywhere; underscores don't.
*/}}
{{- define "bjoroy-bank.pgIdentifier" -}}
{{- . | replace "-" "_" -}}
{{- end }}

{{/*
Bank database name — always prefixed: {instanceId}_bank
*/}}
{{- define "bjoroy-bank.dbName" -}}
{{- include "bjoroy-bank.pgIdentifier" (include "bjoroy-bank.instanceId" .) }}_bank
{{- end }}

{{/*
Database user — one per instance: {instanceId}_bank
*/}}
{{- define "bjoroy-bank.dbUser" -}}
{{- include "bjoroy-bank.pgIdentifier" (include "bjoroy-bank.instanceId" .) }}_bank
{{- end }}

{{/*
Heart database name: {instanceId}_heart
*/}}
{{- define "bjoroy-bank.heartDbName" -}}
{{- include "bjoroy-bank.pgIdentifier" (include "bjoroy-bank.instanceId" .) }}_heart
{{- end }}

{{/*
Customer database name: {instanceId}_customer
*/}}
{{- define "bjoroy-bank.customerDbName" -}}
{{- include "bjoroy-bank.pgIdentifier" (include "bjoroy-bank.instanceId" .) }}_customer
{{- end }}

{{/*
Accounting database name: {instanceId}_accounting
*/}}
{{- define "bjoroy-bank.accountingDbName" -}}
{{- include "bjoroy-bank.pgIdentifier" (include "bjoroy-bank.instanceId" .) }}_accounting
{{- end }}

{{/*
Treasury database name: {instanceId}_treasury
*/}}
{{- define "bjoroy-bank.treasuryDbName" -}}
{{- include "bjoroy-bank.pgIdentifier" (include "bjoroy-bank.instanceId" .) }}_treasury
{{- end }}

{{/*
Database credentials secret — created by the setup job.
Name is {release}-db-credentials.
*/}}
{{- define "bjoroy-bank.dbCredentialsSecret" -}}
{{ .Release.Name }}-db-credentials
{{- end }}

{{/*
Database URL — uses the generated credentials secret
*/}}
{{- define "bjoroy-bank.databaseUrl" -}}
postgres://{{ include "bjoroy-bank.dbUser" . }}:$(DB_PASSWORD)@{{ .Values.database.host }}:{{ .Values.database.port }}/{{ include "bjoroy-bank.dbName" . }}
{{- end }}

{{/*
Selector labels for a component
*/}}
{{- define "bjoroy-bank.selectorLabels" -}}
app.kubernetes.io/name: {{ .name }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Definitions registry URL — local Zot when enabled, else configured registry
*/}}
{{- define "bjoroy-bank.definitionsRegistry" -}}
{{- if .Values.zot.enabled -}}
{{ .Release.Name }}-zot:{{ .Values.zot.port }}
{{- else -}}
{{ .Values.definitions.registry }}
{{- end -}}
{{- end }}

{{/*
Definitions registry secret name — auto-generated Zot secret or user-specified
*/}}
{{- define "bjoroy-bank.definitionsRegistrySecret" -}}
{{- if .Values.zot.enabled -}}
{{ .Release.Name }}-zot-credentials
{{- else -}}
{{ .Values.definitions.registrySecret }}
{{- end -}}
{{- end }}

{{/*
Definitions registry URL with scheme — for OCI Distribution HTTP API
Local Zot uses http://, external uses https://
*/}}
{{- define "bjoroy-bank.definitionsRegistryScheme" -}}
{{- if .Values.zot.enabled -}}
http://{{ .Release.Name }}-zot:{{ .Values.zot.port }}
{{- else -}}
https://{{ .Values.definitions.registry }}
{{- end -}}
{{- end }}

{{/*
Definitions credentials secret — opaque secret with username/password keys.
Priority: zot-credentials → user-specified → auto-generated from --set.
*/}}
{{- define "bjoroy-bank.definitionsCredentialsSecret" -}}
{{- if .Values.zot.enabled -}}
{{ .Release.Name }}-zot-credentials
{{- else if .Values.definitions.credentialsSecret -}}
{{ .Values.definitions.credentialsSecret }}
{{- else -}}
{{ .Release.Name }}-oci-credentials
{{- end -}}
{{- end }}
