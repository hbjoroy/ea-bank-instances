-- Banking platform schema baseline.
-- Each service gets its own schema for logical separation.
--
-- NOTE: Database creation is handled by the setup job (job-setup.yaml)
-- with instance-scoped names. This script only manages schemas and tables
-- within the bank database.

-- ============================================================
-- EXTENSIONS
-- ============================================================

CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE EXTENSION IF NOT EXISTS btree_gist;

-- ============================================================
-- SCHEMAS
-- ============================================================

CREATE SCHEMA IF NOT EXISTS core;
CREATE SCHEMA IF NOT EXISTS payments;
CREATE SCHEMA IF NOT EXISTS channels;
CREATE SCHEMA IF NOT EXISTS admin;

-- ============================================================
-- CORE SCHEMA
-- ============================================================

-- Banking institutions (BIC registry)
CREATE TABLE IF NOT EXISTS core.banking_institutions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    bic VARCHAR(11) NOT NULL UNIQUE,           -- ISO 9362 BIC (8 or 11 chars)
    name VARCHAR(255) NOT NULL,
    country_code VARCHAR(2) NOT NULL DEFAULT 'NO',
    is_own BOOLEAN NOT NULL DEFAULT false,      -- true = this is our bank
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Institution prefixes — generic routing/identification codes assigned to an institution.
-- Covers Norwegian bank registration numbers (BKREG, 4-digit), EMV BINs (BIN, 6-8 digit),
-- SWIFT routing codes, and any future prefix scheme.
-- Each prefix carries JSONB tags for metadata (brand, usage, etc.).
-- Norwegian: "registreringsnummer" / "bankregnummer".
CREATE TABLE IF NOT EXISTS core.institution_prefixes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    institution_id UUID NOT NULL REFERENCES core.banking_institutions(id),
    prefix_type VARCHAR(10) NOT NULL,           -- BKREG, BIN, SWIFT, etc.
    prefix_value VARCHAR(20) NOT NULL,          -- e.g. '3688', '45717360'
    tags JSONB NOT NULL DEFAULT '[]',           -- metadata: [{"brand":"Bjorøy Bank"},{"usage":"current"}]
    status VARCHAR(20) NOT NULL DEFAULT 'active',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT chk_prefix_type CHECK (prefix_type IN ('BKREG', 'BIN', 'SWIFT')),
    UNIQUE (prefix_type, prefix_value)
);

-- Account number series (BBAN ranges managed by a bank)
CREATE TABLE IF NOT EXISTS core.account_number_series (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    institution_id UUID NOT NULL REFERENCES core.banking_institutions(id),
    prefix_id UUID REFERENCES core.institution_prefixes(id), -- link to registered prefix
    name VARCHAR(100) NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    bank_reg_number VARCHAR(4) NOT NULL,       -- Norwegian: 4-digit bank registration number
    range_start INT NOT NULL,                  -- Start of 6-digit range (e.g. 110000)
    range_end INT NOT NULL,                    -- End of 6-digit range   (e.g. 112999)
    next_number INT NOT NULL,                  -- Next number to allocate from this series
    country_code VARCHAR(2) NOT NULL DEFAULT 'NO',
    currency VARCHAR(3) NOT NULL DEFAULT 'NOK',
    status VARCHAR(20) NOT NULL DEFAULT 'active',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT chk_range CHECK (range_start <= range_end),
    CONSTRAINT chk_next CHECK (next_number >= range_start AND next_number <= range_end + 1)
);

-- Prevent overlapping account number series for the same prefix.
-- Uses an exclusion constraint with int4range to block overlapping ranges.
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint WHERE conname = 'excl_series_range_overlap'
    ) THEN
        ALTER TABLE core.account_number_series
            ADD CONSTRAINT excl_series_range_overlap
            EXCLUDE USING gist (
                prefix_id WITH =,
                int4range(range_start, range_end, '[]') WITH &&
            ) WHERE (status = 'active');
    END IF;
END
$$;

-- Account numbers (allocated BBANs with lifecycle tracking)
-- States: reserved → active → deleted
-- Transitions: reserved→active, reserved→unused (delete row), active→deleted
-- Deleted numbers cannot be reused for 10 years.
CREATE TABLE IF NOT EXISTS core.account_numbers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    series_id UUID NOT NULL REFERENCES core.account_number_series(id),
    bban VARCHAR(11) NOT NULL UNIQUE,          -- Full 11-digit BBAN (bank_reg + 6 digits + check)
    iban VARCHAR(15) NOT NULL UNIQUE,          -- Calculated: NOkk + BBAN
    status VARCHAR(20) NOT NULL DEFAULT 'reserved',
    reserved_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    activated_at TIMESTAMPTZ,
    deleted_at TIMESTAMPTZ,
    CONSTRAINT chk_account_number_status CHECK (status IN ('reserved', 'active', 'deleted'))
);

-- Ledger accounts (internal bookkeeping unit)
-- Sub-account hierarchy: parent_account_id links sub-accounts to their parent.
CREATE TABLE IF NOT EXISTS core.ledger_accounts (
    id UUID PRIMARY KEY,
    account_type VARCHAR(20) NOT NULL,
    currency VARCHAR(3) NOT NULL DEFAULT 'NOK',
    parent_account_id UUID REFERENCES core.ledger_accounts(id),
    account_subtype VARCHAR(40),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_ledger_accounts_parent
    ON core.ledger_accounts (parent_account_id)
    WHERE parent_account_id IS NOT NULL;

-- Transactions (groups postings)
CREATE TABLE IF NOT EXISTS core.transactions (
    id UUID PRIMARY KEY,
    reference VARCHAR(255) NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    timestamp TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Postings (individual debit/credit entries)
-- Positive = debit, negative = credit
CREATE TABLE IF NOT EXISTS core.postings (
    id UUID PRIMARY KEY,
    transaction_id UUID NOT NULL REFERENCES core.transactions(id),
    account_id UUID NOT NULL REFERENCES core.ledger_accounts(id),
    amount NUMERIC(19, 4) NOT NULL,
    currency VARCHAR(3) NOT NULL DEFAULT 'NOK'
);

-- Enforce double-entry: every transaction's postings must sum to zero.
-- This is checked via a trigger rather than a check constraint,
-- because the constraint must span multiple rows.
CREATE OR REPLACE FUNCTION core.check_transaction_balance()
RETURNS TRIGGER AS $$
BEGIN
    IF (SELECT COALESCE(SUM(amount), 0) FROM core.postings WHERE transaction_id = NEW.transaction_id) != 0 THEN
        RAISE EXCEPTION 'Transaction % postings do not balance to zero', NEW.transaction_id;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Note: This trigger fires per-statement after all postings for a batch insert.
-- For row-level inserts, balance is validated in application logic before commit.
DROP TRIGGER IF EXISTS trg_check_balance ON core.postings;
CREATE CONSTRAINT TRIGGER trg_check_balance
    AFTER INSERT ON core.postings
    DEFERRABLE INITIALLY DEFERRED
    FOR EACH ROW
    EXECUTE FUNCTION core.check_transaction_balance();

-- Products catalog
CREATE TABLE IF NOT EXISTS core.products (
    id UUID PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    product_type VARCHAR(20) NOT NULL,
    default_currency VARCHAR(3) NOT NULL DEFAULT 'NOK',
    default_interest_rate NUMERIC(8, 6) NOT NULL,
    default_account_number_series_id UUID REFERENCES core.account_number_series(id)
);

CREATE UNIQUE INDEX IF NOT EXISTS uq_product_name
    ON core.products (name);

-- Versioned product definitions loaded from OCI artifacts.
CREATE TABLE IF NOT EXISTS core.product_definitions (
    id UUID PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    version VARCHAR(20) NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    product_type VARCHAR(30) NOT NULL,
    base_currency VARCHAR(3) NOT NULL DEFAULT 'NOK',
    spec JSONB NOT NULL DEFAULT '{}',
    status VARCHAR(20) NOT NULL DEFAULT 'active',
    validation_result JSONB,
    loaded_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (name, version)
);

CREATE INDEX IF NOT EXISTS idx_product_definitions_name ON core.product_definitions (name);

-- Arrangements (metadata → ledger account link)
-- product_id is kept for backward compatibility but no longer required;
-- new arrangements are created from definition_name alone.
-- customer_id references the customer-master service (no local FK).
CREATE TABLE IF NOT EXISTS core.arrangements (
    id UUID PRIMARY KEY,
    ledger_account_id UUID NOT NULL REFERENCES core.ledger_accounts(id),
    product_id UUID,                            -- deprecated: use definition_name instead
    customer_id UUID NOT NULL,                  -- references customer-master service (no local FK)
    name VARCHAR(255) NOT NULL,
    currency VARCHAR(3) NOT NULL DEFAULT 'NOK',
    status VARCHAR(20) NOT NULL DEFAULT 'active',
    definition_name VARCHAR(100),
    definition_version VARCHAR(20),
    lifecycle_state VARCHAR(30) DEFAULT 'active',
    policy_overrides JSONB,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_arrangements_name_lower
    ON core.arrangements (LOWER(name));
CREATE INDEX IF NOT EXISTS idx_arrangements_customer_id
    ON core.arrangements (customer_id);
CREATE INDEX IF NOT EXISTS idx_arrangements_product_id
    ON core.arrangements (product_id);
CREATE INDEX IF NOT EXISTS idx_arrangements_status
    ON core.arrangements (status);
CREATE INDEX IF NOT EXISTS idx_arrangements_currency
    ON core.arrangements (currency);
CREATE INDEX IF NOT EXISTS idx_arrangements_created_at
    ON core.arrangements (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_arrangements_customer_status
    ON core.arrangements (customer_id, status)
    WHERE status = 'active';
CREATE INDEX IF NOT EXISTS idx_arrangements_definition
    ON core.arrangements (definition_name, definition_version);

-- Mandates (user ↔ account permissions)
CREATE TABLE IF NOT EXISTS core.mandates (
    id UUID PRIMARY KEY,
    user_subject VARCHAR(255) NOT NULL,
    arrangement_id UUID NOT NULL REFERENCES core.arrangements(id),
    permissions JSONB NOT NULL DEFAULT '["view"]'
);

-- Account identifiers (ISO 20022 — multiple identifiers per arrangement)
-- identifier_type follows ISO 20022 ExternalAccountIdentification1Code
-- and ExternalProxyAccountType1Code
CREATE TABLE IF NOT EXISTS core.account_identifiers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    arrangement_id UUID NOT NULL REFERENCES core.arrangements(id) ON DELETE CASCADE,
    identifier_type VARCHAR(4) NOT NULL,        -- IBAN, BBAN, TELE, EMAL, DNAM, etc.
    identifier_value VARCHAR(255) NOT NULL,
    is_primary BOOLEAN NOT NULL DEFAULT false,  -- primary identifier for this type
    account_number_id UUID REFERENCES core.account_numbers(id), -- link to account_numbers for IBAN/BBAN
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT chk_identifier_type CHECK (identifier_type IN (
        'IBAN', 'BBAN',                        -- Account identification codes
        'TELE', 'EMAL', 'DNAM',               -- Proxy/alias codes
        'SHID', 'ORGN', 'NIDN'                -- Other proxy codes
    )),
    UNIQUE (identifier_type, identifier_value)  -- no two arrangements share the same identifier
);

-- Only one primary identifier per type per arrangement.
-- Prevents an arrangement from accumulating multiple primary IBANs.
CREATE UNIQUE INDEX IF NOT EXISTS uq_primary_identifier_per_type
    ON core.account_identifiers (arrangement_id, identifier_type)
    WHERE is_primary = true;

CREATE INDEX IF NOT EXISTS idx_account_identifiers_value_lower
    ON core.account_identifiers (LOWER(identifier_value));

-- Pricing rules
CREATE TABLE IF NOT EXISTS core.pricing_rules (
    id UUID PRIMARY KEY,
    product_id UUID REFERENCES core.products(id),
    arrangement_id UUID REFERENCES core.arrangements(id),
    rule_type VARCHAR(20) NOT NULL,
    config JSONB NOT NULL DEFAULT '{}'
);

-- ============================================================
-- PAYMENTS SCHEMA
-- ============================================================

-- Payment orders
-- Identifier columns (debtor_identifier, creditor_identifier) hold IBAN, BBAN,
-- or ISO 20022 proxy values (DNAM, TELE, EMAL, etc.).
-- Resolution to IBAN happens in the Heart process.
CREATE TABLE IF NOT EXISTS payments.payment_orders (
    id UUID PRIMARY KEY,
    debtor_account_id UUID,
    creditor_account_id UUID,
    amount NUMERIC(19, 4) NOT NULL,
    currency VARCHAR(3) NOT NULL DEFAULT 'NOK',
    status VARCHAR(20) NOT NULL DEFAULT 'RCVD',
    reference VARCHAR(255),
    payment_type VARCHAR(20) NOT NULL DEFAULT 'immediate',
    requested_execution_date DATE,
    end_to_end_id VARCHAR(255),
    debtor_identifier VARCHAR(34),
    creditor_identifier VARCHAR(34),
    debtor_identifier_type VARCHAR(4),          -- ExternalProxyAccountType1Code
    creditor_identifier_type VARCHAR(4),        -- ExternalProxyAccountType1Code
    creditor_name VARCHAR(255),
    debtor_name VARCHAR(255),
    description TEXT,
    initiator_subject VARCHAR(255),
    initiator_customer_id UUID,
    is_internal BOOLEAN NOT NULL DEFAULT false,
    sca_exempt BOOLEAN,
    sca_exemption_reason VARCHAR(100),
    heart_process_id UUID,
    heart_execution_process_id UUID,
    pending_work_item_id UUID,
    standing_order_id UUID,
    sca_proof_id UUID,
    rejection_reason VARCHAR(255),
    reserve_immediately BOOLEAN NOT NULL DEFAULT false,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ISO 20022-inspired messages (stored as JSON)
CREATE TABLE IF NOT EXISTS payments.iso_messages (
    id UUID PRIMARY KEY,
    payment_order_id UUID REFERENCES payments.payment_orders(id),
    message_type VARCHAR(20) NOT NULL,
    direction VARCHAR(10) NOT NULL,
    payload JSONB NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- SCA authorisations — generic table for payment and consent authorisation.
-- resource_type + resource_id point to the thing being authorised (e.g. 'payment' + payment_order.id).
-- Reusable for any BG authorisation sub-resource.
CREATE TABLE IF NOT EXISTS payments.payment_authorisations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    resource_type VARCHAR(30) NOT NULL DEFAULT 'payment',
    resource_id UUID NOT NULL,
    sca_status VARCHAR(30) NOT NULL DEFAULT 'received',
    user_subject VARCHAR(255),
    resource_data JSONB,                       -- structured data for SCA display (amount, IBANs, etc.)
    resource_data_hash VARCHAR(64),             -- SHA-256 hash of resource_data at creation (tamper detection)
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_authorisations_resource
    ON payments.payment_authorisations (resource_type, resource_id);

-- SCA proofs — cryptographically signed attestation of SCA completion.
CREATE TABLE IF NOT EXISTS payments.sca_proofs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    authorisation_id UUID NOT NULL REFERENCES payments.payment_authorisations(id),
    payload JSONB NOT NULL,
    signature VARCHAR(128) NOT NULL,
    public_key VARCHAR(64) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_sca_proofs_authorisation ON payments.sca_proofs (authorisation_id);

-- Standing orders — recurring payments
-- Identifier columns use the generalised naming (debtor_identifier, creditor_identifier)
-- to support IBAN, BBAN, or ISO 20022 proxy values.
CREATE TABLE IF NOT EXISTS payments.standing_orders (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    customer_id UUID NOT NULL,
    debtor_account_id UUID NOT NULL,
    debtor_identifier VARCHAR(34) NOT NULL,
    creditor_identifier VARCHAR(34) NOT NULL,
    creditor_name VARCHAR(255) NOT NULL,
    amount NUMERIC(19, 4) NOT NULL,
    currency VARCHAR(3) NOT NULL DEFAULT 'NOK',
    description TEXT,
    display_name VARCHAR(70),
    frequency VARCHAR(20) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE,
    next_execution_date DATE NOT NULL,
    day_of_execution VARCHAR(2),
    execution_rule VARCHAR(20) NOT NULL DEFAULT 'following',
    status VARCHAR(20) NOT NULL DEFAULT 'received',
    last_execution_date DATE,
    execution_count INTEGER NOT NULL DEFAULT 0,
    max_executions INTEGER,
    lead_days INTEGER NOT NULL DEFAULT 0,
    sca_exempt BOOLEAN,
    sca_exemption_reason VARCHAR(100),
    pending_work_item_id UUID,
    heart_process_id UUID,
    last_failure_reason TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_standing_orders_next ON payments.standing_orders (next_execution_date)
    WHERE status = 'active';
CREATE INDEX IF NOT EXISTS idx_standing_orders_customer ON payments.standing_orders (customer_id);

-- Reservations — tracks blocked funds on sub-accounts
CREATE TABLE IF NOT EXISTS core.reservations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    sub_account_id UUID NOT NULL REFERENCES core.ledger_accounts(id),
    payment_order_id UUID NOT NULL REFERENCES payments.payment_orders(id),
    amount NUMERIC(19, 4) NOT NULL,
    currency VARCHAR(3) NOT NULL DEFAULT 'NOK',
    status VARCHAR(20) NOT NULL DEFAULT 'active',
    posting_id UUID REFERENCES core.postings(id),
    release_posting_id UUID REFERENCES core.postings(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at TIMESTAMPTZ,
    settled_at TIMESTAMPTZ,
    CONSTRAINT chk_reservation_status CHECK (status IN ('active', 'settled', 'released', 'expired'))
);

CREATE INDEX IF NOT EXISTS idx_reservations_sub_account
    ON core.reservations (sub_account_id)
    WHERE status = 'active';
CREATE INDEX IF NOT EXISTS idx_reservations_payment_order
    ON core.reservations (payment_order_id);

-- ============================================================
-- CHANNELS SCHEMA
-- ============================================================

-- Consents (BG OpenFinance)
CREATE TABLE IF NOT EXISTS channels.consents (
    id UUID PRIMARY KEY,
    user_subject VARCHAR(255) NOT NULL,
    consent_type VARCHAR(30) NOT NULL DEFAULT 'account-access',
    status VARCHAR(30) NOT NULL DEFAULT 'received',
    access JSONB NOT NULL DEFAULT '{}',
    valid_until TIMESTAMPTZ,
    frequency_per_day INT NOT NULL DEFAULT 4,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- User profiles (OIDC sub ↔ customer mapping)
CREATE TABLE IF NOT EXISTS channels.user_profiles (
    id UUID PRIMARY KEY,
    user_subject VARCHAR(255) NOT NULL UNIQUE,
    customer_id UUID NOT NULL,
    display_name VARCHAR(255),
    settings JSONB NOT NULL DEFAULT '{}',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- ADMIN SCHEMA
-- ============================================================

-- Bank-internal users (operators and administrators)
CREATE TABLE IF NOT EXISTS admin.users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    username VARCHAR(100) NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    display_name VARCHAR(255) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'active',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Module-level permissions for bank users
-- role: 'operator' (read + create/execute) or 'admin' (operator + update/delete + manage)
CREATE TABLE IF NOT EXISTS admin.user_permissions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES admin.users(id) ON DELETE CASCADE,
    module VARCHAR(50) NOT NULL,
    role VARCHAR(20) NOT NULL CHECK (role IN ('operator', 'admin')),
    UNIQUE (user_id, module)
);

-- Session tokens for admin users
CREATE TABLE IF NOT EXISTS admin.sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES admin.users(id) ON DELETE CASCADE,
    token TEXT NOT NULL UNIQUE,
    expires_at TIMESTAMPTZ NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- SEED DATA: initial bank-admin superuser
-- Password: 'bank-admin' hashed with pgcrypto (argon2 done in app;
-- this seed uses a known bcrypt hash for bootstrap only).
-- The application should rehash on first login.
-- ============================================================

INSERT INTO admin.users (id, username, password_hash, display_name, status)
VALUES (
    '00000000-0000-0000-0000-000000000001',
    'bank-admin',
    crypt('bank-admin', gen_salt('bf')),
    'Bank Administrator',
    'active'
) ON CONFLICT (id) DO NOTHING;

INSERT INTO admin.user_permissions (user_id, module, role) VALUES
    ('00000000-0000-0000-0000-000000000001', 'customers',    'admin'),
    ('00000000-0000-0000-0000-000000000001', 'products',     'admin'),
    ('00000000-0000-0000-0000-000000000001', 'arrangements', 'admin'),
    ('00000000-0000-0000-0000-000000000001', 'ledger',       'admin'),
    ('00000000-0000-0000-0000-000000000001', 'payments',     'admin'),
    ('00000000-0000-0000-0000-000000000001', 'clock',        'admin'),
    ('00000000-0000-0000-0000-000000000001', 'users',        'admin'),
    ('00000000-0000-0000-0000-000000000001', 'profiles',     'admin')
ON CONFLICT (user_id, module) DO NOTHING;

-- ============================================================
-- SCHEDULES
-- ============================================================

CREATE TABLE IF NOT EXISTS admin.schedules (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(100) NOT NULL UNIQUE,
    definition_namespace VARCHAR(100) NOT NULL DEFAULT 'default',
    definition_name VARCHAR(200) NOT NULL,
    definition_version VARCHAR(50) NOT NULL DEFAULT '1.0.0',
    schedule_type VARCHAR(20) NOT NULL CHECK (schedule_type IN (
        'continuous', 'intraday', 'daily', 'month-end', 'year-end', 'manual'
    )),
    cron_expression VARCHAR(100),
    interval_seconds INTEGER,
    enabled BOOLEAN NOT NULL DEFAULT true,
    description TEXT,
    last_run_at TIMESTAMPTZ,
    last_instance_id UUID,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Seed schedule configuration for existing Heart definitions
INSERT INTO admin.schedules (name, definition_namespace, definition_name, definition_version, schedule_type, cron_expression, interval_seconds, enabled, description) VALUES
    ('due-payments',         'default', 'payment-execution',   '1.0.0', 'continuous',  NULL,              60,   true,  'Check and execute due-dated payments'),
    ('eod-batch',            'default', 'eod-batch',           '1.0.0', 'daily',       '0 23 * * *',      NULL, true,  'End-of-day accounting batch'),
    ('daily-reconciliation', 'default', 'daily-reconciliation','1.0.0', 'daily',       '0 23 30 * *',     NULL, true,  'Daily GL-to-core reconciliation'),
    ('daily-pnl',            'default', 'daily-pnl',           '1.0.0', 'daily',       '0 23 45 * *',     NULL, true,  'Daily profit & loss calculation'),
    ('daily-position',       'default', 'daily-position',      '1.0.0', 'daily',       '0 22 * * *',      NULL, true,  'Treasury daily position snapshot'),
    ('month-end-close',      'default', 'month-end-batch',     '1.0.0', 'month-end',   '0 2 L * *',       NULL, true,  'Monthly accounting close'),
    ('gl-sync',              'default', 'gl-sync',             '1.0.0', 'daily',       '0 21 * * *',      NULL, true,  'Sync core ledger to general ledger')
ON CONFLICT (name) DO NOTHING;

CREATE TABLE IF NOT EXISTS admin.schedule_runs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    schedule_id UUID NOT NULL REFERENCES admin.schedules(id) ON DELETE CASCADE,
    instance_id UUID,
    status VARCHAR(20) NOT NULL DEFAULT 'started' CHECK (status IN ('started', 'completed', 'failed')),
    triggered_by VARCHAR(20) NOT NULL DEFAULT 'scheduler' CHECK (triggered_by IN ('scheduler', 'manual')),
    error_message TEXT,
    started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_schedule_runs_schedule_id ON admin.schedule_runs(schedule_id);
CREATE INDEX IF NOT EXISTS idx_schedule_runs_started_at ON admin.schedule_runs(started_at DESC);

CREATE TABLE IF NOT EXISTS admin.schedule_alerts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    schedule_id UUID NOT NULL REFERENCES admin.schedules(id) ON DELETE CASCADE,
    alert_type VARCHAR(20) NOT NULL CHECK (alert_type IN ('failed', 'overdue')),
    message TEXT NOT NULL,
    run_id UUID REFERENCES admin.schedule_runs(id) ON DELETE SET NULL,
    acknowledged BOOLEAN NOT NULL DEFAULT false,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    resolved_at TIMESTAMPTZ,
    UNIQUE (schedule_id, alert_type, resolved_at)
);

CREATE INDEX IF NOT EXISTS idx_schedule_alerts_active ON admin.schedule_alerts(schedule_id) WHERE resolved_at IS NULL;

CREATE TABLE IF NOT EXISTS admin.schedule_dependencies (
    schedule_id UUID NOT NULL REFERENCES admin.schedules(id) ON DELETE CASCADE,
    depends_on UUID NOT NULL REFERENCES admin.schedules(id) ON DELETE CASCADE,
    PRIMARY KEY (schedule_id, depends_on),
    CHECK (schedule_id != depends_on)
);

-- Default dependency: month-end-close depends on eod-batch
INSERT INTO admin.schedule_dependencies (schedule_id, depends_on)
SELECT mc.id, eod.id
FROM admin.schedules mc, admin.schedules eod
WHERE mc.name = 'month-end-close' AND eod.name = 'eod-batch'
ON CONFLICT DO NOTHING;

-- ============================================================
-- TERMS & CONDITIONS
-- ============================================================

CREATE TABLE IF NOT EXISTS core.terms_and_conditions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    document_type VARCHAR(100) NOT NULL,        -- "account_general", "savings_specific", "privacy", "onboarding"
    version VARCHAR(20) NOT NULL,               -- semver: "1.0.0", "2.1.0"
    title VARCHAR(500) NOT NULL,
    description TEXT,
    oci_reference VARCHAR(500),                 -- oci://oci.bjoroy.me/<instance>/terms/<type>:<version>
    content_hash VARCHAR(64),                   -- SHA256 for integrity verification
    effective_from TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    effective_to TIMESTAMPTZ,                   -- NULL = currently effective
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (document_type, version)
);

CREATE INDEX IF NOT EXISTS idx_tc_document_type ON core.terms_and_conditions(document_type);
CREATE INDEX IF NOT EXISTS idx_tc_effective ON core.terms_and_conditions(document_type, effective_from);

CREATE TABLE IF NOT EXISTS core.tc_acceptances (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    customer_id UUID NOT NULL,
    tc_id UUID NOT NULL REFERENCES core.terms_and_conditions(id),
    arrangement_id UUID,                        -- NULL for pre-arrangement acceptances (onboarding)
    process_instance_id UUID,                   -- Heart process instance that triggered
    accepted_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    proof_signature TEXT NOT NULL,               -- Ed25519 signature hex
    proof_public_key TEXT NOT NULL,              -- Ed25519 public key hex
    proof_payload JSONB NOT NULL,               -- Signed payload: {tc_id, version, customer_id, content_hash, timestamp}
    ip_address VARCHAR(45),                     -- IPv4 or IPv6
    user_agent TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_tc_accept_customer ON core.tc_acceptances(customer_id);
CREATE INDEX IF NOT EXISTS idx_tc_accept_tc ON core.tc_acceptances(tc_id);
CREATE INDEX IF NOT EXISTS idx_tc_accept_arrangement ON core.tc_acceptances(arrangement_id) WHERE arrangement_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_tc_accept_process ON core.tc_acceptances(process_instance_id) WHERE process_instance_id IS NOT NULL;

-- Seed default T&C documents
INSERT INTO core.terms_and_conditions (document_type, version, title, description, effective_from)
VALUES
    ('account_general', '1.0.0', 'General Account Terms', 'General terms and conditions for all bank accounts', NOW()),
    ('savings_specific', '1.0.0', 'Savings Account Terms', 'Additional terms for savings accounts', NOW()),
    ('privacy', '1.0.0', 'Privacy Policy', 'Data processing and privacy policy', NOW()),
    ('onboarding', '1.0.0', 'Customer Onboarding Terms', 'Terms for becoming a customer', NOW())
ON CONFLICT (document_type, version) DO NOTHING;

-- ============================================================
-- SCHEMA MIGRATIONS (idempotent ALTER statements for existing databases)
-- ============================================================

-- v1.4.18: Allow nullable account IDs for interbank payments.
-- External counterparties (creditor at another bank, or debtor for incoming)
-- don't have local accounts, so these must be nullable.
ALTER TABLE payments.payment_orders ALTER COLUMN debtor_account_id DROP NOT NULL;
ALTER TABLE payments.payment_orders ALTER COLUMN creditor_account_id DROP NOT NULL;
ALTER TABLE payments.payment_orders ADD COLUMN IF NOT EXISTS debtor_name VARCHAR(255);

-- v1.4.25: Retry columns for payment execution back-off
ALTER TABLE payments.payment_orders ADD COLUMN IF NOT EXISTS retry_count INT NOT NULL DEFAULT 0;
ALTER TABLE payments.payment_orders ADD COLUMN IF NOT EXISTS next_retry_at TIMESTAMPTZ;
ALTER TABLE payments.payment_orders ADD COLUMN IF NOT EXISTS retry_deadline TIMESTAMPTZ;

CREATE INDEX IF NOT EXISTS idx_payment_orders_retry
    ON payments.payment_orders (status, next_retry_at)
    WHERE status = 'RTRY';

-- Remove broken due-payments schedule if it exists (was wrongly triggering
-- payment-execution without metadata). ExecutionScheduler handles this.
DELETE FROM admin.schedule_runs WHERE schedule_id IN (
    SELECT id FROM admin.schedules WHERE name = 'due-payments'
      AND definition_name = 'payment-execution'
);
DELETE FROM admin.schedule_alerts WHERE schedule_id IN (
    SELECT id FROM admin.schedules WHERE name = 'due-payments'
      AND definition_name = 'payment-execution'
);
DELETE FROM admin.schedules WHERE name = 'due-payments'
    AND definition_name = 'payment-execution';

-- ============================================================
-- RTP SCHEMA — Request to Pay service
-- ============================================================

CREATE SCHEMA IF NOT EXISTS rtp;

CREATE TABLE IF NOT EXISTS rtp.requests (
    id              UUID PRIMARY KEY,
    end_to_end_id   TEXT NOT NULL,
    message_id      TEXT NOT NULL UNIQUE,
    payee_name      TEXT NOT NULL,
    payee_iban      TEXT NOT NULL,
    payee_bic       TEXT,
    payer_iban      TEXT NOT NULL,
    amount          NUMERIC(18,2) NOT NULL,
    currency        TEXT NOT NULL DEFAULT 'EUR',
    remittance_info TEXT,
    status          TEXT NOT NULL DEFAULT 'created'
                    CHECK (status IN (
                        'created', 'sent', 'received', 'accepted', 'rejected',
                        'expired', 'cancelled', 'payment_pending', 'payment_settled', 'payment_failed'
                    )),
    expiry          TIMESTAMPTZ NOT NULL,
    created_at      TIMESTAMPTZ NOT NULL,
    updated_at      TIMESTAMPTZ NOT NULL,
    process_instance_id TEXT,
    payee_sp_endpoint   TEXT
);

CREATE INDEX IF NOT EXISTS idx_rtp_requests_message_id ON rtp.requests(message_id);
CREATE INDEX IF NOT EXISTS idx_rtp_requests_payer_iban ON rtp.requests(payer_iban);
CREATE INDEX IF NOT EXISTS idx_rtp_requests_status ON rtp.requests(status);
CREATE INDEX IF NOT EXISTS idx_rtp_requests_expiry ON rtp.requests(expiry) WHERE status NOT IN ('payment_settled', 'payment_failed', 'rejected', 'expired', 'cancelled');

CREATE TABLE IF NOT EXISTS rtp.status_history (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    request_id      UUID NOT NULL REFERENCES rtp.requests(id),
    from_status     TEXT NOT NULL,
    to_status       TEXT NOT NULL,
    actor           TEXT NOT NULL,
    reason          TEXT,
    transitioned_at TIMESTAMPTZ NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_rtp_status_history_request ON rtp.status_history(request_id);

CREATE TABLE IF NOT EXISTS rtp.inter_sp_messages (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    message_id      TEXT NOT NULL,
    direction       TEXT NOT NULL CHECK (direction IN ('sent', 'received')),
    message_type    TEXT NOT NULL CHECK (message_type IN ('pain.013', 'pain.014', 'payment_confirmation')),
    payload         JSONB NOT NULL,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_rtp_inter_sp_msg_id ON rtp.inter_sp_messages(message_id);
