-- Channel service schema (idempotent)

CREATE SCHEMA IF NOT EXISTS channel;

CREATE TABLE IF NOT EXISTS channel.profiles (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    sub         TEXT NOT NULL UNIQUE,
    display_name TEXT,
    preferred_payment_account   TEXT,
    preferred_receiving_account TEXT,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS channel.cached_accounts (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    profile_id  UUID NOT NULL REFERENCES channel.profiles(id) ON DELETE CASCADE,
    account_id  TEXT NOT NULL,
    iban        TEXT,
    name        TEXT,
    currency    TEXT,
    product     TEXT,
    status      TEXT,
    cached_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE(profile_id, account_id)
);

CREATE INDEX IF NOT EXISTS idx_cached_accounts_profile
    ON channel.cached_accounts(profile_id);
