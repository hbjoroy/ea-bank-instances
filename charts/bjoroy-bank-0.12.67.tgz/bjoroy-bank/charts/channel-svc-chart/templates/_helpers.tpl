{{/*
Common labels
*/}}
{{- define "channel-svc-chart.labels" -}}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Values.global.imageTag | default .Chart.AppVersion | quote }}
helm.sh/chart: {{ .Chart.Name }}-{{ .Chart.Version }}
{{- end }}

{{/*
Validate instanceId — REQUIRED.
*/}}
{{- define "channel-svc-chart.instanceId" -}}
{{- required "global.instanceId is required. Set --set global.instanceId=<name>" .Values.global.instanceId -}}
{{- end }}

{{/*
Postgres-safe identifier — replaces hyphens with underscores.
*/}}
{{- define "channel-svc-chart.pgIdentifier" -}}
{{- . | replace "-" "_" -}}
{{- end }}

{{/*
Channel database name: {instanceId}_channel
*/}}
{{- define "channel-svc-chart.dbName" -}}
{{- include "channel-svc-chart.pgIdentifier" (include "channel-svc-chart.instanceId" .) }}_channel
{{- end }}

{{/*
Database user — shared bank user: {instanceId}_bank
*/}}
{{- define "channel-svc-chart.dbUser" -}}
{{- include "channel-svc-chart.pgIdentifier" (include "channel-svc-chart.instanceId" .) }}_bank
{{- end }}

{{/*
Database credentials secret: {release}-db-credentials
*/}}
{{- define "channel-svc-chart.dbCredentialsSecret" -}}
{{ .Release.Name }}-db-credentials
{{- end }}

{{/*
Full DATABASE_URL
*/}}
{{- define "channel-svc-chart.databaseUrl" -}}
postgres://{{ include "channel-svc-chart.dbUser" . }}:$(DB_PASSWORD)@{{ .Values.database.host }}:{{ .Values.database.port }}/{{ include "channel-svc-chart.dbName" . }}
{{- end }}

{{/*
Selector labels for a component
*/}}
{{- define "channel-svc-chart.selectorLabels" -}}
app.kubernetes.io/name: {{ .name }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}
