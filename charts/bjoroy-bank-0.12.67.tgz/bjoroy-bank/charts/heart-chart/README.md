# Heart Helm Chart

This chart deploys the Heart API server with an optional PostgreSQL instance.
It is designed to run standalone or as a subchart of another Helm chart.

## Quick Start

**Basic deployment:**

```sh
helm install heart . \
  --set image.tag=1.0.0 \
  --set database.host=postgres \
  --set database.user=heart \
  --set database.password=heart-dev
```

**Production deployment with separate admin credentials:**

```sh
helm install heart . \
  --set image.tag=1.0.0 \
  --set database.host=postgres-postgresql.database.svc.cluster.local \
  --set database.user=heart \
  --set database.existingSecret=heart-db-secret \
  --set migrations.pgUser=postgres \
  --set migrations.pgPassword=$POSTGRES_ADMIN_PASSWORD
```

**Using existing secret for admin credentials:**

```sh
helm install heart . \
  --set image.tag=1.0.0 \
  --set database.host=postgres-postgresql.database.svc.cluster.local \
  --set database.user=heart \
  --set database.existingSecret=heart-db-secret \
  --set migrations.existingSecret=postgres-admin-secret \
  --set migrations.pgUser=postgres
```

## Subchart Usage

In a parent chart, add this to Chart.yaml:

```yaml
dependencies:
  - name: heart-chart
    version: 0.3.0
    repository: oci://oci.bjoroy.me/heart
    alias: heart
```

Then override values in the parent values.yaml:

```yaml
heart:
  image:
    tag: "1.0.0"
  database:
    host: "postgres-postgresql.database.svc.cluster.local"
    port: 5432
    name: "heart"
    user: "heart"
    existingSecret: "postgres-credentials"
    existingSecretKey: "password"
```

## Values

| Key | Default | Description |
|-----|---------|-------------|
| image.repository | oci.bjoroy.me/heart/api | Heart container image |
| image.tag | 0.1.0 | Image tag |
| image.pullPolicy | IfNotPresent | Pull policy |
| replicaCount | 1 | Deployment replicas |
| containerPort | 3000 | Container port |
| service.type | ClusterIP | Service type |
| service.port | 3000 | Service port |
| env.rustLog | info | Log level |
| global.dbHost | | Overrides database.host across all subcharts |
| global.dbPort | | Overrides database.port across all subcharts |
| global.dbName | | Overrides database.name across all subcharts |
| global.dbUser | | Overrides database.user across all subcharts |
| global.dbPassword | | Overrides database.password across all subcharts |
| database.host | postgres | Database host |
| database.port | 5432 | Database port |
| database.name | heart | Database name |
| database.user | heart | Database user |
| database.password | heart-dev | Database password (ignored if existingSecret set) |
| database.existingSecret | "" | Existing secret for password |
| database.existingSecretKey | password | Key in existing secret |
| migrations.enabled | true | Run migrations job |
| migrations.image | postgres:17 | Image for migrations job |
| migrations.createDatabase | true | Attempt to create database if it doesn't exist (requires CREATE DATABASE privilege) |
| migrations.pgUser | "" | Admin user for database creation (defaults to database.user). Pass via --set, don't commit! |
| migrations.pgPassword | "" | Admin password for database creation (defaults to database.password). Pass via --set, don't commit! |
| migrations.existingSecret | "" | Existing secret containing admin password for database creation |
| migrations.existingSecretKey | admin-password | Key in migrations.existingSecret |
| postgres.enabled | false | Enable bundled PostgreSQL |
| postgres.image | postgres:17 | PostgreSQL image |
| postgres.auth.username | heart | DB username |
| postgres.auth.password | heart-dev | DB password |
| postgres.auth.database | heart | DB name |
| postgres.service.port | 5432 | PostgreSQL service port |
| postgres.persistence.enabled | false | Enable PVC |
| postgres.persistence.size | 10Gi | PVC size |
| postgres.persistence.storageClass | "" | Storage class |

## Examples

- External PostgreSQL: see examples/values-external-postgres.yaml
- Bundled PostgreSQL: see examples/values-bundled-postgres.yaml

## Global Values

When Heart is used as a subchart, the parent chart can set database configuration via `global.*` values. These flow automatically to all subcharts without prefixing:

```yaml
# parent values.yaml
global:
  dbUser: "myapp"
  dbName: "myapp_heart"
  dbHost: "postgres-postgresql.database.svc.cluster.local"
```

This is equivalent to setting `heart.database.user`, `heart.database.name`, and `heart.database.host` — but applies to all subcharts at once.

Global values take precedence over `database.*` values. Chart-level `database.*` values serve as defaults when no global is set.

- External PostgreSQL: see examples/values-external-postgres.yaml
- Bundled PostgreSQL: see examples/values-bundled-postgres.yaml

## Database Configuration

Heart requires a PostgreSQL database. Configure the connection using the `database.*` values:

```yaml
database:
  host: "postgres-postgresql.database.svc.cluster.local"
  port: 5432
  name: "heart"
  user: "heart"
  # Either provide a password directly (not recommended for production)
  password: "heart-dev"
  # Or reference an existing secret (recommended)
  existingSecret: "postgres-secret"
  existingSecretKey: "password"
```

When `database.existingSecret` is set, the password field is ignored and the secret is used instead.

### Database Creation

By default, the migration job will automatically create the target database if it doesn't exist (`migrations.createDatabase: true`). This requires the database user to have `CREATE DATABASE` privileges on the PostgreSQL server.

#### Using Separate Admin Credentials

For production environments, it's recommended to use separate admin credentials for database creation:

```sh
helm install heart . \
  --set image.tag=1.0.0 \
  --set database.host=postgres-postgresql.database.svc.cluster.local \
  --set database.user=heart \
  --set database.existingSecret=heart-db-secret \
  --set migrations.pgUser=postgres \
  --set migrations.pgPassword=admin-password
```

**⚠️ SECURITY BEST PRACTICE:**
- Never commit `migrations.pgUser` or `migrations.pgPassword` to version control
- Always pass admin credentials via command-line `--set` flags or CI/CD secrets
- For production, use `migrations.existingSecret` to reference a secret containing admin credentials

#### Configuration Options

1. **Use admin credentials from command line** (development):
   ```yaml
   migrations:
     createDatabase: true
     pgUser: "postgres"
     pgPassword: "admin-password"  # Pass via --set, don't commit!
   ```

2. **Use admin credentials from existing secret** (production):
   ```yaml
   migrations:
     createDatabase: true
     existingSecret: "postgres-admin-secret"
     existingSecretKey: "admin-password"
     pgUser: "postgres"
   ```

3. **Disable auto-creation** (if database is pre-created):
   ```yaml
   migrations:
     createDatabase: false
   ```

When using the bundled PostgreSQL (`postgres.enabled: true`), the database is created automatically by PostgreSQL itself.
- Bundled PostgreSQL: see examples/values-bundled-postgres.yaml

## Notes

- The migrations job applies the SQL files from the chart to the database.
- For production, consider running migrations via a dedicated tool.
