{{- define "heart.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "heart.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name (include "heart.name" .) | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{- define "heart.labels" -}}
app.kubernetes.io/name: {{ include "heart.name" . }}
helm.sh/chart: {{ .Chart.Name }}-{{ .Chart.Version }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{- define "heart.selectorLabels" -}}
app.kubernetes.io/name: {{ include "heart.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{- define "heart.databaseSecretName" -}}
{{- if and .Values.global .Values.global.dbCredentialsSecret -}}
{{- .Values.global.dbCredentialsSecret -}}
{{- else if and .Values.global .Values.global.instanceId -}}
{{- printf "%s-db-credentials" .Release.Name -}}
{{- else if .Values.database.existingSecret -}}
{{- .Values.database.existingSecret -}}
{{- else -}}
{{- printf "%s-db" (include "heart.fullname" .) -}}
{{- end -}}
{{- end -}}

{{- define "heart.databaseSecretKey" -}}
{{- if and .Values.global .Values.global.dbCredentialsSecret -}}
password
{{- else if and .Values.global .Values.global.instanceId -}}
password
{{- else if .Values.database.existingSecret -}}
{{- .Values.database.existingSecretKey | default "password" -}}
{{- else -}}
DATABASE_URL
{{- end -}}
{{- end -}}

{{/*
Postgres-safe identifier — replaces hyphens with underscores
*/}}
{{- define "heart.pgIdentifier" -}}
{{- . | replace "-" "_" -}}
{{- end -}}

{{/*
Resolved database values — global.instanceId auto-derives names,
then global.* overrides, then database.* defaults.
*/}}
{{- define "heart.db.host" -}}
{{- if and .Values.global .Values.global.dbHost -}}{{ .Values.global.dbHost }}{{- else -}}{{ .Values.database.host }}{{- end -}}
{{- end -}}

{{- define "heart.db.port" -}}
{{- if and .Values.global .Values.global.dbPort -}}{{ .Values.global.dbPort }}{{- else -}}{{ .Values.database.port }}{{- end -}}
{{- end -}}

{{- define "heart.db.name" -}}
{{- if and .Values.global .Values.global.instanceId -}}{{ include "heart.pgIdentifier" .Values.global.instanceId }}_heart
{{- else if and .Values.global .Values.global.dbName -}}{{ .Values.global.dbName }}{{- else -}}{{ .Values.database.name }}{{- end -}}
{{- end -}}

{{- define "heart.db.user" -}}
{{- if and .Values.global .Values.global.instanceId -}}{{ include "heart.pgIdentifier" .Values.global.instanceId }}_bank
{{- else if and .Values.global .Values.global.dbUser -}}{{ .Values.global.dbUser }}{{- else -}}{{ .Values.database.user }}{{- end -}}
{{- end -}}

{{- define "heart.db.password" -}}
{{- if and .Values.global .Values.global.dbPassword -}}{{ .Values.global.dbPassword }}{{- else -}}{{ .Values.database.password }}{{- end -}}
{{- end -}}

{{- define "heart.databaseUrl" -}}
postgres://{{ include "heart.db.user" . }}:{{ include "heart.db.password" . }}@{{ include "heart.db.host" . }}:{{ include "heart.db.port" . }}/{{ include "heart.db.name" . }}
{{- end -}}

{{- define "heart.postgresName" -}}
{{- printf "%s-postgres" (include "heart.fullname" .) -}}
{{- end -}}
