-- Heart — Migration 003: Message Subscriptions
--
-- Adds a table for message subscriptions created by receive nodes.
-- When a process instance reaches a receive node, it creates a subscription
-- with a correlation key/value pair. When a message is sent matching the
-- namespace + key + value, all matching subscribers are notified.

CREATE TABLE heart.message_subscription (
    id              UUID        PRIMARY KEY,
    instance_id     UUID        NOT NULL REFERENCES heart.instance(id),
    namespace       TEXT        NOT NULL,
    node_id         TEXT        NOT NULL,
    correlation_key TEXT        NOT NULL,
    correlation_value TEXT      NOT NULL,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Index for efficient lookup when a message arrives
CREATE INDEX idx_message_sub_ns_key_value
    ON heart.message_subscription (namespace, correlation_key, correlation_value);

-- Index for cleanup when an instance is deleted/archived
CREATE INDEX idx_message_sub_instance
    ON heart.message_subscription (instance_id);
