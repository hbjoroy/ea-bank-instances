-- 004: Add error_node and error_message to instance table.
-- Stores error details when an instance transitions to 'failed' status.

ALTER TABLE heart.instance
    ADD COLUMN IF NOT EXISTS error_node TEXT,
    ADD COLUMN IF NOT EXISTS error_message TEXT;
