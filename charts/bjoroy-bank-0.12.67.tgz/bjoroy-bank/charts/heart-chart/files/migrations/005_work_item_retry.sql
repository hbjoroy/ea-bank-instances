-- 005: Add retry_count and max_retries to work_item table.
-- Supports automatic timeout and dead-letter for picked work items.

ALTER TABLE heart.work_item
    ADD COLUMN IF NOT EXISTS retry_count INTEGER NOT NULL DEFAULT 0,
    ADD COLUMN IF NOT EXISTS max_retries INTEGER NOT NULL DEFAULT 3;
