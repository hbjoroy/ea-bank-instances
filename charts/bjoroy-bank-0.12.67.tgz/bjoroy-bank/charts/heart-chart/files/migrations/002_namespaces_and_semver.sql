-- Heart — Migration 002: Namespaces and Semver Versioning
--
-- Adds namespace column to all entity tables and converts version from
-- INTEGER to TEXT (semver format).  Existing data gets namespace='default'
-- and version '1.0.0' (from integer 1).
--
-- After applying this migration, recreate the dev database:
--   podman compose down -v && podman compose up -d
-- Or apply manually with psql.

-- ═══════════════════════════════════════════════════════════════
-- Definitions: add namespace, convert version to semver TEXT
-- ═══════════════════════════════════════════════════════════════

-- Add namespace column
ALTER TABLE heart.definition
    ADD COLUMN namespace TEXT NOT NULL DEFAULT 'default';

-- Drop old integer-only constraints
ALTER TABLE heart.definition
    DROP CONSTRAINT ck_definition_version;
ALTER TABLE heart.definition
    DROP CONSTRAINT uq_definition_name_version;
DROP INDEX IF EXISTS heart.idx_definition_name;

-- Convert version from INTEGER to semver TEXT (e.g. 1 → '1.0.0')
ALTER TABLE heart.definition
    ALTER COLUMN version TYPE TEXT USING version::text || '.0.0';

-- Add new constraints
ALTER TABLE heart.definition
    ADD CONSTRAINT uq_definition_ns_name_version UNIQUE (namespace, name, version);
ALTER TABLE heart.definition
    ADD CONSTRAINT ck_definition_namespace CHECK (namespace ~ '^[a-z][a-z0-9-]*[a-z0-9]$');

-- New index on (namespace, name)
CREATE INDEX idx_definition_ns_name ON heart.definition (namespace, name);

-- ═══════════════════════════════════════════════════════════════
-- Instances: add namespace
-- ═══════════════════════════════════════════════════════════════

ALTER TABLE heart.instance
    ADD COLUMN namespace TEXT NOT NULL DEFAULT 'default';

CREATE INDEX idx_instance_namespace ON heart.instance (namespace);

-- ═══════════════════════════════════════════════════════════════
-- Work Items: add namespace, update index
-- ═══════════════════════════════════════════════════════════════

ALTER TABLE heart.work_item
    ADD COLUMN namespace TEXT NOT NULL DEFAULT 'default';

-- Replace queue-only index with namespace-scoped index
DROP INDEX IF EXISTS heart.idx_work_item_queue_status;
CREATE INDEX idx_work_item_ns_queue_status ON heart.work_item (namespace, queue_name, status);

-- ═══════════════════════════════════════════════════════════════
-- Instance Archive: add namespace, convert version to TEXT
-- ═══════════════════════════════════════════════════════════════

ALTER TABLE heart.instance_archive
    ADD COLUMN namespace TEXT NOT NULL DEFAULT 'default';

ALTER TABLE heart.instance_archive
    ALTER COLUMN definition_version TYPE TEXT USING definition_version::text || '.0.0';

-- Update archive index
DROP INDEX IF EXISTS heart.idx_instance_archive_definition;
CREATE INDEX idx_instance_archive_ns_definition
    ON heart.instance_archive (namespace, definition_name, definition_version);
