-- Gate trace on transitions
ALTER TABLE heart.transition ADD COLUMN IF NOT EXISTS gate_trace JSONB;
