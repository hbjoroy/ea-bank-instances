-- 007: Add correlation_id to instance and work_item tables
ALTER TABLE heart.instance ADD COLUMN IF NOT EXISTS correlation_id TEXT;
ALTER TABLE heart.work_item ADD COLUMN IF NOT EXISTS correlation_id TEXT;
