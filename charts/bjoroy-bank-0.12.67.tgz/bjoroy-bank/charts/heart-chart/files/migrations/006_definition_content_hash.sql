-- 006: Add content_hash column to definition table for idempotent deploy.
-- The hash covers all definition content except the version field.
ALTER TABLE heart.definition ADD COLUMN IF NOT EXISTS content_hash TEXT;
