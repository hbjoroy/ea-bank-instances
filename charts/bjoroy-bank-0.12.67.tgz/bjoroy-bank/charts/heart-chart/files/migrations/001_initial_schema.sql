-- Heart — Initial Schema
-- Applied automatically on first PostgreSQL startup via docker-entrypoint-initdb.d

CREATE SCHEMA IF NOT EXISTS heart;

-- ═══════════════════════════════════════════════════════════════
-- Process Definitions
-- ═══════════════════════════════════════════════════════════════

CREATE TABLE heart.definition (
    id              UUID PRIMARY KEY,
    name            TEXT NOT NULL,
    version         INTEGER NOT NULL,
    description     TEXT,
    source_yaml     TEXT NOT NULL,
    parsed_json     JSONB NOT NULL,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),

    CONSTRAINT uq_definition_name_version UNIQUE (name, version),
    CONSTRAINT ck_definition_name CHECK (name ~ '^[a-z][a-z0-9-]*[a-z0-9]$'),
    CONSTRAINT ck_definition_version CHECK (version > 0)
);

CREATE INDEX idx_definition_name ON heart.definition (name);

-- ═══════════════════════════════════════════════════════════════
-- Process Instances
-- ═══════════════════════════════════════════════════════════════

CREATE TYPE heart.instance_status AS ENUM (
    'running',
    'waiting',
    'completed',
    'failed',
    'cancelled'
);

CREATE TABLE heart.instance (
    id              UUID PRIMARY KEY,
    definition_id   UUID NOT NULL,
    status          heart.instance_status NOT NULL DEFAULT 'running',
    current_node    TEXT NOT NULL,
    metadata        JSONB NOT NULL DEFAULT '{}',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    completed_at    TIMESTAMPTZ,

    CONSTRAINT fk_instance_definition
        FOREIGN KEY (definition_id) REFERENCES heart.definition(id)
);

CREATE INDEX idx_instance_definition_id ON heart.instance (definition_id);
CREATE INDEX idx_instance_status ON heart.instance (status);
CREATE INDEX idx_instance_created_at ON heart.instance (created_at);

-- ═══════════════════════════════════════════════════════════════
-- Transition Log
-- ═══════════════════════════════════════════════════════════════

CREATE TABLE heart.transition (
    id              UUID PRIMARY KEY,
    instance_id     UUID NOT NULL,
    seq             INTEGER NOT NULL,
    from_node       TEXT NOT NULL,
    to_node         TEXT NOT NULL,
    metadata_snapshot JSONB NOT NULL,
    transitioned_at TIMESTAMPTZ NOT NULL DEFAULT now(),

    CONSTRAINT uq_transition_instance_seq UNIQUE (instance_id, seq),
    CONSTRAINT fk_transition_instance
        FOREIGN KEY (instance_id) REFERENCES heart.instance(id)
);

CREATE INDEX idx_transition_instance_id ON heart.transition (instance_id);
CREATE INDEX idx_transition_transitioned_at ON heart.transition (transitioned_at);

-- ═══════════════════════════════════════════════════════════════
-- Work Queue
-- ═══════════════════════════════════════════════════════════════

CREATE TYPE heart.work_item_status AS ENUM (
    'pending',
    'processing',
    'completed',
    'failed'
);

CREATE TABLE heart.work_item (
    id              UUID PRIMARY KEY,
    instance_id     UUID NOT NULL,
    queue_name      TEXT NOT NULL,
    node_id         TEXT NOT NULL,
    status          heart.work_item_status NOT NULL DEFAULT 'pending',
    metadata        JSONB NOT NULL,
    result_metadata JSONB,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    picked_at       TIMESTAMPTZ,
    completed_at    TIMESTAMPTZ,

    CONSTRAINT fk_work_item_instance
        FOREIGN KEY (instance_id) REFERENCES heart.instance(id)
);

CREATE INDEX idx_work_item_queue_status ON heart.work_item (queue_name, status);
CREATE INDEX idx_work_item_instance_id ON heart.work_item (instance_id);

-- ═══════════════════════════════════════════════════════════════
-- Instance Archive
-- ═══════════════════════════════════════════════════════════════

CREATE TABLE heart.instance_archive (
    id              UUID PRIMARY KEY,
    definition_id   UUID NOT NULL,
    definition_name TEXT NOT NULL,
    definition_version INTEGER NOT NULL,
    status          heart.instance_status NOT NULL,
    final_node      TEXT NOT NULL,
    metadata        JSONB NOT NULL,
    transitions     JSONB NOT NULL,
    created_at      TIMESTAMPTZ NOT NULL,
    completed_at    TIMESTAMPTZ NOT NULL,
    archived_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_instance_archive_definition ON heart.instance_archive (definition_name, definition_version);
CREATE INDEX idx_instance_archive_completed_at ON heart.instance_archive (completed_at);
