{{- define "customer-master.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "customer-master.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name (include "customer-master.name" .) | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{- define "customer-master.labels" -}}
app.kubernetes.io/name: {{ include "customer-master.name" . }}
helm.sh/chart: {{ .Chart.Name }}-{{ .Chart.Version }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{- define "customer-master.selectorLabels" -}}
app.kubernetes.io/name: {{ include "customer-master.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{/*
Postgres-safe identifier — replaces hyphens with underscores
*/}}
{{- define "customer-master.pgIdentifier" -}}
{{- . | replace "-" "_" -}}
{{- end -}}

{{- define "customer-master.databaseSecretName" -}}
{{- if and .Values.global .Values.global.dbCredentialsSecret -}}
{{- .Values.global.dbCredentialsSecret -}}
{{- else if and .Values.global .Values.global.instanceId -}}
{{- printf "%s-db-credentials" .Release.Name -}}
{{- else if .Values.database.existingSecret -}}
{{- .Values.database.existingSecret -}}
{{- else -}}
{{- printf "%s-db" (include "customer-master.fullname" .) -}}
{{- end -}}
{{- end -}}

{{- define "customer-master.databaseSecretKey" -}}
{{- if and .Values.global .Values.global.dbCredentialsSecret -}}
password
{{- else if and .Values.global .Values.global.instanceId -}}
password
{{- else if .Values.database.existingSecret -}}
{{- .Values.database.existingSecretKey | default "password" -}}
{{- else -}}
DATABASE_URL
{{- end -}}
{{- end -}}

{{/*
Resolved database values — global.instanceId auto-derives names,
then global.* overrides, then database.* defaults.
*/}}
{{- define "customer-master.db.host" -}}
{{- if and .Values.global .Values.global.dbHost -}}{{ .Values.global.dbHost }}{{- else -}}{{ .Values.database.host }}{{- end -}}
{{- end -}}

{{- define "customer-master.db.port" -}}
{{- if and .Values.global .Values.global.dbPort -}}{{ .Values.global.dbPort }}{{- else -}}{{ .Values.database.port }}{{- end -}}
{{- end -}}

{{- define "customer-master.db.name" -}}
{{- if and .Values.global .Values.global.instanceId -}}{{ include "customer-master.pgIdentifier" .Values.global.instanceId }}_customer
{{- else if and .Values.global .Values.global.customerDbName -}}{{ .Values.global.customerDbName }}{{- else -}}{{ .Values.database.name }}{{- end -}}
{{- end -}}

{{- define "customer-master.db.user" -}}
{{- if and .Values.global .Values.global.instanceId -}}{{ include "customer-master.pgIdentifier" .Values.global.instanceId }}_bank
{{- else if and .Values.global .Values.global.dbUser -}}{{ .Values.global.dbUser }}{{- else -}}{{ .Values.database.user }}{{- end -}}
{{- end -}}

{{- define "customer-master.db.password" -}}
{{- if and .Values.global .Values.global.dbPassword -}}{{ .Values.global.dbPassword }}{{- else -}}{{ .Values.database.password }}{{- end -}}
{{- end -}}

{{- define "customer-master.databaseUrl" -}}
postgres://{{ include "customer-master.db.user" . }}:{{ include "customer-master.db.password" . }}@{{ include "customer-master.db.host" . }}:{{ include "customer-master.db.port" . }}/{{ include "customer-master.db.name" . }}
{{- end -}}
