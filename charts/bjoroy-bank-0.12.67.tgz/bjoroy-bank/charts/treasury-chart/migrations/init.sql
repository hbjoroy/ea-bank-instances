-- ea-bank-treasury schema
-- Treasury and funding module for Bjørøy Bank

CREATE SCHEMA IF NOT EXISTS treasury;

-- Funding accounts: bank's positions at central bank, correspondents, etc.
CREATE TABLE IF NOT EXISTS treasury.funding_accounts (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name            VARCHAR(200) NOT NULL,
    account_type    VARCHAR(40) NOT NULL,   -- 'central_bank', 'correspondent', 'interbank', 'internal'
    counterparty    VARCHAR(200),           -- e.g. 'Norges Bank', 'DNB'
    currency        VARCHAR(3) DEFAULT 'NOK',
    ledger_account_id UUID,                 -- link to core ledger account (if applicable)
    gl_account_code VARCHAR(10),            -- link to GL account code
    is_active       BOOLEAN DEFAULT TRUE,
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- Internal transfers between funding/GL accounts
CREATE TABLE IF NOT EXISTS treasury.internal_transfers (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    from_account_id     UUID NOT NULL REFERENCES treasury.funding_accounts(id),
    to_account_id       UUID NOT NULL REFERENCES treasury.funding_accounts(id),
    amount              NUMERIC(19, 4) NOT NULL,
    currency            VARCHAR(3) DEFAULT 'NOK',
    reference           VARCHAR(255),
    description         TEXT DEFAULT '',
    status              VARCHAR(20) DEFAULT 'completed',
    core_transaction_id UUID,               -- link to core ledger transaction
    created_at          TIMESTAMPTZ DEFAULT NOW()
);

-- Liquidity snapshots: periodic position snapshots
CREATE TABLE IF NOT EXISTS treasury.liquidity_snapshots (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    snapshot_date   DATE NOT NULL,
    total_assets    NUMERIC(19, 4) NOT NULL DEFAULT 0,
    total_liabilities NUMERIC(19, 4) NOT NULL DEFAULT 0,
    net_position    NUMERIC(19, 4) NOT NULL DEFAULT 0,
    currency        VARCHAR(3) DEFAULT 'NOK',
    details         JSONB DEFAULT '{}',
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE (snapshot_date, currency)
);

-- Update transfer status to support Heart-orchestrated lifecycle
ALTER TABLE treasury.internal_transfers
    ALTER COLUMN status SET DEFAULT 'pending';
-- Valid statuses: pending, in_progress, completed, failed, compensated

CREATE INDEX IF NOT EXISTS idx_transfers_from ON treasury.internal_transfers(from_account_id);
CREATE INDEX IF NOT EXISTS idx_transfers_to ON treasury.internal_transfers(to_account_id);
CREATE INDEX IF NOT EXISTS idx_transfers_status ON treasury.internal_transfers(status);
CREATE INDEX IF NOT EXISTS idx_snapshots_date ON treasury.liquidity_snapshots(snapshot_date);

-- ═══════════════════════════════════════════════════════════
-- Routine / operations tables
-- ═══════════════════════════════════════════════════════════

-- Funding gap reports: maturity ladder analysis results
CREATE TABLE IF NOT EXISTS treasury.funding_gap_reports (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    run_date            DATE NOT NULL,
    report_data         JSONB NOT NULL,       -- full maturity ladder with buckets
    breach_detected     BOOLEAN NOT NULL DEFAULT FALSE,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_gap_reports_date ON treasury.funding_gap_reports(run_date);

-- Funding gap alerts: individual limit breaches
CREATE TABLE IF NOT EXISTS treasury.funding_gap_alerts (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    report_id       UUID NOT NULL REFERENCES treasury.funding_gap_reports(id),
    time_bucket     TEXT NOT NULL,            -- 'overnight', '1w', '1m', '3m', '6m', '1y', 'gt1y'
    gap_amount      NUMERIC(19, 4) NOT NULL,
    limit_amount    NUMERIC(19, 4) NOT NULL,
    currency        TEXT NOT NULL DEFAULT 'NOK',
    status          TEXT NOT NULL DEFAULT 'open'
                    CHECK (status IN ('open', 'acknowledged', 'resolved')),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Position limits: configurable thresholds for daily monitoring
CREATE TABLE IF NOT EXISTS treasury.position_limits (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    currency        TEXT NOT NULL DEFAULT 'NOK',
    metric          TEXT NOT NULL,            -- 'net_position', 'available_liquidity', 'total_assets', etc.
    min_value       NUMERIC(19, 4),           -- alert if actual < min
    max_value       NUMERIC(19, 4),           -- alert if actual > max
    alert_threshold NUMERIC(19, 4),           -- warn before hard limit
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (currency, metric)
);

-- Limit alerts: individual position limit breaches
CREATE TABLE IF NOT EXISTS treasury.limit_alerts (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    snapshot_id     UUID REFERENCES treasury.liquidity_snapshots(id),
    limit_id        UUID NOT NULL REFERENCES treasury.position_limits(id),
    actual_value    NUMERIC(19, 4) NOT NULL,
    limit_value     NUMERIC(19, 4) NOT NULL,
    severity        TEXT NOT NULL DEFAULT 'warning'
                    CHECK (severity IN ('warning', 'breach', 'critical')),
    status          TEXT NOT NULL DEFAULT 'open'
                    CHECK (status IN ('open', 'acknowledged', 'resolved')),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_limit_alerts_status ON treasury.limit_alerts(status);
CREATE INDEX IF NOT EXISTS idx_gap_alerts_status ON treasury.funding_gap_alerts(status);
