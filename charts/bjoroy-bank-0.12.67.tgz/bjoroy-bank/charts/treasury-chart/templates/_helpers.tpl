{{/*
Common labels
*/}}
{{- define "treasury-chart.labels" -}}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
helm.sh/chart: {{ .Chart.Name }}-{{ .Chart.Version }}
{{- end }}

{{/*
Validate instanceId — REQUIRED, no default instance concept.
Reads from global.instanceId so it flows from parent chart automatically.
*/}}
{{- define "treasury-chart.instanceId" -}}
{{- required "global.instanceId is required. Set --set global.instanceId=<name>" .Values.global.instanceId -}}
{{- end }}

{{/*
Postgres-safe identifier — replaces hyphens with underscores.
*/}}
{{- define "treasury-chart.pgIdentifier" -}}
{{- . | replace "-" "_" -}}
{{- end }}

{{/*
Treasury database name — {instanceId}_treasury
*/}}
{{- define "treasury-chart.dbName" -}}
{{- include "treasury-chart.pgIdentifier" (include "treasury-chart.instanceId" .) }}_treasury
{{- end }}

{{/*
Database user — shared bank user: {instanceId}_bank
All modules share the same DB user created by the parent setup job.
*/}}
{{- define "treasury-chart.dbUser" -}}
{{- include "treasury-chart.pgIdentifier" (include "treasury-chart.instanceId" .) }}_bank
{{- end }}

{{/*
Database credentials secret — {release}-db-credentials
*/}}
{{- define "treasury-chart.dbCredentialsSecret" -}}
{{ .Release.Name }}-db-credentials
{{- end }}
