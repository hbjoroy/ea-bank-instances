{{/*
Common labels
*/}}
{{- define "accounting-chart.labels" -}}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Values.global.imageTag | default .Chart.AppVersion | quote }}
helm.sh/chart: {{ .Chart.Name }}-{{ .Chart.Version }}
{{- end }}

{{/*
Validate instanceId — REQUIRED.
*/}}
{{- define "accounting-chart.instanceId" -}}
{{- required "global.instanceId is required. Set --set global.instanceId=<name>" .Values.global.instanceId -}}
{{- end }}

{{/*
Postgres-safe identifier — replaces hyphens with underscores.
*/}}
{{- define "accounting-chart.pgIdentifier" -}}
{{- . | replace "-" "_" -}}
{{- end }}

{{/*
Accounting database name: {instanceId}_accounting
*/}}
{{- define "accounting-chart.dbName" -}}
{{- include "accounting-chart.pgIdentifier" (include "accounting-chart.instanceId" .) }}_accounting
{{- end }}

{{/*
Database user — shared bank user: {instanceId}_bank
All modules share the same DB user created by the parent setup job.
*/}}
{{- define "accounting-chart.dbUser" -}}
{{- include "accounting-chart.pgIdentifier" (include "accounting-chart.instanceId" .) }}_bank
{{- end }}

{{/*
Database credentials secret: {release}-db-credentials
*/}}
{{- define "accounting-chart.dbCredentialsSecret" -}}
{{ .Release.Name }}-db-credentials
{{- end }}

{{/*
Full DATABASE_URL
*/}}
{{- define "accounting-chart.databaseUrl" -}}
postgres://{{ include "accounting-chart.dbUser" . }}:$(DB_PASSWORD)@{{ .Values.database.host }}:{{ .Values.database.port }}/{{ include "accounting-chart.dbName" . }}
{{- end }}

{{/*
Selector labels for a component
*/}}
{{- define "accounting-chart.selectorLabels" -}}
app.kubernetes.io/name: {{ .name }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}
