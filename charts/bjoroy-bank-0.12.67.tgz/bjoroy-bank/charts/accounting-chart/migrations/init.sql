-- ea-bank-accounting schema
-- GL accounting module for Bjørøy Bank

CREATE SCHEMA IF NOT EXISTS accounting;

-- Chart of accounts: hierarchical GL account structure
-- Follows NS 4102 (Norwegian standard) adapted for banking
-- Code format: 4 digits (NNNN), hierarchy derived from prefix
--   Class (kontoklasse):  first digit  (1-8)
--   Group (kontogruppe):  first 2 digits (10-89)
--   Account (konto):      full 4 digits (1000-8999)
CREATE TABLE IF NOT EXISTS accounting.chart_of_accounts (
    code        VARCHAR(10) PRIMARY KEY,
    name        VARCHAR(200) NOT NULL,
    description TEXT DEFAULT '',
    account_class   SMALLINT NOT NULL,  -- 1=Assets, 2=Liab+Equity, 3=Revenue, 4-7=Expenses, 8=Tax
    account_group   VARCHAR(10),        -- parent group code (first 2 digits for accounts)
    normal_side     VARCHAR(6) NOT NULL CHECK (normal_side IN ('debit', 'credit')),
    is_group        BOOLEAN DEFAULT FALSE,  -- true = group header, not postable
    is_active       BOOLEAN DEFAULT TRUE,
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- Accounting periods: monthly with lifecycle management
CREATE TABLE IF NOT EXISTS accounting.accounting_periods (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    year        SMALLINT NOT NULL,
    month       SMALLINT NOT NULL CHECK (month BETWEEN 1 AND 12),
    status      VARCHAR(10) NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'closed', 'locked')),
    opened_at   TIMESTAMPTZ DEFAULT NOW(),
    closed_at   TIMESTAMPTZ,
    locked_at   TIMESTAMPTZ,
    created_at  TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE (year, month)
);

-- Journal entries: GL-level transactions (may originate from core sync or manual entry)
CREATE TABLE IF NOT EXISTS accounting.journal_entries (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    period_id       UUID NOT NULL REFERENCES accounting.accounting_periods(id),
    entry_number    BIGINT,  -- sequential within period
    reference       VARCHAR(255) NOT NULL,      -- e.g. core transaction ID, or manual ref
    description     TEXT DEFAULT '',
    source          VARCHAR(20) NOT NULL DEFAULT 'manual' CHECK (source IN ('manual', 'sync', 'closing')),
    core_transaction_id UUID,                   -- link to core posting (NULL for manual entries)
    posted_at       TIMESTAMPTZ DEFAULT NOW(),
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- Journal lines: individual debit/credit per GL account
CREATE TABLE IF NOT EXISTS accounting.journal_lines (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    entry_id        UUID NOT NULL REFERENCES accounting.journal_entries(id),
    gl_account_code VARCHAR(10) NOT NULL REFERENCES accounting.chart_of_accounts(code),
    debit           NUMERIC(19, 4) NOT NULL DEFAULT 0,
    credit          NUMERIC(19, 4) NOT NULL DEFAULT 0,
    currency        VARCHAR(3) DEFAULT 'NOK',
    description     TEXT DEFAULT '',
    CONSTRAINT positive_amounts CHECK (debit >= 0 AND credit >= 0),
    CONSTRAINT one_side_only CHECK (debit = 0 OR credit = 0)
);

-- Balanced journal entry trigger
CREATE OR REPLACE FUNCTION accounting.check_journal_entry_balance()
RETURNS TRIGGER AS $$
DECLARE
    entry_total NUMERIC(19, 4);
BEGIN
    SELECT COALESCE(SUM(debit) - SUM(credit), 0)
    INTO entry_total
    FROM accounting.journal_lines
    WHERE entry_id = NEW.entry_id;

    -- Allow during insert (partial entry); final check via API before commit
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- GL mapping rules: core posting patterns → GL account codes
-- Used by sync process to auto-map core postings to journal entries
CREATE TABLE IF NOT EXISTS accounting.gl_mappings (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name                VARCHAR(100) NOT NULL,
    description         TEXT DEFAULT '',
    core_account_type   VARCHAR(20),            -- matches core.ledger_accounts.account_type
    core_account_subtype VARCHAR(40),           -- matches core.ledger_accounts.account_subtype
    currency            VARCHAR(3),             -- NULL = any currency
    posting_side        VARCHAR(6) NOT NULL CHECK (posting_side IN ('debit', 'credit')),
    gl_account_code     VARCHAR(10) NOT NULL REFERENCES accounting.chart_of_accounts(code),
    priority            INT DEFAULT 0,          -- higher = matched first
    is_active           BOOLEAN DEFAULT TRUE,
    created_at          TIMESTAMPTZ DEFAULT NOW(),
    updated_at          TIMESTAMPTZ DEFAULT NOW()
);

-- Materialized period balances for fast reporting
CREATE TABLE IF NOT EXISTS accounting.balances (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    period_id       UUID NOT NULL REFERENCES accounting.accounting_periods(id),
    gl_account_code VARCHAR(10) NOT NULL REFERENCES accounting.chart_of_accounts(code),
    debit_total     NUMERIC(19, 4) NOT NULL DEFAULT 0,
    credit_total    NUMERIC(19, 4) NOT NULL DEFAULT 0,
    balance         NUMERIC(19, 4) NOT NULL DEFAULT 0,  -- debit_total - credit_total (or inverse for credit-normal accounts)
    currency        VARCHAR(3) DEFAULT 'NOK',
    computed_at     TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE (period_id, gl_account_code, currency)
);

-- Sync state: track last synced core posting for incremental sync
CREATE TABLE IF NOT EXISTS accounting.sync_state (
    id                  VARCHAR(50) PRIMARY KEY DEFAULT 'default',
    last_synced_at      TIMESTAMPTZ,
    last_transaction_id UUID,
    sync_count          BIGINT DEFAULT 0,
    updated_at          TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_journal_entries_period ON accounting.journal_entries(period_id);
CREATE INDEX IF NOT EXISTS idx_journal_entries_core_tx ON accounting.journal_entries(core_transaction_id);
CREATE INDEX IF NOT EXISTS idx_journal_lines_entry ON accounting.journal_lines(entry_id);
CREATE INDEX IF NOT EXISTS idx_journal_lines_gl_account ON accounting.journal_lines(gl_account_code);
CREATE INDEX IF NOT EXISTS idx_balances_period ON accounting.balances(period_id);
CREATE INDEX IF NOT EXISTS idx_gl_mappings_pattern ON accounting.gl_mappings(core_account_type, core_account_subtype, currency);

-- Seed: default Norwegian bank chart of accounts (NS 4102 adaptation)
-- Groups (is_group = true) and key accounts

-- Class 1: Assets (Eiendeler)
INSERT INTO accounting.chart_of_accounts (code, name, account_class, normal_side, is_group) VALUES
    ('10', 'Immaterielle eiendeler', 1, 'debit', TRUE),
    ('11', 'Tomter og bygninger', 1, 'debit', TRUE),
    ('12', 'Transportmidler, inventar, maskiner', 1, 'debit', TRUE),
    ('13', 'Finansielle anleggsmidler', 1, 'debit', TRUE),
    ('14', 'Utlån til kunder', 1, 'debit', TRUE),
    ('15', 'Kortsiktige fordringer', 1, 'debit', TRUE),
    ('19', 'Kontanter og bankinnskudd', 1, 'debit', TRUE)
ON CONFLICT (code) DO NOTHING;

INSERT INTO accounting.chart_of_accounts (code, name, account_class, account_group, normal_side, is_group) VALUES
    ('1400', 'Utlån til kunder', 1, '14', 'debit', FALSE),
    ('1410', 'Nedbetalingslån', 1, '14', 'debit', FALSE),
    ('1420', 'Kassakreditt', 1, '14', 'debit', FALSE),
    ('1500', 'Kundefordringer', 1, '15', 'debit', FALSE),
    ('1900', 'Kontanter', 1, '19', 'debit', FALSE),
    ('1910', 'Bankinnskudd drift', 1, '19', 'debit', FALSE),
    ('1920', 'Bankinnskudd - Norges Bank', 1, '19', 'debit', FALSE),
    ('1930', 'Bankinnskudd - korrespondentbanker', 1, '19', 'debit', FALSE),
    ('1940', 'Oppgjørskonto', 1, '19', 'debit', FALSE)
ON CONFLICT (code) DO NOTHING;

-- Class 2: Liabilities & Equity (Gjeld og egenkapital)
INSERT INTO accounting.chart_of_accounts (code, name, account_class, normal_side, is_group) VALUES
    ('20', 'Egenkapital', 2, 'credit', TRUE),
    ('21', 'Avsetning for forpliktelser', 2, 'credit', TRUE),
    ('22', 'Annen langsiktig gjeld', 2, 'credit', TRUE),
    ('23', 'Innskudd fra kunder', 2, 'credit', TRUE),
    ('24', 'Leverandørgjeld', 2, 'credit', TRUE),
    ('26', 'Skattetrekk og offentlige avgifter', 2, 'credit', TRUE),
    ('27', 'Skyldig lønn og feriepenger', 2, 'credit', TRUE),
    ('29', 'Annen kortsiktig gjeld', 2, 'credit', TRUE)
ON CONFLICT (code) DO NOTHING;

INSERT INTO accounting.chart_of_accounts (code, name, account_class, account_group, normal_side, is_group) VALUES
    ('2000', 'Aksjekapital', 2, '20', 'credit', FALSE),
    ('2020', 'Overkursfond', 2, '20', 'credit', FALSE),
    ('2050', 'Annen egenkapital', 2, '20', 'credit', FALSE),
    ('2300', 'Kundeinnskudd - brukskonto', 2, '23', 'credit', FALSE),
    ('2310', 'Kundeinnskudd - sparekonto', 2, '23', 'credit', FALSE),
    ('2320', 'Kundeinnskudd - fastrentekonto', 2, '23', 'credit', FALSE),
    ('2400', 'Leverandørgjeld', 2, '24', 'credit', FALSE),
    ('2900', 'Annen kortsiktig gjeld', 2, '29', 'credit', FALSE)
ON CONFLICT (code) DO NOTHING;

-- Class 3: Revenue (Inntekter)
INSERT INTO accounting.chart_of_accounts (code, name, account_class, normal_side, is_group) VALUES
    ('30', 'Renteinntekter', 3, 'credit', TRUE),
    ('31', 'Provisjonsinntekter', 3, 'credit', TRUE),
    ('34', 'Gebyrinntekter', 3, 'credit', TRUE),
    ('38', 'Andre driftsinntekter', 3, 'credit', TRUE),
    ('39', 'Kursgevinster', 3, 'credit', TRUE)
ON CONFLICT (code) DO NOTHING;

INSERT INTO accounting.chart_of_accounts (code, name, account_class, account_group, normal_side, is_group) VALUES
    ('3000', 'Renteinntekter utlån', 3, '30', 'credit', FALSE),
    ('3010', 'Renteinntekter bankinnskudd', 3, '30', 'credit', FALSE),
    ('3100', 'Provisjonsinntekter betalingsformidling', 3, '31', 'credit', FALSE),
    ('3400', 'Gebyrinntekter kontohold', 3, '34', 'credit', FALSE),
    ('3410', 'Gebyrinntekter betalingstjenester', 3, '34', 'credit', FALSE),
    ('3800', 'Andre driftsinntekter', 3, '38', 'credit', FALSE)
ON CONFLICT (code) DO NOTHING;

-- Class 4: Cost of materials / Interest expenses
INSERT INTO accounting.chart_of_accounts (code, name, account_class, normal_side, is_group) VALUES
    ('40', 'Rentekostnader', 4, 'debit', TRUE),
    ('41', 'Andre finanskostnader', 4, 'debit', TRUE)
ON CONFLICT (code) DO NOTHING;

INSERT INTO accounting.chart_of_accounts (code, name, account_class, account_group, normal_side, is_group) VALUES
    ('4000', 'Rentekostnader kundeinnskudd', 4, '40', 'debit', FALSE),
    ('4010', 'Rentekostnader innlån', 4, '40', 'debit', FALSE),
    ('4100', 'Provisjonskostnader', 4, '41', 'debit', FALSE)
ON CONFLICT (code) DO NOTHING;

-- Class 5: Personnel expenses
INSERT INTO accounting.chart_of_accounts (code, name, account_class, normal_side, is_group) VALUES
    ('50', 'Lønn', 5, 'debit', TRUE),
    ('52', 'Arbeidsgiveravgift', 5, 'debit', TRUE),
    ('53', 'Pensjonskostnader', 5, 'debit', TRUE),
    ('59', 'Andre personalkostnader', 5, 'debit', TRUE)
ON CONFLICT (code) DO NOTHING;

INSERT INTO accounting.chart_of_accounts (code, name, account_class, account_group, normal_side, is_group) VALUES
    ('5000', 'Lønn', 5, '50', 'debit', FALSE),
    ('5200', 'Arbeidsgiveravgift', 5, '52', 'debit', FALSE),
    ('5300', 'Pensjonskostnader', 5, '53', 'debit', FALSE),
    ('5900', 'Andre personalkostnader', 5, '59', 'debit', FALSE)
ON CONFLICT (code) DO NOTHING;

-- Class 6-7: Other operating expenses
INSERT INTO accounting.chart_of_accounts (code, name, account_class, normal_side, is_group) VALUES
    ('60', 'Avskrivninger', 6, 'debit', TRUE),
    ('63', 'Tap på utlån', 6, 'debit', TRUE),
    ('65', 'IT-kostnader', 6, 'debit', TRUE),
    ('69', 'Andre driftskostnader', 6, 'debit', TRUE),
    ('70', 'Kontorkostnader', 7, 'debit', TRUE),
    ('77', 'Revisjon og rådgivning', 7, 'debit', TRUE),
    ('79', 'Andre driftskostnader 2', 7, 'debit', TRUE)
ON CONFLICT (code) DO NOTHING;

INSERT INTO accounting.chart_of_accounts (code, name, account_class, account_group, normal_side, is_group) VALUES
    ('6000', 'Avskrivninger', 6, '60', 'debit', FALSE),
    ('6300', 'Tap på utlån', 6, '63', 'debit', FALSE),
    ('6500', 'IT-drift og lisenser', 6, '65', 'debit', FALSE),
    ('6900', 'Andre driftskostnader', 6, '69', 'debit', FALSE),
    ('7000', 'Kontorkostnader', 7, '70', 'debit', FALSE),
    ('7700', 'Revisjon og rådgivning', 7, '77', 'debit', FALSE)
ON CONFLICT (code) DO NOTHING;

-- Class 8: Tax and extraordinary items
INSERT INTO accounting.chart_of_accounts (code, name, account_class, normal_side, is_group) VALUES
    ('80', 'Finansinntekter', 8, 'credit', TRUE),
    ('81', 'Finanskostnader', 8, 'debit', TRUE),
    ('83', 'Skattekostnad', 8, 'debit', TRUE),
    ('88', 'Årsresultat', 8, 'credit', TRUE)
ON CONFLICT (code) DO NOTHING;

INSERT INTO accounting.chart_of_accounts (code, name, account_class, account_group, normal_side, is_group) VALUES
    ('8000', 'Finansinntekter', 8, '80', 'credit', FALSE),
    ('8100', 'Finanskostnader', 8, '81', 'debit', FALSE),
    ('8300', 'Skattekostnad', 8, '83', 'debit', FALSE),
    ('8800', 'Årsresultat', 8, '88', 'credit', FALSE)
ON CONFLICT (code) DO NOTHING;

-- Default GL mappings: core posting patterns → GL accounts
-- These map the operational ledger events to the chart of accounts
INSERT INTO accounting.gl_mappings (name, core_account_type, core_account_subtype, currency, posting_side, gl_account_code, priority) VALUES
    ('Customer deposit - debit', 'general_ledger', NULL, 'NOK', 'debit', '1940', 10),
    ('Customer deposit - credit', 'customer', NULL, 'NOK', 'credit', '2300', 10),
    ('Fee income - debit', 'customer', NULL, 'NOK', 'debit', '2300', 5),
    ('Fee income - credit', NULL, 'fee_income', 'NOK', 'credit', '3400', 20),
    ('Loan disbursement - debit', 'customer', NULL, 'NOK', 'debit', '1400', 5),
    ('Loan disbursement - credit', 'general_ledger', NULL, 'NOK', 'credit', '1940', 5)
ON CONFLICT DO NOTHING;

-- Initialize sync state
INSERT INTO accounting.sync_state (id, sync_count) VALUES ('default', 0)
ON CONFLICT DO NOTHING;

-- ═══════════════════════════════════════════════════════════
-- Routine / operations tables
-- ═══════════════════════════════════════════════════════════

-- Reconciliation runs: one row per daily recon execution
CREATE TABLE IF NOT EXISTS accounting.reconciliation_runs (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    period_id       UUID NOT NULL REFERENCES accounting.accounting_periods(id),
    run_date        DATE NOT NULL,
    status          TEXT NOT NULL DEFAULT 'running'
                    CHECK (status IN ('running', 'clean', 'exceptions', 'failed')),
    total_accounts  INT NOT NULL DEFAULT 0,
    matched         INT NOT NULL DEFAULT 0,
    breaks          INT NOT NULL DEFAULT 0,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_recon_runs_date ON accounting.reconciliation_runs(run_date);

-- Reconciliation exceptions: individual breaks for investigation
CREATE TABLE IF NOT EXISTS accounting.reconciliation_exceptions (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    run_id          UUID NOT NULL REFERENCES accounting.reconciliation_runs(id),
    gl_account_code TEXT NOT NULL,
    gl_balance      NUMERIC(20,4) NOT NULL,
    core_balance    NUMERIC(20,4) NOT NULL,
    difference      NUMERIC(20,4) NOT NULL,
    currency        TEXT NOT NULL DEFAULT 'NOK',
    status          TEXT NOT NULL DEFAULT 'open'
                    CHECK (status IN ('open', 'investigating', 'resolved', 'written_off')),
    resolved_by     TEXT,
    resolved_at     TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_recon_exceptions_status ON accounting.reconciliation_exceptions(status);

-- Daily P&L flash: management summary per day
CREATE TABLE IF NOT EXISTS accounting.daily_flash (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    run_date        DATE NOT NULL,
    period_id       UUID NOT NULL REFERENCES accounting.accounting_periods(id),
    total_revenue   NUMERIC(20,4) NOT NULL DEFAULT 0,
    total_expenses  NUMERIC(20,4) NOT NULL DEFAULT 0,
    net_income      NUMERIC(20,4) NOT NULL DEFAULT 0,
    currency        TEXT NOT NULL DEFAULT 'NOK',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (run_date, currency)
);

-- Period snapshots: frozen financial statements for audit trail
CREATE TABLE IF NOT EXISTS accounting.period_snapshots (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    period_id       UUID NOT NULL REFERENCES accounting.accounting_periods(id),
    report_type     TEXT NOT NULL
                    CHECK (report_type IN ('trial_balance', 'balance_sheet', 'income_statement')),
    report_data     JSONB NOT NULL,
    generated_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (period_id, report_type)
);
