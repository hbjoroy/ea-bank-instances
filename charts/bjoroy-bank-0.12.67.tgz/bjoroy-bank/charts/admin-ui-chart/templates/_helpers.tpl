{{/*
Validate instanceId — REQUIRED, no default.
*/}}
{{- define "admin-ui.instanceId" -}}
{{- required "global.instanceId is required. Set --set global.instanceId=<name>" .Values.global.instanceId -}}
{{- end }}

{{/*
Common labels
*/}}
{{- define "admin-ui.labels" -}}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Values.global.imageTag | default .Chart.AppVersion | quote }}
helm.sh/chart: {{ .Chart.Name }}-{{ .Chart.Version }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "admin-ui.selectorLabels" -}}
app.kubernetes.io/name: admin-ui
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Full image reference — uses subchart-specific imageTag, NOT global.imageTag
*/}}
{{- define "admin-ui.image" -}}
{{ .Values.global.imageRegistry }}/{{ .Values.adminUi.image }}:{{ .Values.adminUi.imageTag | default .Chart.AppVersion }}
{{- end }}

{{/*
Backend host helpers — use explicit host if set, otherwise derive FQDN from
release name + namespace.  Nginx's `resolver` directive bypasses the normal
/etc/resolv.conf search domains, so bare service names don't resolve.
*/}}
{{- define "admin-ui.adminApiHost" -}}
{{- if .Values.backends.adminApi.host -}}
{{ .Values.backends.adminApi.host }}
{{- else -}}
admin-api.{{ .Release.Namespace }}.svc.cluster.local
{{- end -}}
{{- end }}

{{- define "admin-ui.definitionsServiceHost" -}}
{{- if .Values.backends.definitionsService.host -}}
{{ .Values.backends.definitionsService.host }}
{{- else -}}
definitions-service.{{ .Release.Namespace }}.svc.cluster.local
{{- end -}}
{{- end }}

{{- define "admin-ui.accountingApiHost" -}}
{{- if .Values.backends.accountingApi.host -}}
{{ .Values.backends.accountingApi.host }}
{{- else -}}
{{ .Release.Name }}-accounting-api.{{ .Release.Namespace }}.svc.cluster.local
{{- end -}}
{{- end }}

{{- define "admin-ui.treasuryApiHost" -}}
{{- if .Values.backends.treasuryApi.host -}}
{{ .Values.backends.treasuryApi.host }}
{{- else -}}
{{ .Release.Name }}-treasury-api.{{ .Release.Namespace }}.svc.cluster.local
{{- end -}}
{{- end }}
