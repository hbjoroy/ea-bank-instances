-- Chat service schema
CREATE SCHEMA IF NOT EXISTS chat;

CREATE TABLE IF NOT EXISTS chat.sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_subject TEXT NOT NULL,
    customer_id UUID,
    access_token TEXT,
    refresh_token TEXT,
    token_expires_at TIMESTAMPTZ,
    pkce_verifier TEXT,
    oauth_state TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_active_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    metadata JSONB NOT NULL DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS chat.messages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    session_id UUID NOT NULL REFERENCES chat.sessions(id),
    role TEXT NOT NULL,
    content TEXT,
    tool_calls JSONB,
    tool_call_id TEXT,
    tool_name TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_chat_messages_session
    ON chat.messages(session_id, created_at);

CREATE INDEX IF NOT EXISTS idx_chat_sessions_user
    ON chat.sessions(user_subject, last_active_at DESC);

CREATE INDEX IF NOT EXISTS idx_chat_sessions_oauth_state
    ON chat.sessions(oauth_state) WHERE oauth_state IS NOT NULL;

-- Upgrade: add OIDC token columns (idempotent for existing installs)
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns
                   WHERE table_schema='chat' AND table_name='sessions' AND column_name='access_token') THEN
        ALTER TABLE chat.sessions ADD COLUMN access_token TEXT;
        ALTER TABLE chat.sessions ADD COLUMN refresh_token TEXT;
        ALTER TABLE chat.sessions ADD COLUMN token_expires_at TIMESTAMPTZ;
        ALTER TABLE chat.sessions ADD COLUMN pkce_verifier TEXT;
        ALTER TABLE chat.sessions ADD COLUMN oauth_state TEXT;
        CREATE INDEX IF NOT EXISTS idx_chat_sessions_oauth_state
            ON chat.sessions(oauth_state) WHERE oauth_state IS NOT NULL;
    END IF;
END $$;
