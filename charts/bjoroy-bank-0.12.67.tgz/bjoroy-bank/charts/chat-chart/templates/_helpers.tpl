{{/*
Common labels
*/}}
{{- define "chat-chart.labels" -}}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Values.global.imageTag | default .Chart.AppVersion | quote }}
helm.sh/chart: {{ .Chart.Name }}-{{ .Chart.Version }}
{{- end }}

{{/*
Validate instanceId — REQUIRED.
*/}}
{{- define "chat-chart.instanceId" -}}
{{- required "global.instanceId is required. Set --set global.instanceId=<name>" .Values.global.instanceId -}}
{{- end }}

{{/*
Postgres-safe identifier — replaces hyphens with underscores.
*/}}
{{- define "chat-chart.pgIdentifier" -}}
{{- . | replace "-" "_" -}}
{{- end }}

{{/*
Chat uses the main bank database with a chat schema (not a separate DB).
Database name: {instanceId}_bank
*/}}
{{- define "chat-chart.dbName" -}}
{{- include "chat-chart.pgIdentifier" (include "chat-chart.instanceId" .) }}_bank
{{- end }}

{{/*
Database user — shared bank user: {instanceId}_bank
*/}}
{{- define "chat-chart.dbUser" -}}
{{- include "chat-chart.pgIdentifier" (include "chat-chart.instanceId" .) }}_bank
{{- end }}

{{/*
Database credentials secret: {release}-db-credentials
*/}}
{{- define "chat-chart.dbCredentialsSecret" -}}
{{ .Release.Name }}-db-credentials
{{- end }}

{{/*
Full DATABASE_URL
*/}}
{{- define "chat-chart.databaseUrl" -}}
postgres://{{ include "chat-chart.dbUser" . }}:$(DB_PASSWORD)@{{ .Values.database.host }}:{{ .Values.database.port }}/{{ include "chat-chart.dbName" . }}
{{- end }}

{{/*
Selector labels for a component
*/}}
{{- define "chat-chart.selectorLabels" -}}
app.kubernetes.io/name: {{ .name }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}
